package com.worldhordes.mod.events;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.horde.HordeManager;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;
import com.worldhordes.mod.registry.ModBlocks;

public class WorldEventHandler {

    private static long serverTick = 0;

    /**
     * Tracks which players were already warned this session (UUID → last warn tick).
     * Warnings are sent once when the player first enters detection range, then
     * suppressed until they leave and re-enter the area.
     */
    private static final Map<UUID, Long> lastWarningTick = new HashMap<>();
    /**
     * How many ticks between repeat warnings for the same player still inside range.
     * Default: 6000 ticks = 5 minutes.
     */
    private static final long WARNING_COOLDOWN_TICKS = 6000L;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        serverTick++;

        int updateInterval = WorldHordesConfig.COMMON.ticksPerInfestationUpdate.get();
        if (serverTick % updateInterval == 0) {
            HordeManager.tick(serverTick);
        }

        // Player proximity warnings — checked every 2 seconds (40 ticks)
        if (serverTick % 40 == 0) {
            tickPlayerWarnings();
        }
    }

    /**
     * Sends a warning to any player who enters an infested area.
     * The warning fires once on entry, then respects WARNING_COOLDOWN_TICKS before repeating.
     */
    private void tickPlayerWarnings() {
        int warningRadius = WorldHordesConfig.COMMON.infestationWarningDetectionChunks.get();
        if (warningRadius <= 0) return;

        for (net.minecraft.server.MinecraftServer server : getServers()) {
            ServerLevel overworld = server.getLevel(Level.OVERWORLD);
            if (overworld == null) continue;
            String dim = DimUtil.OVERWORLD_DIM;

            for (net.minecraft.world.entity.player.Player rawPlayer : overworld.players()) {
                if (!(rawPlayer instanceof ServerPlayer player)) continue;

                UUID uuid = player.getUUID();
                BlockPos pos = player.blockPosition();
                int playerCx = pos.getX() >> 4;
                int playerCz = pos.getZ() >> 4;

                int[] nearest = InfestationData.getNearestInfestedRegionCentre(
                        dim, playerCx, playerCz, warningRadius);

                if (nearest != null) {
                    long lastWarn = lastWarningTick.getOrDefault(uuid, -WARNING_COOLDOWN_TICKS);
                    if (serverTick - lastWarn >= WARNING_COOLDOWN_TICKS) {
                        lastWarningTick.put(uuid, serverTick);
                        // Distance in chunks for context
                        int dist = Math.max(Math.abs(playerCx - nearest[0]), Math.abs(playerCz - nearest[1]));
                        player.sendSystemMessage(Component.literal(
                                "§4⚠ You are entering an infested area! "
                                + "Zombies are nearby (" + dist + " chunk" + (dist == 1 ? "" : "s") + " away). Be careful!"));
                    }
                } else {
                    // Player left the danger zone — reset so they get a fresh warning on next entry
                    lastWarningTick.remove(uuid);
                }
            }
        }
    }

    /** Helper to access all running server instances (in practice always one). */
    private Iterable<net.minecraft.server.MinecraftServer> getServers() {
        net.minecraft.server.MinecraftServer s = HordeManager.getServer();
        return s != null ? java.util.List.of(s) : java.util.List.of();
    }

    @SubscribeEvent
    public void onLevelLoad(LevelEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel level) {
            if (level.dimension() == Level.OVERWORLD) {
                WorldHordesMod.LOGGER.info("[WorldHordes] Overworld loaded - zombie ecosystem is active.");
            }
        }
    }

    /**
     * Fires when an entity leaves the chunk tracking system (i.e. despawns naturally
     * or is unloaded far from players). If it's a tagged infest-zombie, return it
     * to its source chunk's reserve.
     *
     * Additionally, if ANY zombie (tagged or not) despawns inside a previously-cleared
     * chunk, that counts as a re-infestation event — the cleared flag is lifted and a
     * small amount of infestation is seeded, satisfying the design rule:
     * "cleared chunks only spawn zombies again once a zombie enters and despawns there."
     */
    @SubscribeEvent
    public void onEntityLeaveWorld(EntityLeaveLevelEvent event) {
        if (!(event.getEntity() instanceof Zombie zombie)) return;
        if (!zombie.isAlive()) return; // dead zombies handled by LivingDeathEvent

        String dim = com.worldhordes.mod.util.DimUtil.getDim(
                (net.minecraft.server.level.ServerLevel) event.getLevel());
        net.minecraft.core.BlockPos pos = zombie.blockPosition();
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;

        // Re-infestation from zombie despawning inside a cleared chunk
        com.worldhordes.mod.data.ChunkInfestationLevel chunkState =
                com.worldhordes.mod.data.InfestationData.get(dim, cx, cz);
        if (chunkState != null && chunkState.isCleared()) {
            int reinfestAmount = WorldHordesConfig.COMMON.infestationFromZombieEntry.get();
            chunkState.addInfestationForced(reinfestAmount);
            WorldHordesMod.LOGGER.info(
                    "[WorldHordes] Cleared chunk ({},{}) re-seeded by zombie despawn (+{} infestation).",
                    cx, cz, reinfestAmount);
        }

        // Zombie despawned inside a player-claimed chunk — lift the claim
        if (PlayerClaimedChunkManager.isChunkClaimed(dim, cx, cz)) {
            PlayerClaimedChunkManager.onZombieEnteredClaimed(dim, cx, cz);
            // Physically break any Claimed Chunk Block in this chunk so the state is consistent
            if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel serverLvl) {
                net.minecraft.world.level.chunk.LevelChunk lc = serverLvl.getChunkAt(zombie.blockPosition());
                net.minecraft.core.BlockPos.MutableBlockPos mpos = new net.minecraft.core.BlockPos.MutableBlockPos();
                int baseX = lc.getPos().getMinBlockX();
                int baseZ = lc.getPos().getMinBlockZ();
                ModBlocks.CLAIMED_CHUNK.ifPresent(claimedBlock -> {
                    outerLoop:
                    for (int bx = baseX; bx < baseX + 16; bx++) {
                        for (int bz = baseZ; bz < baseZ + 16; bz++) {
                            for (int by = serverLvl.getMinBuildHeight(); by < serverLvl.getMaxBuildHeight(); by++) {
                                mpos.set(bx, by, bz);
                                if (serverLvl.getBlockState(mpos).getBlock() == claimedBlock) {
                                    // Drop the block back as an item if configured
                                    if (WorldHordesConfig.COMMON.claimedChunkDropOnBreak.get()) {
                                        net.minecraft.world.item.ItemStack drop = new net.minecraft.world.item.ItemStack(claimedBlock);
                                        net.minecraft.world.entity.item.ItemEntity itemEntity =
                                                new net.minecraft.world.entity.item.ItemEntity(serverLvl,
                                                        mpos.getX() + 0.5, mpos.getY() + 0.5, mpos.getZ() + 0.5, drop);
                                        serverLvl.addFreshEntity(itemEntity);
                                    }
                                    serverLvl.setBlock(mpos,
                                            net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),
                                            net.minecraft.world.level.block.Block.UPDATE_CLIENTS);
                                    WorldHordesMod.LOGGER.info(
                                            "[WorldHordes] Claimed Chunk Block at {} broken by zombie entry.",
                                            mpos.immutable());
                                    break outerLoop;
                                }
                            }
                        }
                    }
                });
            }
        }

        // Infest-tagged zombie untrack (reserve return)
        if (!zombie.getPersistentData().getBoolean("worldhordes_infest_spawn")) return;
        HordeManager.onInfestZombieUntrack(zombie);
    }
}
