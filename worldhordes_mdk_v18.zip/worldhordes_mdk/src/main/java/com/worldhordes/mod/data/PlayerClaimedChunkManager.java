package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages the Player Claimed Chunk system.
 *
 * When a player fully clears an infested chunk they earn one "Claim Token".
 * They can spend that token to place a Claimed Chunk Block anywhere in the world.
 * While that block is present:
 *   - No zombies or hostile mobs spawn naturally inside the chunk.
 *   - The only way for zombies to re-enter is by physically walking in and despawning
 *     (which lifts the protection on that chunk exactly like a normal cleared infested chunk).
 *
 * This mirrors the existing cleared-chunk logic from ChunkInfestationLevel but is player-
 * controlled and can be placed anywhere, not just inside a former infestation zone.
 */
public class PlayerClaimedChunkManager {

    private static final String SAVE_FILE = "worldhordes_claimed_chunks.dat";

    /** Set of "dim:cx:cz" keys for chunks that have an active Claimed Chunk Block. */
    private static final Set<String> claimedChunks = ConcurrentHashMap.newKeySet();

    /** Player UUID → token count (how many cleared infested chunks they've earned). */
    private static final Map<UUID, Integer> playerTokens = new ConcurrentHashMap<>();

    private static MinecraftServer server;

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        load();
    }

    // -------------------------------------------------------------------------
    // Token management
    // -------------------------------------------------------------------------

    /** Award a player one claim token (called when they fully clear an infested zone). */
    public static void awardToken(UUID playerUUID, String playerName) {
        int current = playerTokens.getOrDefault(playerUUID, 0);
        playerTokens.put(playerUUID, current + 1);
        WorldHordesMod.LOGGER.info("[WorldHordes] Awarded claim token to {} (UUID {}). Tokens: {}",
                playerName, playerUUID, current + 1);
    }

    /** Returns the number of claim tokens a player holds. */
    public static int getTokens(UUID playerUUID) {
        return playerTokens.getOrDefault(playerUUID, 0);
    }

    /**
     * Spend one claim token for a player. Returns true if they had one to spend.
     */
    public static boolean spendToken(UUID playerUUID) {
        int current = playerTokens.getOrDefault(playerUUID, 0);
        if (current <= 0) return false;
        playerTokens.put(playerUUID, current - 1);
        return true;
    }

    /** Set a player's token count directly (used by admin commands). */
    public static void setTokens(UUID playerUUID, int count) {
        playerTokens.put(playerUUID, Math.max(0, count));
    }

    // -------------------------------------------------------------------------
    // Claimed chunk registration
    // -------------------------------------------------------------------------

    private static String chunkKey(String dim, int cx, int cz) {
        return dim + ":" + cx + ":" + cz;
    }

    /**
     * Register a chunk as player-claimed. Called when the Claimed Chunk Block is placed.
     * Returns true if the chunk wasn't already claimed.
     */
    public static boolean claimChunk(String dim, int cx, int cz) {
        return claimedChunks.add(chunkKey(dim, cx, cz));
    }

    /**
     * Remove a chunk from the claimed set. Called when the Claimed Chunk Block is broken.
     */
    public static void unclaimChunk(String dim, int cx, int cz) {
        claimedChunks.remove(chunkKey(dim, cx, cz));
        WorldHordesMod.LOGGER.info("[WorldHordes] Claimed chunk ({},{}) released.", cx, cz);
    }

    /** Returns true if a chunk is currently claimed by a player. */
    public static boolean isChunkClaimed(String dim, int cx, int cz) {
        return claimedChunks.contains(chunkKey(dim, cx, cz));
    }

    /** Returns an unmodifiable view of all claimed chunk keys for debug/command use. */
    public static Set<String> getAllClaimedChunks() {
        return Collections.unmodifiableSet(claimedChunks);
    }

    /** Total number of currently active claimed chunks. */
    public static int getClaimedChunkCount() { return claimedChunks.size(); }

    // -------------------------------------------------------------------------
    // Re-infestation from zombie entry (mirrors infested-chunk cleared logic)
    // -------------------------------------------------------------------------

    /**
     * Called when a zombie despawns (not killed) inside a claimed chunk.
     * Removes the claim and allows natural spawns again in that chunk.
     * The Claimed Chunk Block must be removed separately (via block break event).
     */
    public static void onZombieEnteredClaimed(String dim, int cx, int cz) {
        if (claimedChunks.remove(chunkKey(dim, cx, cz))) {
            WorldHordesMod.LOGGER.info(
                    "[WorldHordes] Claimed chunk ({},{}) breached by zombie despawn — claim lifted.",
                    cx, cz);
            // The physical block needs to be broken too — handled by ClaimedChunkBlock event
        }
    }

    // -------------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(1); // version
            // Claimed chunks
            out.writeInt(claimedChunks.size());
            for (String key : claimedChunks) {
                out.writeUTF(key);
            }
            // Player tokens
            out.writeInt(playerTokens.size());
            for (Map.Entry<UUID, Integer> e : playerTokens.entrySet()) {
                out.writeUTF(e.getKey().toString());
                out.writeInt(e.getValue());
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved {} claimed chunks, {} player token records.",
                    claimedChunks.size(), playerTokens.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save claimed chunk data", e);
        }
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int version = in.readInt();
            int chunkCount = in.readInt();
            for (int i = 0; i < chunkCount; i++) {
                claimedChunks.add(in.readUTF());
            }
            if (version >= 1) {
                int tokenCount = in.readInt();
                for (int i = 0; i < tokenCount; i++) {
                    UUID uuid = UUID.fromString(in.readUTF());
                    int tokens = in.readInt();
                    playerTokens.put(uuid, tokens);
                }
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded {} claimed chunks, {} player token records.",
                    claimedChunks.size(), playerTokens.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load claimed chunk data", e);
        }
    }
}
