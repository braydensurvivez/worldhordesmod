package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks all active InfestationZones.  Each zone has exactly ONE shared
 * {@link InfestationEntity} that holds the whole zone's population.
 *
 * Zone keys: "dim:originX:originZ"  (originX/Z = top-left core chunk)
 * Chunk lookup key: "dim:cx:cz"
 */
public class InfestationZoneRegistry {

    private static final String SAVE_FILE = "worldhordes_zones.dat";

    /** key: "dim:originX:originZ" → zone */
    private static final Map<String, InfestationZone>   activeZones      = new ConcurrentHashMap<>();
    /** key: "dim:originX:originZ" → shared entity */
    private static final Map<String, InfestationEntity> zoneEntities     = new ConcurrentHashMap<>();
    /** Reverse lookup: "dim:cx:cz" → zone key */
    private static final Map<String, String>            chunkToZoneKey   = new ConcurrentHashMap<>();
    /** dim key → set of zone keys in that dim (for fast getAllZoneCentres) */
    private static final Map<String, Set<String>>       dimToZoneKeys    = new ConcurrentHashMap<>();

    private static MinecraftServer server;

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        load();
    }

    // -------------------------------------------------------------------------
    // Key helpers
    // -------------------------------------------------------------------------

    private static String zoneKey(String dim, InfestationZone zone) {
        return dim + ":" + zone.getOriginX() + ":" + zone.getOriginZ();
    }

    private static String chunkKey(String dim, int cx, int cz) {
        return dim + ":" + cx + ":" + cz;
    }

    // -------------------------------------------------------------------------
    // Zone creation
    // -------------------------------------------------------------------------

    /**
     * Creates and registers a new infestation zone centred near (centreX, centreZ).
     * Returns the zone, or null if placement is rejected (distance check failed).
     *
     * @param initialPopulation starting population for the shared entity
     */
    public static InfestationZone createZone(String dim, int centreX, int centreZ,
                                             int initialPopulation) {
        InfestationZone zone = InfestationZone.centredAt(centreX, centreZ);

        int minDist = WorldHordesConfig.COMMON.infestationRegionMinDistance.get();
        if (minDist > 0 && !isDistanceValid(dim, zone, minDist)) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Zone creation rejected at ({},{}) — too close to existing zone.",
                        centreX, centreZ);
            }
            return null;
        }

        String key = zoneKey(dim, zone);
        activeZones.put(key, zone);
        InfestationEntity entity = new InfestationEntity(initialPopulation);
        entity.setZoneKey(key);
        zoneEntities.put(key, entity);

        dimToZoneKeys.computeIfAbsent(dim, d -> ConcurrentHashMap.newKeySet()).add(key);

        // Register chunk → zone mappings for fast lookup
        for (int[] chunk : zone.getAllChunks()) {
            chunkToZoneKey.put(chunkKey(dim, chunk[0], chunk[1]), key);
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Created {} in dim={} population={}",
                zone, dim, initialPopulation);
        return zone;
    }

    // -------------------------------------------------------------------------
    // Lookup
    // -------------------------------------------------------------------------

    /** Returns the zone that contains chunk (cx,cz), or null. */
    public static InfestationZone getZoneFor(String dim, int cx, int cz) {
        String key = chunkToZoneKey.get(chunkKey(dim, cx, cz));
        return key != null ? activeZones.get(key) : null;
    }

    /** Returns the shared InfestationEntity for the zone containing (cx,cz), or null. */
    public static InfestationEntity getEntityFor(String dim, int cx, int cz) {
        String key = chunkToZoneKey.get(chunkKey(dim, cx, cz));
        return key != null ? zoneEntities.get(key) : null;
    }

    /** Returns the shared InfestationEntity for a zone key, or null. */
    public static InfestationEntity getEntityByKey(String zoneKey) {
        return zoneEntities.get(zoneKey);
    }

    /** Returns the InfestationZone for a zone key, or null. */
    public static InfestationZone getZoneByKey(String zoneKey) {
        return activeZones.get(zoneKey);
    }

    /** Returns the zone role of (cx,cz) across all active zones. */
    public static InfestationZone.ZoneRole getRoleOf(String dim, int cx, int cz) {
        String key = chunkToZoneKey.get(chunkKey(dim, cx, cz));
        if (key == null) return InfestationZone.ZoneRole.NONE;
        InfestationZone zone = activeZones.get(key);
        return zone != null ? zone.roleOf(cx, cz) : InfestationZone.ZoneRole.NONE;
    }

    public static boolean isCore(String dim, int cx, int cz) {
        return getRoleOf(dim, cx, cz) == InfestationZone.ZoneRole.CORE;
    }

    public static boolean isOuterRing(String dim, int cx, int cz) {
        return getRoleOf(dim, cx, cz) == InfestationZone.ZoneRole.OUTER_RING;
    }

    public static boolean isInAnyZone(String dim, int cx, int cz) {
        return getRoleOf(dim, cx, cz) != InfestationZone.ZoneRole.NONE;
    }

    // -------------------------------------------------------------------------
    // Zone removal
    // -------------------------------------------------------------------------

    /**
     * Removes the zone that contains chunk (cx,cz) plus all chunk mappings.
     * Does NOT remove blood decals — caller must do that.
     */
    public static void removeZone(String dim, int cx, int cz) {
        String key = chunkToZoneKey.get(chunkKey(dim, cx, cz));
        if (key == null) return;
        removeZoneByKey(dim, key);
    }

    public static void removeZoneByKey(String dim, String key) {
        InfestationZone zone = activeZones.remove(key);
        zoneEntities.remove(key);
        Set<String> dimKeys = dimToZoneKeys.get(dim);
        if (dimKeys != null) dimKeys.remove(key);
        if (zone != null) {
            for (int[] chunk : zone.getAllChunks()) {
                chunkToZoneKey.remove(chunkKey(dim, chunk[0], chunk[1]));
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Removed zone {} from dim={}", zone, dim);
        }
    }

    // -------------------------------------------------------------------------
    // Iteration helpers
    // -------------------------------------------------------------------------

    public static int[] getNearestZoneCentre(String dim, int cx, int cz, int searchRadius) {
        int bestDist = Integer.MAX_VALUE;
        int[] best = null;
        Set<String> keys = dimToZoneKeys.get(dim);
        if (keys == null) return null;
        for (String key : keys) {
            InfestationZone zone = activeZones.get(key);
            if (zone == null) continue;
            int ecx = zone.getZoneCentreX(), ecz = zone.getZoneCentreZ();
            int dist = Math.max(Math.abs(cx - ecx), Math.abs(cz - ecz));
            if (dist <= searchRadius && dist < bestDist) {
                bestDist = dist;
                best = new int[]{ecx, ecz};
            }
        }
        return best;
    }

    public static List<int[]> getAllZoneCentres(String dim) {
        List<int[]> result = new ArrayList<>();
        Set<String> keys = dimToZoneKeys.get(dim);
        if (keys == null) return result;
        for (String key : keys) {
            InfestationZone z = activeZones.get(key);
            if (z != null) result.add(new int[]{z.getZoneCentreX(), z.getZoneCentreZ()});
        }
        return result;
    }

    public static Collection<InfestationZone> getAllZones() {
        return Collections.unmodifiableCollection(activeZones.values());
    }

    /**
     * Returns all active zone keys mapped to their entities.
     * Used by HordeManager for the density contribution tick.
     */
    public static Map<String, InfestationEntity> getAllEntities() {
        return Collections.unmodifiableMap(zoneEntities);
    }

    /**
     * Returns all (zoneKey, zone) pairs across all dimensions.
     */
    public static Map<String, InfestationZone> getAllZoneMap() {
        return Collections.unmodifiableMap(activeZones);
    }

    public static int getZoneCount() { return activeZones.size(); }

    /**
     * Extracts the dimension portion from a zone key of the form "dim:originX:originZ".
     * The dim itself may contain colons (e.g. "modid:custom_dim"), so everything before
     * the last two ':'-separated integer segments is treated as the dimension.
     */
    public static String extractDim(String zoneKey) {
        String[] parts = zoneKey.split(":");
        if (parts.length < 3) return "minecraft:overworld"; // fallback
        StringBuilder dimBuilder = new StringBuilder();
        for (int p = 0; p < parts.length - 2; p++) {
            if (p > 0) dimBuilder.append(":");
            dimBuilder.append(parts[p]);
        }
        return dimBuilder.toString();
    }

    // -------------------------------------------------------------------------
    // Distance check
    // -------------------------------------------------------------------------

    public static boolean isDistanceValid(String dim, int cx, int cz) {
        InfestationZone candidate = InfestationZone.centredAt(cx, cz);
        int minDist = WorldHordesConfig.COMMON.infestationRegionMinDistance.get();
        return isDistanceValid(dim, candidate, minDist);
    }

    private static boolean isDistanceValid(String dim, InfestationZone candidate, int minDist) {
        int cx = candidate.getZoneCentreX(), cz = candidate.getZoneCentreZ();
        Set<String> keys = dimToZoneKeys.get(dim);
        if (keys == null) return true;
        for (String key : keys) {
            InfestationZone existing = activeZones.get(key);
            if (existing == null) continue;
            int dist = Math.max(Math.abs(cx - existing.getZoneCentreX()),
                                Math.abs(cz - existing.getZoneCentreZ()));
            if (dist < minDist) return false;
        }
        return true;
    }

    // -------------------------------------------------------------------------
    // Clear all (shutdown)
    // -------------------------------------------------------------------------

    public static void clear() {
        activeZones.clear();
        zoneEntities.clear();
        chunkToZoneKey.clear();
        dimToZoneKeys.clear();
    }

    // -------------------------------------------------------------------------
    // Persistence — save / load zones.dat
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(1); // version
            out.writeInt(activeZones.size());
            for (Map.Entry<String, InfestationZone> entry : activeZones.entrySet()) {
                String key = entry.getKey();
                InfestationZone zone = entry.getValue();
                InfestationEntity entity = zoneEntities.get(key);
                if (entity == null) continue;

                // Determine dim from key (dim:originX:originZ) — dim may contain colons itself
                // Store the full key so we can reconstruct on load
                out.writeUTF(key);
                out.writeInt(zone.getOriginX());
                out.writeInt(zone.getOriginZ());
                // InfestationEntity fields
                out.writeInt(entity.getPopulation());
                out.writeInt(entity.getSpawnReserve());
                out.writeBoolean(entity.isActive());
                out.writeBoolean(entity.isMarkedForDestruction());
                out.writeLong(entity.getLastActivityTime());
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved {} infestation zones.", activeZones.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save zone registry", e);
        }
    }

    private static void load() {
        if (server == null) return;
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int version = in.readInt();
            int count = in.readInt();
            for (int i = 0; i < count; i++) {
                String key       = in.readUTF();
                int originX      = in.readInt();
                int originZ      = in.readInt();
                int population   = in.readInt();
                int reserve      = in.readInt();
                boolean active   = in.readBoolean();
                boolean marked   = in.readBoolean();
                long lastAct     = in.readLong();

                InfestationZone zone = new InfestationZone(originX, originZ);
                InfestationEntity entity = new InfestationEntity(population, reserve, active, marked, lastAct);

                activeZones.put(key, zone);
                zoneEntities.put(key, entity);

                // Reconstruct dim from key (key format: dim:originX:originZ)
                String dim = extractDim(key);

                dimToZoneKeys.computeIfAbsent(dim, d -> ConcurrentHashMap.newKeySet()).add(key);
                for (int[] chunk : zone.getAllChunks()) {
                    chunkToZoneKey.put(chunkKey(dim, chunk[0], chunk[1]), key);
                }
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded {} infestation zones.", activeZones.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load zone registry", e);
        }
    }
}
