package com.worldhordes.mod.data;

import com.worldhordes.mod.config.WorldHordesConfig;

/**
 * Represents the shared, zone-level population state of a single infestation.
 * The entire 4×4 zone (2×2 core + 1-chunk outer ring) shares ONE InfestationEntity.
 *
 * COMBAT LOCK: while the den is in active combat (a player has recently killed a zombie
 * inside it) natural spawn growth and regen are suppressed.  This prevents players from
 * fighting a den only to have it immediately regrow from natural spawns during the fight.
 */
public class InfestationEntity {

    private int population;
    private int spawnReserve;
    private boolean active;
    private boolean markedForDestruction;
    private long lastActivityTime;

    /**
     * Timestamp (System.currentTimeMillis) of the last player kill inside this den.
     * While (now - lastCombatTime) < COMBAT_LOCK_MS the den is "in combat" and will
     * not accept natural spawn growth or regen.
     */
    private long lastCombatTime = 0L;

    /** How long (ms) the den stays in combat-lock after the last player kill. 30 seconds. */
    private static final long COMBAT_LOCK_MS = 30_000L;

    private int lastDensityContribution = 0;
    private String zoneKey = null;

    public void setZoneKey(String key) { this.zoneKey = key; }
    public String getZoneKey() { return zoneKey; }

    // -------------------------------------------------------------------------

    public InfestationEntity(int initialPopulation) {
        this.population           = initialPopulation;
        this.spawnReserve         = initialPopulation;
        this.active               = false;
        this.markedForDestruction = false;
        this.lastActivityTime     = System.currentTimeMillis();
    }

    public InfestationEntity(int population, int spawnReserve, boolean active,
                              boolean markedForDestruction, long lastActivityTime) {
        this.population           = population;
        this.spawnReserve         = spawnReserve;
        this.active               = active;
        this.markedForDestruction = markedForDestruction;
        this.lastActivityTime     = lastActivityTime;
    }

    // -------------------------------------------------------------------------
    // Combat lock
    // -------------------------------------------------------------------------

    /** True if a player has killed a zombie here recently (within COMBAT_LOCK_MS). */
    public boolean isInCombat() {
        return (System.currentTimeMillis() - lastCombatTime) < COMBAT_LOCK_MS;
    }

    /** Refresh the combat timer. Called every time a player kills a zombie in this den. */
    public void markCombat() {
        lastCombatTime = System.currentTimeMillis();
    }

    /** Remaining combat-lock ms (0 if not in combat). */
    public long getCombatLockRemainingMs() {
        long remaining = COMBAT_LOCK_MS - (System.currentTimeMillis() - lastCombatTime);
        return Math.max(0, remaining);
    }

    // -------------------------------------------------------------------------
    // Population mutation
    // -------------------------------------------------------------------------

    /**
     * Natural zombie spawn within the zone increases shared population.
     * BLOCKED while the den is in combat to prevent active regen during a fight.
     */
    public void onNaturalSpawn(int amount) {
        if (isInCombat()) return; // combat lock — no growth during active fight

        int effective = (zoneKey != null)
                ? com.worldhordes.mod.data.NaturalSpawnGatekeeper.tryDenContribute(zoneKey, amount)
                : amount;
        if (effective <= 0) return;
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        population   = Math.min(population + effective, max);
        spawnReserve = Math.min(spawnReserve + effective, max);
        lastActivityTime = System.currentTimeMillis();
    }

    /**
     * Player kill reduces shared population, refreshes combat lock, and checks destroy threshold.
     * Returns true if the population just fell below the destroy threshold.
     */
    public boolean onZombieKilledByPlayer(int decayPerKill) {
        markCombat(); // refresh combat lock on every player kill
        population   = Math.max(0, population - decayPerKill);
        spawnReserve = Math.max(0, spawnReserve - 1);
        lastActivityTime = System.currentTimeMillis();
        int threshold = WorldHordesConfig.COMMON.infestationDestroyThreshold.get();
        if (population <= threshold && !markedForDestruction) {
            markedForDestruction = true;
            return true;
        }
        return false;
    }

    /**
     * Passive regen tick — also blocked during combat so players clearing a den
     * don't watch it refill in real-time while they fight.
     */
    public void applyRegen(int regenAmount) {
        if (markedForDestruction) return;
        if (isInCombat()) return; // combat lock — no regen during active fight

        int effective = (zoneKey != null)
                ? com.worldhordes.mod.data.NaturalSpawnGatekeeper.tryDenContribute(zoneKey, regenAmount)
                : regenAmount;
        if (effective <= 0) return;
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        population   = Math.min(population + effective, max);
        spawnReserve = Math.min(spawnReserve + effective / 2 + 1, max);
    }

    // -------------------------------------------------------------------------
    // Wave spawning
    // -------------------------------------------------------------------------

    public int drawFromReserve(int count) {
        int drawn = Math.min(count, spawnReserve);
        spawnReserve = Math.max(0, spawnReserve - drawn);
        return drawn;
    }

    public void returnToReserve(int count) {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        spawnReserve = Math.min(spawnReserve + count, max);
    }

    public void refillReserve() {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        int cap = Math.max(1, population / 2);
        if (spawnReserve < cap) {
            spawnReserve = Math.min(cap, spawnReserve + Math.max(1, population / 10));
            spawnReserve = Math.min(spawnReserve, max);
        }
    }

    // -------------------------------------------------------------------------
    // Global density contribution
    // -------------------------------------------------------------------------

    public int computeDensityContribution() {
        return active ? Math.max(1, population / 10) : 0;
    }

    public int computeDensityDelta() {
        int current = computeDensityContribution();
        int delta = current - lastDensityContribution;
        lastDensityContribution = current;
        return delta;
    }

    public int getLastDensityContribution() { return lastDensityContribution; }

    // -------------------------------------------------------------------------
    // State queries
    // -------------------------------------------------------------------------

    public int     getPopulation()            { return population; }
    public int     getSpawnReserve()          { return spawnReserve; }
    public boolean isActive()                 { return active; }
    public boolean isMarkedForDestruction()   { return markedForDestruction; }
    public long    getLastActivityTime()      { return lastActivityTime; }

    public void setActive(boolean active)     { this.active = active; }
    public void setPopulation(int pop)        { this.population = Math.max(0, pop); }
}
