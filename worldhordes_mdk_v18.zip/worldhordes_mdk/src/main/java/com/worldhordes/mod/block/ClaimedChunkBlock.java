package com.worldhordes.mod.block;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.List;

/**
 * The Claimed Chunk Block — a placeable marker that suppresses zombie and
 * hostile mob spawns in the chunk it occupies.
 *
 * Earning: Players receive one token each time they fully clear an infested zone.
 * Placing: They craft / receive this block and place it anywhere.
 *   - Immediately registers the chunk as "claimed" in PlayerClaimedChunkManager.
 *   - Zombies (and hostile mobs) cannot spawn naturally in that chunk.
 * Lifting: Break the block manually, or a zombie that walks into the chunk and
 *   despawns there will lift the claim automatically (the block pops as a drop).
 *
 * The block is visually a flat marker (thin slab) so it's unobtrusive.
 */
public class ClaimedChunkBlock extends Block {

    /** 1-pixel-tall flat marker shape */
    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 1, 16);

    public ClaimedChunkBlock() {
        super(BlockBehaviour.Properties.of()
                .mapColor(MapColor.EMERALD)
                .strength(1.5f, 6.0f)
                .sound(SoundType.STONE)
                .noOcclusion()
                .requiresCorrectToolForDrops());
    }

    @Override
    @SuppressWarnings("deprecation")
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    // -------------------------------------------------------------------------
    // Registration / deregistration
    // -------------------------------------------------------------------------

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!(level instanceof ServerLevel serverLevel)) return;

        String dim = DimUtil.getDim(serverLevel);
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;

        boolean fresh = PlayerClaimedChunkManager.claimChunk(dim, cx, cz);
        if (fresh) {
            WorldHordesMod.LOGGER.info("[WorldHordes] Claimed Chunk Block placed at ({}) — chunk ({},{}) claimed.",
                    pos, cx, cz);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        super.onRemove(state, level, pos, newState, isMoving);
        if (!(level instanceof ServerLevel serverLevel)) return;
        if (state.is(newState.getBlock())) return; // same block, just update — skip

        String dim = DimUtil.getDim(serverLevel);
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;
        PlayerClaimedChunkManager.unclaimChunk(dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Item tooltip
    // -------------------------------------------------------------------------

    @Override
    public void appendHoverText(ItemStack stack, BlockGetter level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.literal("§aPlace in any chunk to claim it."));
        tooltip.add(Component.literal("§7Prevents zombie and hostile mob spawns inside."));
        tooltip.add(Component.literal("§7Earned by fully clearing infested zones."));
        tooltip.add(Component.literal("§cBreaking the block releases the claim."));
    }
}
