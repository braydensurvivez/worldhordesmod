package com.worldhordes.mod.data;

/**
 * Represents a single infestation zone — an 8×8 chunk area that acts as a single entity.
 *
 * Layout (each cell = 1 chunk, zone is 8×8 = 64 chunks total):
 * <pre>
 *   O O O O O O O O
 *   O O O O O O O O
 *   O O C C C C O O
 *   O O C C C C O O
 *   O O C C C C O O
 *   O O C C C C O O
 *   O O O O O O O O
 *   O O O O O O O O
 * </pre>
 * C = Core Zone  (4×4 = 16 chunks in the centre)
 * O = Outer Ring (remaining 48 chunks forming the border)
 *
 * The "origin" stored here is the top-left corner of the 8×8 zone.
 * Core starts at (originX+2, originZ+2) and spans to (originX+5, originZ+5).
 *
 * ALL 64 chunks share ONE InfestationEntity and display that entity's member count.
 */
public class InfestationZone {

    /** Top-left chunk of the 8×8 zone. */
    private final int originX;
    private final int originZ;

    /** Zone size (8×8). */
    public static final int ZONE_SIZE = 8;

    /** Core offset from origin (starts at offset 2, ends at offset 5 inclusive). */
    private static final int CORE_START = 2;
    private static final int CORE_END   = 5;

    public InfestationZone(int originX, int originZ) {
        this.originX = originX;
        this.originZ = originZ;
    }

    /**
     * Creates an InfestationZone centred as close as possible to (centreX, centreZ).
     * The 8×8 zone's centre is at (originX+3, originZ+3) (between chunks 3 and 4).
     * So originX = centreX - 3, originZ = centreZ - 3.
     */
    public static InfestationZone centredAt(int centreX, int centreZ) {
        return new InfestationZone(centreX - 3, centreZ - 3);
    }

    public int getOriginX() { return originX; }
    public int getOriginZ() { return originZ; }

    /** Centre chunk X of the 8×8 zone (for distance checks). */
    public int getZoneCentreX() { return originX + 3; }
    /** Centre chunk Z of the 8×8 zone (for distance checks). */
    public int getZoneCentreZ() { return originZ + 3; }

    /** Returns true if (cx, cz) is one of the 16 Core Zone chunks. */
    public boolean isCore(int cx, int cz) {
        int dx = cx - originX;
        int dz = cz - originZ;
        return dx >= CORE_START && dx <= CORE_END && dz >= CORE_START && dz <= CORE_END;
    }

    /** Returns true if (cx, cz) is in the Outer Ring (the border around the core inside the 8×8). */
    public boolean isOuterRing(int cx, int cz) {
        int dx = cx - originX;
        int dz = cz - originZ;
        if (dx < 0 || dx >= ZONE_SIZE || dz < 0 || dz >= ZONE_SIZE) return false;
        return !isCore(cx, cz);
    }

    /** Returns true if (cx, cz) is anywhere within this zone (core or ring). */
    public boolean contains(int cx, int cz) {
        int dx = cx - originX;
        int dz = cz - originZ;
        return dx >= 0 && dx < ZONE_SIZE && dz >= 0 && dz < ZONE_SIZE;
    }

    /**
     * Returns ZoneRole for (cx, cz): CORE, OUTER_RING, or NONE.
     */
    public ZoneRole roleOf(int cx, int cz) {
        if (isCore(cx, cz)) return ZoneRole.CORE;
        if (isOuterRing(cx, cz)) return ZoneRole.OUTER_RING;
        return ZoneRole.NONE;
    }

    public enum ZoneRole {
        CORE,
        OUTER_RING,
        NONE
    }

    /**
     * Lists all 16 core chunk positions as int[]{cx, cz} pairs.
     */
    public int[][] getCoreChunks() {
        int count = (CORE_END - CORE_START + 1) * (CORE_END - CORE_START + 1); // 4×4 = 16
        int[][] result = new int[count][2];
        int idx = 0;
        for (int dx = CORE_START; dx <= CORE_END; dx++) {
            for (int dz = CORE_START; dz <= CORE_END; dz++) {
                result[idx][0] = originX + dx;
                result[idx][1] = originZ + dz;
                idx++;
            }
        }
        return result;
    }

    /**
     * Lists all outer ring chunk positions (48 chunks) as int[]{cx, cz} pairs.
     */
    public int[][] getOuterRingChunks() {
        int total = ZONE_SIZE * ZONE_SIZE - (CORE_END - CORE_START + 1) * (CORE_END - CORE_START + 1); // 64 - 16 = 48
        int[][] result = new int[total][2];
        int idx = 0;
        for (int dx = 0; dx < ZONE_SIZE; dx++) {
            for (int dz = 0; dz < ZONE_SIZE; dz++) {
                int cx = originX + dx;
                int cz = originZ + dz;
                if (!isCore(cx, cz)) {
                    result[idx][0] = cx;
                    result[idx][1] = cz;
                    idx++;
                }
            }
        }
        return result;
    }

    /**
     * Lists all 64 chunks in this zone (core + ring).
     */
    public int[][] getAllChunks() {
        int[][] result = new int[ZONE_SIZE * ZONE_SIZE][2];
        int idx = 0;
        for (int dx = 0; dx < ZONE_SIZE; dx++) {
            for (int dz = 0; dz < ZONE_SIZE; dz++) {
                result[idx][0] = originX + dx;
                result[idx][1] = originZ + dz;
                idx++;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "InfestationZone{8x8, origin=(" + originX + "," + originZ + "), centre=("
                + getZoneCentreX() + "," + getZoneCentreZ() + ")}";
    }
}
