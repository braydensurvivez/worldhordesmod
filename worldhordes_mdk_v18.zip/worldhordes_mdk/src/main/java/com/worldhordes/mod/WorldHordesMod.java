package com.worldhordes.mod;

import com.worldhordes.mod.capability.ChunkInfestationCapability;
import com.worldhordes.mod.client.ClientEventHandler;
import com.worldhordes.mod.client.InfestationOverlayRenderer;
import com.worldhordes.mod.command.WorldHordesCommand;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;
import com.worldhordes.mod.events.EntityEventHandler;
import com.worldhordes.mod.events.SpawnEventHandler;
import com.worldhordes.mod.events.WorldEventHandler;
import com.worldhordes.mod.horde.HordeManager;
import com.worldhordes.mod.registry.ModBlocks;
import com.worldhordes.mod.registry.ModCapabilities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(WorldHordesMod.MOD_ID)
public class WorldHordesMod {

    public static final String MOD_ID = "worldhordes";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public WorldHordesMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        modEventBus.addListener(this::commonSetup);

        // Register config via the mod event bus context (Forge 47+ style)
        context.registerConfig(ModConfig.Type.COMMON, WorldHordesConfig.COMMON_SPEC, "worldhordes-common.toml");

        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new EntityEventHandler());
        MinecraftForge.EVENT_BUS.register(new SpawnEventHandler());
        MinecraftForge.EVENT_BUS.register(new WorldEventHandler());

        // Client-only: overlay renderer and keybind handler
        if (FMLEnvironment.dist == Dist.CLIENT) {
            MinecraftForge.EVENT_BUS.register(new InfestationOverlayRenderer());
            MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
        }

        ModCapabilities.register(modEventBus);
        ModBlocks.register(modEventBus);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("[WorldHordes] Common setup complete.");
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        WorldHordesCommand.register(event.getDispatcher());
        LOGGER.info("[WorldHordes] Registered /worldhordes debug commands.");
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("[WorldHordes] Server starting - initializing horde ecosystem...");
        HordeManager.init(event.getServer());
        InfestationZoneRegistry.init(event.getServer());
        InfestationData.init(event.getServer());
        HordeDensityManager.init(event.getServer());
        PlayerClaimedChunkManager.init(event.getServer());
    }

    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        LOGGER.info("[WorldHordes] Server stopping - saving horde data...");
        InfestationData.save(event.getServer());
        HordeDensityManager.save(event.getServer());
        HordeManager.save(event.getServer());
        PlayerClaimedChunkManager.save(event.getServer());
    }
}
