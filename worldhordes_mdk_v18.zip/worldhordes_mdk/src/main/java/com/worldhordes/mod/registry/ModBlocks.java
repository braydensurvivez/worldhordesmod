package com.worldhordes.mod.registry;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.block.BloodSplatterBlock;
import com.worldhordes.mod.block.ClaimedChunkBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, WorldHordesMod.MOD_ID);

    /**
     * Blood splatter decal blocks — one registered block with VARIANT blockstate property.
     * The same block class handles all variants; texture is selected by the blockstate model.
     */
    public static final RegistryObject<BloodSplatterBlock> BLOOD_SPLATTER =
            BLOCKS.register("blood_splatter", BloodSplatterBlock::new);

    /**
     * Player Claimed Chunk Block — earned by clearing infested zones.
     * When placed, suppresses zombie and hostile mob spawns in the chunk it occupies.
     */
    public static final RegistryObject<ClaimedChunkBlock> CLAIMED_CHUNK =
            BLOCKS.register("claimed_chunk", ClaimedChunkBlock::new);

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
    }
}
