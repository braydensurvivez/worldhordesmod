package com.worldhordes.mod.horde;

import java.util.UUID;

public class WanderingHorde {

    private final UUID id;
    private String dimension;
    private int chunkX;
    private int chunkZ;
    private int size;
    private int targetChunkX;
    private int targetChunkZ;
    private long lastMoveTick;
    private boolean isSettled;
    private int wanderDirection; // 0=N, 1=E, 2=S, 3=W, -1=random each step
    private int stepsTaken;
    private int maxSteps;

    /**
     * The dedicated member pool for this horde.
     * Zombies are drawn from here when the horde spawns into the world.
     * Unlike {@code size} (encounter/wander count), memberCount tracks
     * how many physical zombies this horde can still deploy.
     */
    private int memberCount;

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    public WanderingHorde(String dimension, int chunkX, int chunkZ, int size) {
        this.id              = UUID.randomUUID();
        this.dimension       = dimension;
        this.chunkX          = chunkX;
        this.chunkZ          = chunkZ;
        this.size            = size;
        this.memberCount     = size; // member pool starts equal to horde size
        this.targetChunkX    = chunkX;
        this.targetChunkZ    = chunkZ;
        this.lastMoveTick    = 0;
        this.isSettled       = false;
        this.wanderDirection = -1;
        this.stepsTaken      = 0;
        this.maxSteps        = 20 + (int)(Math.random() * 30);
    }

    /** Full deserialization constructor (includes memberCount). */
    public WanderingHorde(UUID id, String dimension, int chunkX, int chunkZ, int size,
                          int targetX, int targetZ, long lastMove, boolean settled,
                          int dir, int steps, int maxSteps, int memberCount) {
        this.id              = id;
        this.dimension       = dimension;
        this.chunkX          = chunkX;
        this.chunkZ          = chunkZ;
        this.size            = size;
        this.memberCount     = memberCount;
        this.targetChunkX    = targetX;
        this.targetChunkZ    = targetZ;
        this.lastMoveTick    = lastMove;
        this.isSettled       = settled;
        this.wanderDirection = dir;
        this.stepsTaken      = steps;
        this.maxSteps        = maxSteps;
    }

    // -------------------------------------------------------------------------
    // Member pool
    // -------------------------------------------------------------------------

    /** How many members remain available to deploy. */
    public int getMemberCount() { return memberCount; }

    /**
     * Draw up to {@code count} members from the pool.
     * Returns the actual number drawn (may be less if pool is low).
     */
    public int drawMembers(int count) {
        int drawn = Math.min(count, memberCount);
        memberCount = Math.max(0, memberCount - drawn);
        return drawn;
    }

    /** Return members to the pool (e.g. despawned without being killed). */
    public void returnMembers(int count) {
        memberCount = Math.min(memberCount + count, size); // never exceed original size
    }

    public boolean hasMembersLeft() { return memberCount > 0; }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public UUID    getId()            { return id; }
    public String  getDimension()     { return dimension; }
    public int     getChunkX()        { return chunkX; }
    public int     getChunkZ()        { return chunkZ; }
    public int     getSize()          { return size; }
    public int     getTargetChunkX()  { return targetChunkX; }
    public int     getTargetChunkZ()  { return targetChunkZ; }
    public long    getLastMoveTick()  { return lastMoveTick; }
    public boolean isSettled()        { return isSettled; }
    public int     getWanderDirection(){ return wanderDirection; }
    public int     getStepsTaken()    { return stepsTaken; }
    public int     getMaxSteps()      { return maxSteps; }

    // -------------------------------------------------------------------------
    // Setters
    // -------------------------------------------------------------------------

    public void setChunkX(int x)          { this.chunkX = x; }
    public void setChunkZ(int z)          { this.chunkZ = z; }
    public void setSize(int size)         { this.size = Math.max(0, size); }
    public void setTargetChunkX(int x)    { this.targetChunkX = x; }
    public void setTargetChunkZ(int z)    { this.targetChunkZ = z; }
    public void setLastMoveTick(long tick){ this.lastMoveTick = tick; }
    public void setSettled(boolean s)     { this.isSettled = s; }
    public void setWanderDirection(int d) { this.wanderDirection = d; }
    public void incrementSteps()          { this.stepsTaken++; }
    public void setStepsTaken(int steps)  { this.stepsTaken = steps; }
    public void setMaxSteps(int max)      { this.maxSteps = max; }

    // -------------------------------------------------------------------------
    // State checks
    // -------------------------------------------------------------------------

    public boolean hasExhausted() { return stepsTaken >= maxSteps; }

    /**
     * A horde is depleted when its wandering size hits 0 OR its member pool
     * is fully consumed — whichever comes first.
     */
    public boolean isDepleted() { return size <= 0 || memberCount <= 0; }

    public void shrink(int amount) {
        size = Math.max(0, size - amount);
    }

    // -------------------------------------------------------------------------
    // Movement
    // -------------------------------------------------------------------------

    public int[] nextChunkPosition(int chunksPerStep) {
        java.util.Random rand = new java.util.Random();
        int dir = wanderDirection == -1 ? rand.nextInt(4) : wanderDirection;
        int nx = chunkX;
        int nz = chunkZ;
        switch (dir) {
            case 0 -> nz -= chunksPerStep;
            case 1 -> nx += chunksPerStep;
            case 2 -> nz += chunksPerStep;
            case 3 -> nx -= chunksPerStep;
        }
        if (rand.nextInt(4) == 0) wanderDirection = rand.nextInt(4);
        return new int[]{nx, nz};
    }

    @Override
    public String toString() {
        return String.format(
                "WanderingHorde[%s, dim=%s, chunk=(%d,%d), size=%d, members=%d, steps=%d/%d, settled=%b]",
                id.toString().substring(0, 8), dimension, chunkX, chunkZ,
                size, memberCount, stepsTaken, maxSteps, isSettled);
    }
}
