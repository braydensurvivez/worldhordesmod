package com.worldhordes.mod.horde;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationEntity;
import com.worldhordes.mod.data.InfestationZone;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.data.LiveZombieTracker;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class HordeManager {

    private static final List<WanderingHorde> activeHordes = new CopyOnWriteArrayList<>();
    private static MinecraftServer server;
    private static long lastHordeSpawnTick    = 0;
    private static long lastHordeMigrationTick = 0;
    private static long lastInfestSpawnTick   = 0;
    /** Tick at which a combat-pause was last triggered. 0 = no pause active. */
    private static long combatPauseUntilTick  = 0;

    private static final String SAVE_FILE = "worldhordes_hordes.dat";
    private static final Random RAND = new Random();

    // -------------------------------------------------------------------------
    // Wave spawn constants
    // -------------------------------------------------------------------------

    /**
     * Number of zombies per assault wave spawned 1 chunk away from the player.
     * Per the design spec: 30 waves × this many zombies each pulse.
     */
    private static final int ASSAULT_WAVE_SIZE = 30;

    /**
     * Waves per pulse: each time the spawn pulse fires while the player is inside
     * a zone, 30 waves of ASSAULT_WAVE_SIZE zombies are sent.
     */
    private static final int WAVES_PER_PULSE = 30;

    /**
     * Cooldown between wave pulses in ticks. 40 seconds = 800 ticks.
     */
    private static final int WAVE_COOLDOWN_TICKS = 800;

    /**
     * Fraction of the zone's member count to passively spawn when a player
     * first loads a chunk in the zone. 0.10 = 10 %.
     */
    private static final float PASSIVE_LOAD_FRACTION = 0.10f;

    /** Chunk distance beyond which far zombies are recalled (converted to reserve). */
    private static final int FAR_ZOMBIE_CHUNK_DIST = 2;

    /** Minimum group size (kept for pre-pop compat). */
    private static final int GROUP_MIN = 2;
    /** Maximum group size (kept for pre-pop compat). */
    private static final int GROUP_MAX = 5;

    // -------------------------------------------------------------------------
    // Per-zone wave cooldown tracking
    // Keyed by zoneKey → game tick of last wave sent.
    // -------------------------------------------------------------------------
    private static final Map<String, Long> zoneLastWaveTick = new HashMap<>();

    // -------------------------------------------------------------------------

    /** Set of zone keys that have already been pre-populated on load. */
    private static final Set<String> prePoppedZones = new java.util.HashSet<>();

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        LiveZombieTracker.reset();
        load();
    }

    public static List<WanderingHorde> getActiveHordes() { return Collections.unmodifiableList(activeHordes); }
    public static MinecraftServer getServer() { return server; }

    // -------------------------------------------------------------------------
    // Main tick
    // -------------------------------------------------------------------------

    public static void tick(long gameTick) {
        HordeDensityManager.tick();
        InfestationData.tick();

        int spawnInterval = WorldHordesConfig.COMMON.hordeSpawnIntervalTicks.get();
        if (gameTick - lastHordeSpawnTick >= spawnInterval) {
            lastHordeSpawnTick = gameTick;
            trySpawnHorde();
        }

        int moveInterval = WorldHordesConfig.COMMON.hordeMoveCooldownTicks.get();
        if (gameTick - lastHordeMigrationTick >= moveInterval) {
            lastHordeMigrationTick = gameTick;
            tickHordeMigration();
        }

        // Infested-zone spawn pulse: runs continuously; per-zone cooldown enforced inside.
        int pulseInterval = WorldHordesConfig.COMMON.infestationChunkSpawnPulseTicks.get();
        if (gameTick - lastInfestSpawnTick >= pulseInterval) {
            lastInfestSpawnTick = gameTick;
            tickInfestationSpawns(gameTick);
        }

        activeHordes.removeIf(h -> {
            if (h.isDepleted()) {
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} depleted and removed.", h.getId().toString().substring(0,8));
                return true;
            }
            return false;
        });
    }

    // -------------------------------------------------------------------------
    // Horde spawning
    // -------------------------------------------------------------------------

    private static void trySpawnHorde() {
        int maxHordes = WorldHordesConfig.COMMON.maxActiveHordes.get();
        if (activeHordes.size() >= maxHordes) return;
        if (!HordeDensityManager.isAboveHordeThreshold()) return;

        ServerLevel overworld = server.getLevel(Level.OVERWORLD);
        if (overworld == null) return;
        List<net.minecraft.world.entity.player.Player> players = new ArrayList<>(overworld.players());
        if (players.isEmpty()) return;

        net.minecraft.world.entity.player.Player player = players.get(RAND.nextInt(players.size()));
        BlockPos playerPos = player.blockPosition();

        int offsetX = (80 + RAND.nextInt(70)) * (RAND.nextBoolean() ? 1 : -1);
        int offsetZ = (80 + RAND.nextInt(70)) * (RAND.nextBoolean() ? 1 : -1);
        int spawnChunkX = (playerPos.getX() >> 4) + (offsetX / 16);
        int spawnChunkZ = (playerPos.getZ() >> 4) + (offsetZ / 16);

        if (!InfestationData.isRegionDistanceValid(DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ)) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug("[WorldHordes] Horde spawn rejected — too close to existing infested region.");
            }
            return;
        }

        int minSize = WorldHordesConfig.COMMON.hordeMinSize.get();
        int maxSize = WorldHordesConfig.COMMON.hordeMaxSize.get();
        int size    = minSize + RAND.nextInt(Math.max(1, maxSize - minSize));

        int density   = HordeDensityManager.getDensity();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        float densityScale = Math.min(3.0f, (float) density / threshold);
        size = (int)(size * densityScale);
        size = Math.max(minSize, Math.min(size, maxSize));

        WanderingHorde horde = new WanderingHorde(DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ, size);
        activeHordes.add(horde);

        int arrivalBonus = WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get();
        InfestationZone zone = InfestationData.seedInfestationRegion(
                DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ,
                size + arrivalBonus);

        if (zone == null) {
            WorldHordesMod.LOGGER.info("[WorldHordes] Zone rejected — horde {} will wander without settling.",
                    horde.getId().toString().substring(0, 8));
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Spawned {} [size={}] at chunk ({},{}). Active hordes: {}",
                horde, size, spawnChunkX, spawnChunkZ, activeHordes.size());
    }

    // -------------------------------------------------------------------------
    // Horde migration
    // -------------------------------------------------------------------------

    private static void tickHordeMigration() {
        int chunksPerMove  = WorldHordesConfig.COMMON.hordeChunksPerMove.get();
        double settleChance = WorldHordesConfig.COMMON.hordeEnterInfestedChunkChance.get();

        for (WanderingHorde horde : activeHordes) {
            if (horde.isSettled()) {
                if (RAND.nextInt(20) == 0) {
                    horde.setSettled(false);
                    WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} moving again from ({},{})",
                            horde.getId().toString().substring(0,8), horde.getChunkX(), horde.getChunkZ());
                }
                continue;
            }

            int[] next = horde.nextChunkPosition(chunksPerMove);
            int nx = next[0], nz = next[1];
            horde.setChunkX(nx); horde.setChunkZ(nz); horde.incrementSteps();

            ChunkInfestationLevel newInf = InfestationData.getOrCreate(horde.getDimension(), nx, nz);

            int existingInfest = InfestationData.getLevel(horde.getDimension(), nx, nz);
            if (existingInfest >= WorldHordesConfig.COMMON.infestationTier2.get()
                    && RAND.nextDouble() < settleChance) {
                horde.setSettled(true);
                newInf.setHasActiveHorde(true);
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} settled in heavily infested chunk ({},{})",
                        horde.getId().toString().substring(0,8), nx, nz);
            }

            if (horde.hasExhausted()) {
                if (RAND.nextBoolean()) { horde.setSettled(true); newInf.setHasActiveHorde(true); }
                else { horde.setSize(0); }
            }

            spawnHordeZombiesNearPlayer(horde);
        }
    }

    // -------------------------------------------------------------------------
    // Infested chunk spawn pulses
    //
    // BEHAVIOUR:
    //
    //   ZONE SIZE      : 4×4 chunks total, 2×2 core, 1-chunk outer ring.
    //
    //   WAVE TRIGGER   : When a player steps into any chunk belonging to an
    //                    infestation zone, attack status is set and a wave
    //                    fires immediately from that zone (subject to the 40-second
    //                    per-zone cooldown). Waves continue to fire every time
    //                    the pulse runs while the player remains inside.
    //
    //   WAVE SIZE      : 30 waves × ASSAULT_WAVE_SIZE (30) = up to 900 zombies drawn
    //                    from the zone reserve per pulse, spread over 30 iterations.
    //                    Zombies spawn in chunks exactly 1 chunk away from the player.
    //
    //   PLAYER Y AXIS  : ALL zombies are forced to spawn at the same Y level as
    //                    the player (±8 block scan). No surface-only spawning during
    //                    assault waves — they must engage at the player's floor.
    //
    //   LIGHT AGNOSTIC : Assault wave and pre-population spawns ignore light level
    //                    entirely. Zombies spawn in both light and darkness.
    //
    //   WAVE COOLDOWN  : 40 seconds (800 ticks) per zone between wave pulses.
    //
    //   PASSIVE LOAD   : When a player first loads a chunk inside a zone,
    //                    PASSIVE_LOAD_FRACTION (10%) of the zone's current member
    //                    count is passively spawned inside that chunk at player Y.
    //
    //   FAR RECALL     : Tagged zombies > FAR_ZOMBIE_CHUNK_DIST (2) chunks from all
    //                    players are despawned and their slots returned to the reserve.
    // -------------------------------------------------------------------------

    /**
     * Activates infestations, handles passive load spawning, sends assault waves,
     * and recalls far zombies back to reserve.
     */
    private static void tickInfestationSpawns(long gameTick) {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;

        if (LiveZombieTracker.isAtHardCap()) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Spawn pulse skipped — live zombie cap reached ({}/{})",
                        LiveZombieTracker.get(),
                        WorldHordesConfig.COMMON.maxLiveHordeZombies.get());
            }
            return;
        }

        int coreMax  = WorldHordesConfig.COMMON.coreSpawnPerPulse.get();
        int outerMax = WorldHordesConfig.COMMON.outerRingSpawnPerPulse.get();
        String dim   = DimUtil.OVERWORLD_DIM;

        // ---- 1. Update global density from zone populations ----
        int totalZoneDensityDelta = 0;
        for (com.worldhordes.mod.data.InfestationEntity entity
                : InfestationZoneRegistry.getAllEntities().values()) {
            totalZoneDensityDelta += entity.computeDensityDelta();
        }
        if (totalZoneDensityDelta > 0) {
            HordeDensityManager.addDensity(totalZoneDensityDelta);
        } else if (totalZoneDensityDelta < 0) {
            HordeDensityManager.removeDensity(-totalZoneDensityDelta);
        }

        // ---- 2. Recall far zombies back to the zone reserve ----
        {
            int recallRadius = 6;
            Set<Zombie> recallCandidates = new java.util.LinkedHashSet<>();
            for (net.minecraft.world.entity.player.Player p : level.players()) {
                BlockPos pp = p.blockPosition();
                int pcx = pp.getX() >> 4;
                int pcz = pp.getZ() >> 4;
                for (int dx = -recallRadius; dx <= recallRadius; dx++) {
                    for (int dz = -recallRadius; dz <= recallRadius; dz++) {
                        int dist = Math.max(Math.abs(dx), Math.abs(dz));
                        if (dist <= FAR_ZOMBIE_CHUNK_DIST) continue;
                        int rcx = pcx + dx;
                        int rcz = pcz + dz;
                        if (!level.hasChunk(rcx, rcz)) continue;
                        net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(rcx, rcz);
                        int bx = lc.getPos().getMinBlockX();
                        int bz = lc.getPos().getMinBlockZ();
                        net.minecraft.world.phys.AABB chunkBox = new net.minecraft.world.phys.AABB(
                                bx, level.getMinBuildHeight(), bz,
                                bx + 16, level.getMaxBuildHeight(), bz + 16);
                        for (Zombie z : level.getEntitiesOfClass(Zombie.class, chunkBox,
                                zz -> zz.getPersistentData().getBoolean("worldhordes_infest_spawn"))) {
                            recallCandidates.add(z);
                        }
                    }
                }
            }
            for (Zombie z : recallCandidates) {
                int zcx = z.blockPosition().getX() >> 4;
                int zcz = z.blockPosition().getZ() >> 4;
                boolean nearAnyPlayer = false;
                for (net.minecraft.world.entity.player.Player p : level.players()) {
                    int pcx = p.blockPosition().getX() >> 4;
                    int pcz = p.blockPosition().getZ() >> 4;
                    if (Math.abs(zcx - pcx) <= FAR_ZOMBIE_CHUNK_DIST
                            && Math.abs(zcz - pcz) <= FAR_ZOMBIE_CHUNK_DIST) {
                        nearAnyPlayer = true;
                        break;
                    }
                }
                if (nearAnyPlayer) continue;
                int tagCx = z.getPersistentData().getInt("worldhordes_src_cx");
                int tagCz = z.getPersistentData().getInt("worldhordes_src_cz");
                com.worldhordes.mod.data.InfestationEntity farEntity =
                        InfestationZoneRegistry.getEntityFor(dim, tagCx, tagCz);
                if (farEntity != null) {
                    farEntity.returnToReserve(1);
                    farEntity.onZombieRemovedFromChunk();
                }
                LiveZombieTracker.onRemove();
                z.getPersistentData().putBoolean("worldhordes_infest_spawn", false);
                z.discard();
            }
        }

        // ---- 3. Per-player: activate zones, passive load, assault waves ----
        for (net.minecraft.world.entity.player.Player player : level.players()) {
            BlockPos playerPos = player.blockPosition();
            int playerCx = playerPos.getX() >> 4;
            int playerCz = playerPos.getZ() >> 4;

            // Deduplicate per-zone processing this pulse
            Set<com.worldhordes.mod.data.InfestationEntity> processedThisPulse = new java.util.HashSet<>();

            // Search radius to cover the full 4×4 zone plus 1-chunk buffer
            int searchRadius = 5;
            for (int dx = -searchRadius; dx <= searchRadius; dx++) {
                for (int dz = -searchRadius; dz <= searchRadius; dz++) {
                    int cx = playerCx + dx;
                    int cz = playerCz + dz;
                    if (!level.hasChunk(cx, cz)) continue;

                    com.worldhordes.mod.data.InfestationEntity entity =
                            InfestationZoneRegistry.getEntityFor(dim, cx, cz);
                    if (entity == null || entity.isMarkedForDestruction()) continue;

                    ChunkInfestationLevel chunkState = InfestationData.get(dim, cx, cz);
                    if (chunkState != null && chunkState.isCleared()) continue;
                    if (PlayerClaimedChunkManager.isChunkClaimed(dim, cx, cz)) continue;

                    // ---- Activate zone on first player entry ----
                    if (!entity.isActive()) {
                        entity.setActive(true);
                        WorldHordesMod.LOGGER.info(
                                "[WorldHordes] Infestation zone activated by player entry at ({},{}). Pop={}",
                                cx, cz, entity.getPopulation());
                        placeInitialBloodDecals(level, dim, cx, cz);
                    }

                    // ---- Attack status: mark when player is inside any chunk of the zone ----
                    // Always fetch fresh zone reference for this chunk
                    InfestationZone activeZone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
                    // Player is inside the zone if their chunk is part of this zone
                    if (activeZone != null && activeZone.contains(playerCx, playerCz)) {
                        entity.onPlayerEntered();
                    }
                    // Also trigger attack status if the player is standing on a chunk that IS this zone
                    // (catches cases where the zone lookup for the player's chunk returns the same entity)
                    if (entity == InfestationZoneRegistry.getEntityFor(dim, playerCx, playerCz)) {
                        entity.onPlayerEntered();
                    }

                    // ---- Pre-populate zone chunks once on first zone load ----
                    String zoneKey = entity.getZoneKey();
                    if (zoneKey != null && !prePoppedZones.contains(zoneKey)
                            && entity.getSpawnReserve() > 0) {
                        InfestationZone zone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
                        if (zone != null) {
                            prePoppedZones.add(zoneKey);
                            int preSpawned = prePopulateZoneChunks(level, dim, zone, entity, coreMax, outerMax);
                            WorldHordesMod.LOGGER.info(
                                    "[WorldHordes] Pre-populated zone {} with {} zombies inside chunk bounds.",
                                    zoneKey, preSpawned);
                        }
                    }

                    // Avoid processing the same zone entity twice per pulse
                    if (processedThisPulse.contains(entity)) continue;

                    // ---- Passive chunk-load spawn: 10% of zone members when chunk first encountered ----
                    // This fires every pulse for chunks the player is standing on/near — simulates
                    // ambient population already present in loaded chunks.
                    if (entity.isActive() && entity.getPopulation() > 0 && entity.getSpawnReserve() > 0) {
                        int passiveCount = Math.max(1, (int)(entity.getPopulation() * PASSIVE_LOAD_FRACTION));
                        passiveCount = Math.min(passiveCount, entity.getSpawnReserve());
                        // Only fire passive load if not already under a full assault wave
                        if (!entity.isUnderAttack()) {
                            int tagCxP = activeZone != null ? activeZone.getZoneCentreX() : cx;
                            int tagCzP = activeZone != null ? activeZone.getZoneCentreZ() : cz;
                            spawnAtPlayerY(level, dim, playerPos, passiveCount, entity, tagCxP, tagCzP, 1);
                        }
                    }

                    // ---- ASSAULT WAVES: 30 waves of ASSAULT_WAVE_SIZE when player is inside zone ----
                    // Fires every WAVE_COOLDOWN_TICKS (40 seconds) as long as zone is under attack.
                    if (entity.isUnderAttack()
                            && entity.getPopulation() > 0
                            && entity.getSpawnReserve() > 0) {

                        long lastWave = zoneLastWaveTick.getOrDefault(zoneKey != null ? zoneKey : "null", 0L);
                        if (gameTick - lastWave >= WAVE_COOLDOWN_TICKS) {
                            zoneLastWaveTick.put(zoneKey != null ? zoneKey : "null", gameTick);
                            processedThisPulse.add(entity);

                            int tagCx2 = activeZone != null ? activeZone.getZoneCentreX() : cx;
                            int tagCz2 = activeZone != null ? activeZone.getZoneCentreZ() : cz;

                            int totalSpawned = 0;
                            // Spawn half the waves directly inside the infested zone chunks (pressure inside)
                            int innerWaves = WAVES_PER_PULSE / 2;
                            int outerWaves = WAVES_PER_PULSE - innerWaves;
                            InfestationZone waveZone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
                            for (int wave = 0; wave < innerWaves; wave++) {
                                if (entity.getSpawnReserve() <= 0) break;
                                if (LiveZombieTracker.isAtHardCap()) break;
                                // Spawn inside the zone: pick a random core or ring chunk
                                int waveSpawned = 0;
                                if (waveZone != null) {
                                    int[][] allChunks = waveZone.getAllChunks();
                                    int[] targetChunk = allChunks[RAND.nextInt(allChunks.length)];
                                    waveSpawned = spawnZombiesInsideChunk(level, dim,
                                            targetChunk[0], targetChunk[1], entity, ASSAULT_WAVE_SIZE);
                                }
                                if (waveSpawned == 0) {
                                    // Fallback to ring-1 if inside spawn fails
                                    waveSpawned = spawnAtPlayerY(level, dim, playerPos,
                                            ASSAULT_WAVE_SIZE, entity, tagCx2, tagCz2, 1);
                                }
                                totalSpawned += waveSpawned;
                            }
                            // Remaining waves come from 1 chunk outside the player (encirclement)
                            for (int wave = 0; wave < outerWaves; wave++) {
                                if (entity.getSpawnReserve() <= 0) break;
                                if (LiveZombieTracker.isAtHardCap()) break;
                                int waveSpawned = spawnAtPlayerY(
                                        level, dim, playerPos,
                                        ASSAULT_WAVE_SIZE, entity,
                                        tagCx2, tagCz2,
                                        1); // exactly 1 chunk away
                                totalSpawned += waveSpawned;
                            }

                            if (totalSpawned > 0) {
                                WorldHordesMod.LOGGER.info(
                                        "[WorldHordes] Assault: {} zombies in {} waves at player ({},{}) from zone {}. Reserve={}",
                                        totalSpawned, WAVES_PER_PULSE, playerCx, playerCz,
                                        zoneKey, entity.getSpawnReserve());
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Spawns {@code count} zombies in chunks exactly {@code ringDist} chunk(s) away from
     * the player, at the SAME Y as the player. No light check — spawns in both light and dark.
     *
     * @param ringDist Chebyshev ring distance (1 = immediately adjacent chunks)
     */
    private static int spawnAtPlayerY(ServerLevel level, String dim,
                                       BlockPos playerPos,
                                       int count,
                                       com.worldhordes.mod.data.InfestationEntity entity,
                                       int tagCx, int tagCz,
                                       int ringDist) {
        if (entity.getSpawnReserve() <= 0) return 0;
        if (LiveZombieTracker.isAtHardCap()) return 0;

        int playerCx = playerPos.getX() >> 4;
        int playerCz = playerPos.getZ() >> 4;
        int playerY  = playerPos.getY();

        int toSpawn = Math.min(count, entity.getSpawnReserve());
        int drawn   = entity.drawFromReserve(toSpawn);
        int spawned = 0;

        // Collect all chunks at the requested Chebyshev ring distance
        List<int[]> ringChunks = new java.util.ArrayList<>();
        for (int ddx = -ringDist; ddx <= ringDist; ddx++) {
            for (int ddz = -ringDist; ddz <= ringDist; ddz++) {
                if (Math.max(Math.abs(ddx), Math.abs(ddz)) == ringDist) {
                    ringChunks.add(new int[]{playerCx + ddx, playerCz + ddz});
                }
            }
        }
        java.util.Collections.shuffle(ringChunks, RAND);

        for (int i = 0; i < drawn; i++) {
            if (LiveZombieTracker.isAtHardCap()) {
                entity.returnToReserve(drawn - i);
                break;
            }
            int[] rc = ringChunks.get(i % ringChunks.size());
            int rcx = rc[0], rcz = rc[1];

            if (!level.hasChunk(rcx, rcz)) continue;
            if (PlayerClaimedChunkManager.isChunkClaimed(dim, rcx, rcz)) continue;

            net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(rcx, rcz);
            int baseX = lc.getPos().getMinBlockX();
            int baseZ = lc.getPos().getMinBlockZ();
            int bx = baseX + RAND.nextInt(16);
            int bz = baseZ + RAND.nextInt(16);

            // Always spawn at the player's Y level — scan ±10 blocks to find a valid floor
            BlockPos spawnPos = findPlayerLevelSpawn(level, bx, playerY, bz);
            if (spawnPos == null) {
                // Fallback: surface spawn only if player-level scan fails (e.g. open sky)
                spawnPos = findAnyValidSpawn(level, bx, bz);
            }
            if (spawnPos != null) {
                Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                zombie.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
                zombie.getPersistentData().putInt("worldhordes_src_cx", tagCx);
                zombie.getPersistentData().putInt("worldhordes_src_cz", tagCz);
                zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                        MobSpawnType.MOB_SUMMONED, null, null);
                level.addFreshEntity(zombie);
                LiveZombieTracker.onSpawn();
                entity.onZombieSpawnedInChunk();
                spawned++;
            }
        }
        if (drawn - spawned > 0) entity.returnToReserve(drawn - spawned);
        return spawned;
    }

    /**
     * Pre-populates all loaded chunks in a zone with zombies spawned INSIDE the chunk bounds.
     * Called once per zone on first activation. Uses player-Y-aware spawn so even pre-pop
     * zombies land at a sensible level.
     */
    private static final int MIN_PREPOP_ZOMBIES = 30;

    private static int prePopulateZoneChunks(ServerLevel level, String dim,
                                              InfestationZone zone,
                                              com.worldhordes.mod.data.InfestationEntity entity,
                                              int coreMax, int outerMax) {
        int corePerChunk  = Math.max(5, coreMax);
        int outerPerChunk = Math.max(2, outerMax);

        int totalSpawned = 0;
        for (int[] chunk : zone.getCoreChunks()) {
            totalSpawned += spawnZombiesInsideChunk(level, dim, chunk[0], chunk[1], entity, corePerChunk);
        }
        for (int[] chunk : zone.getOuterRingChunks()) {
            totalSpawned += spawnZombiesInsideChunk(level, dim, chunk[0], chunk[1], entity, outerPerChunk);
        }

        if (totalSpawned < MIN_PREPOP_ZOMBIES && entity.getSpawnReserve() > 0) {
            int deficit = MIN_PREPOP_ZOMBIES - totalSpawned;
            for (int[] chunk : zone.getCoreChunks()) {
                if (deficit <= 0 || entity.getSpawnReserve() <= 0) break;
                int extra = spawnZombiesInsideChunk(level, dim, chunk[0], chunk[1], entity, deficit);
                totalSpawned += extra;
                deficit -= extra;
            }
        }
        return totalSpawned;
    }

    /**
     * Spawns up to {@code maxCount} zombies at surface-level inside the given chunk.
     * Light-agnostic — used for ambient pre-population, not gated on darkness.
     */
    private static int spawnZombiesInsideChunk(ServerLevel level, String dim,
                                                int chunkX, int chunkZ,
                                                com.worldhordes.mod.data.InfestationEntity entity,
                                                int maxCount) {
        if (!level.hasChunk(chunkX, chunkZ)) return 0;
        if (entity.getSpawnReserve() <= 0) return 0;
        if (PlayerClaimedChunkManager.isChunkClaimed(dim, chunkX, chunkZ)) return 0;
        if (LiveZombieTracker.isAtHardCap()) return 0;

        net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(chunkX, chunkZ);
        int baseX = lc.getPos().getMinBlockX();
        int baseZ = lc.getPos().getMinBlockZ();

        int count = Math.min(maxCount, entity.getSpawnReserve());
        int drawn = entity.drawFromReserve(count);
        int spawned = 0;

        for (int i = 0; i < drawn; i++) {
            if (LiveZombieTracker.isAtHardCap()) {
                entity.returnToReserve(drawn - i);
                break;
            }
            int bx = baseX + RAND.nextInt(16);
            int bz = baseZ + RAND.nextInt(16);
            // Surface spawn for ambient pre-pop (no specific player Y reference)
            BlockPos spawnPos = findAnyValidSpawn(level, bx, bz);
            if (spawnPos != null) {
                Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                zombie.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
                zombie.getPersistentData().putInt("worldhordes_src_cx", chunkX);
                zombie.getPersistentData().putInt("worldhordes_src_cz", chunkZ);
                zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                        MobSpawnType.MOB_SUMMONED, null, null);
                level.addFreshEntity(zombie);
                LiveZombieTracker.onSpawn();
                entity.onZombieSpawnedInChunk();
                spawned++;
            }
        }
        if (drawn - spawned > 0) entity.returnToReserve(drawn - spawned);
        return spawned;
    }

    /**
     * Places initial blood decals when an infestation zone first becomes active.
     */
    private static void placeInitialBloodDecals(ServerLevel level, String dim, int cx, int cz) {
        if (!WorldHordesConfig.COMMON.enableBloodDecals.get()) return;
        InfestationZone zone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
        if (zone == null) return;

        com.worldhordes.mod.registry.ModBlocks.BLOOD_SPLATTER.ifPresent(bloodBlock -> {
            int placed = 0;
            for (int[] chunk : zone.getCoreChunks()) {
                placed += placeDecalsInChunk(level, chunk[0], chunk[1], bloodBlock, 12);
            }
            for (int[] chunk : zone.getOuterRingChunks()) {
                placed += placeDecalsInChunk(level, chunk[0], chunk[1], bloodBlock, 3);
            }
            if (placed > 0) {
                WorldHordesMod.LOGGER.info(
                        "[WorldHordes] Placed {} initial blood decals for infestation zone at ({},{}).", placed, cx, cz);
            }
        });
    }

    private static int placeDecalsInChunk(ServerLevel level, int chunkX, int chunkZ,
                                           net.minecraft.world.level.block.Block bloodBlock,
                                           int attempts) {
        if (!level.hasChunk(chunkX, chunkZ)) return 0;
        net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(chunkX, chunkZ);
        int baseX = lc.getPos().getMinBlockX();
        int baseZ = lc.getPos().getMinBlockZ();
        int variants = WorldHordesConfig.COMMON.bloodDecalVariants.get();
        int placed = 0;

        for (int a = 0; a < attempts; a++) {
            int bx = baseX + RAND.nextInt(16);
            int bz = baseZ + RAND.nextInt(16);
            int by = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
            BlockPos candidate = new BlockPos(bx, by, bz);
            BlockPos below = candidate.below();
            net.minecraft.world.level.block.state.BlockState ground = level.getBlockState(below);
            if (!ground.isAir() && !ground.liquid()
                    && level.getBlockState(candidate).isAir()) {
                int variant = RAND.nextInt(Math.min(variants, com.worldhordes.mod.block.BloodSplatterBlock.MAX_VARIANTS));
                level.setBlock(candidate,
                        bloodBlock.defaultBlockState()
                                .setValue(com.worldhordes.mod.block.BloodSplatterBlock.VARIANT, variant),
                        net.minecraft.world.level.block.Block.UPDATE_CLIENTS
                        | net.minecraft.world.level.block.Block.UPDATE_SUPPRESS_DROPS);
                placed++;
            }
        }
        return placed;
    }

    /** Returns the spawn role label for a chunk. */
    public static InfestationZone.ZoneRole getChunkRole(String dim, int cx, int cz) {
        return InfestationZoneRegistry.getRoleOf(dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Horde chunk spawns (wandering hordes)
    // -------------------------------------------------------------------------

    private static void spawnHordeZombiesNearPlayer(WanderingHorde horde) {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;
        if (LiveZombieTracker.isAtHardCap()) return;
        if (!horde.hasMembersLeft()) return;

        int hcx = horde.getChunkX();
        int hcz = horde.getChunkZ();

        boolean playerNearby = false;
        net.minecraft.world.entity.player.Player nearestPlayer = null;
        for (net.minecraft.world.entity.player.Player player : level.players()) {
            BlockPos pos = player.blockPosition();
            int pCx = pos.getX() >> 4, pCz = pos.getZ() >> 4;
            if (Math.abs(pCx - hcx) <= 8 && Math.abs(pCz - hcz) <= 8) {
                playerNearby = true;
                nearestPlayer = player;
                break;
            }
        }
        if (!playerNearby || nearestPlayer == null) return;
        if (!level.hasChunk(hcx, hcz)) return;

        int waveCap  = Math.min(10, horde.getMemberCount());
        int drawn    = horde.drawMembers(waveCap);
        int spawned  = 0;

        net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(hcx, hcz);
        int baseX = lc.getPos().getMinBlockX();
        int baseZ = lc.getPos().getMinBlockZ();
        int playerY = nearestPlayer.blockPosition().getY();

        for (int i = 0; i < drawn; i++) {
            if (LiveZombieTracker.isAtHardCap()) {
                horde.returnMembers(drawn - i);
                break;
            }
            int bx = baseX + RAND.nextInt(16);
            int bz = baseZ + RAND.nextInt(16);
            // Wandering horde zombies also attempt player Y first
            BlockPos spawnPos = findPlayerLevelSpawn(level, bx, playerY, bz);
            if (spawnPos == null) spawnPos = findAnyValidSpawn(level, bx, bz);
            if (spawnPos != null) {
                Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                zombie.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
                zombie.getPersistentData().putInt("worldhordes_src_cx", hcx);
                zombie.getPersistentData().putInt("worldhordes_src_cz", hcz);
                zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                        MobSpawnType.MOB_SUMMONED, null, null);
                level.addFreshEntity(zombie);
                LiveZombieTracker.onSpawn();
                spawned++;
            }
        }

        if (drawn - spawned > 0) horde.returnMembers(drawn - spawned);

        if (spawned > 0) {
            horde.shrink(spawned);
            WorldHordesMod.LOGGER.info(
                    "[WorldHordes] Horde {} deployed {} zombies from chunk ({},{}) — members left: {}, size left: {}",
                    horde.getId().toString().substring(0, 8), spawned, hcx, hcz,
                    horde.getMemberCount(), horde.getSize());
        }
    }

    // -------------------------------------------------------------------------
    // Spawn position helpers
    // -------------------------------------------------------------------------

    /**
     * Finds a valid spawn position near (spawnX, spawnZ) at approximately playerY.
     * Scans ±10 blocks around playerY for a two-block-tall air pocket above solid ground.
     * Ignores light level — spawns in both light and darkness.
     */
    private static BlockPos findPlayerLevelSpawn(ServerLevel level, int spawnX, int playerY, int spawnZ) {
        for (int attempt = 0; attempt < 8; attempt++) {
            int ox = RAND.nextInt(9) - 4;
            int oz = RAND.nextInt(9) - 4;
            int ax = spawnX + ox;
            int az = spawnZ + oz;
            int minY = Math.max(level.getMinBuildHeight() + 1, playerY - 10);
            int maxY = Math.min(level.getMaxBuildHeight() - 2, playerY + 10);
            for (int y = minY; y <= maxY; y++) {
                BlockPos candidate = new BlockPos(ax, y, az);
                if (isValidSpawnPos(level, candidate)) return candidate;
            }
        }
        return null;
    }

    /**
     * Finds a valid surface spawn position near (spawnX, spawnZ).
     * Light-agnostic — horde and wave spawns work day or night.
     */
    private static BlockPos findAnyValidSpawn(ServerLevel level, int spawnX, int spawnZ) {
        for (int attempt = 0; attempt < 6; attempt++) {
            int ox = RAND.nextInt(9) - 4;
            int oz = RAND.nextInt(9) - 4;
            int ax = spawnX + ox;
            int az = spawnZ + oz;
            int groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ax, az);
            BlockPos candidate = new BlockPos(ax, groundY, az);
            if (isValidSpawnPos(level, candidate)) return candidate;
        }
        int groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawnX, spawnZ);
        BlockPos fallback = new BlockPos(spawnX, groundY, spawnZ);
        return isValidSpawnPos(level, fallback) ? fallback : null;
    }

    /**
     * Valid spawn: feet-pos is air, head-pos is air, ground below is solid.
     */
    private static boolean isValidSpawnPos(ServerLevel level, BlockPos pos) {
        if (pos == null) return false;
        BlockPos below = pos.below();
        return level.getBlockState(pos).isAir()
                && level.getBlockState(pos.above()).isAir()
                && level.getBlockState(below).isCollisionShapeFullBlock(level, below);
    }

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    public static void onInfestZombieUntrack(Zombie zombie) {
        if (!zombie.getPersistentData().getBoolean("worldhordes_infest_spawn")) return;
        LiveZombieTracker.onRemove();
        int cx = zombie.getPersistentData().getInt("worldhordes_src_cx");
        int cz = zombie.getPersistentData().getInt("worldhordes_src_cz");
        com.worldhordes.mod.data.InfestationEntity entity =
                InfestationZoneRegistry.getEntityFor(DimUtil.OVERWORLD_DIM, cx, cz);
        if (entity != null) {
            entity.returnToReserve(1);
            entity.onZombieRemovedFromChunk();
        } else {
            InfestationData.getOrCreate(DimUtil.OVERWORLD_DIM, cx, cz).addToReserve(1);
        }
        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Infest zombie returned to zone reserve at ({},{}).", cx, cz);
        }
    }

    public static void forceSpawnHorde(String dim, int cx, int cz, int size) {
        WanderingHorde horde = new WanderingHorde(dim, cx, cz, size);
        activeHordes.add(horde);
        int arrivalBonus = WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get();
        InfestationData.seedInfestationRegion(dim, cx, cz, size + arrivalBonus);
        WorldHordesMod.LOGGER.info("[WorldHordes] Force-spawned horde {} [size={}] at chunk ({},{}).",
                horde.getId().toString().substring(0,8), size, cx, cz);
    }

    public static int clearAllHordes() {
        int count = activeHordes.size();
        activeHordes.clear();
        prePoppedZones.clear();
        zoneLastWaveTick.clear();
        WorldHordesMod.LOGGER.info("[WorldHordes] Cleared {} active hordes via debug command.", count);
        return count;
    }

    public static void onZombieKilledInChunk(String dim, int cx, int cz) {
        for (WanderingHorde horde : activeHordes) {
            if (horde.isSettled() && horde.getDimension().equals(dim)
                    && horde.getChunkX() == cx && horde.getChunkZ() == cz) {
                horde.shrink(1);
                if (horde.isDepleted()) {
                    InfestationData.getOrCreate(dim, cx, cz).setHasActiveHorde(false);
                    WorldHordesMod.LOGGER.info("[WorldHordes] Settled horde {} wiped out at ({},{})",
                            horde.getId().toString().substring(0,8), cx, cz);
                }
            }
        }
    }

    public static void onChunkFullyCleared(ServerLevel serverLevel, String dim, int cx, int cz) {
        com.worldhordes.mod.data.InfestationEntity entity =
                InfestationZoneRegistry.getEntityFor(dim, cx, cz);
        if (entity != null && entity.getZoneKey() != null) {
            prePoppedZones.remove(entity.getZoneKey());
            zoneLastWaveTick.remove(entity.getZoneKey());
        }
        InfestationData.destroyInfestation(serverLevel, dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(activeHordes.size());
            for (WanderingHorde h : activeHordes) {
                out.writeUTF(h.getId().toString());
                out.writeUTF(h.getDimension());
                out.writeInt(h.getChunkX());
                out.writeInt(h.getChunkZ());
                out.writeInt(h.getSize());
                out.writeInt(h.getTargetChunkX());
                out.writeInt(h.getTargetChunkZ());
                out.writeLong(h.getLastMoveTick());
                out.writeBoolean(h.isSettled());
                out.writeInt(h.getWanderDirection());
                out.writeInt(h.getStepsTaken());
                out.writeInt(h.getMaxSteps());
                out.writeInt(h.getMemberCount());
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved {} active hordes.", activeHordes.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save horde data", e);
        }
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int count = in.readInt();
            for (int i = 0; i < count; i++) {
                UUID id = UUID.fromString(in.readUTF());
                String dim = in.readUTF();
                int cx = in.readInt(), cz = in.readInt(), size = in.readInt();
                int tx = in.readInt(), tz = in.readInt();
                long lastMove = in.readLong();
                boolean settled = in.readBoolean();
                int dir = in.readInt(), steps = in.readInt(), maxSteps = in.readInt();
                int memberCount = in.readInt();
                activeHordes.add(new WanderingHorde(id, dim, cx, cz, size, tx, tz, lastMove, settled, dir, steps, maxSteps, memberCount));
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded {} active hordes.", activeHordes.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load horde data", e);
        }
    }
}
