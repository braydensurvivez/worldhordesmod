package com.worldhordes.mod.horde;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationEntity;
import com.worldhordes.mod.data.InfestationZone;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.data.LiveZombieTracker;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class HordeManager {

    private static final List<WanderingHorde> activeHordes = new CopyOnWriteArrayList<>();
    private static MinecraftServer server;
    private static long lastHordeSpawnTick    = 0;
    private static long lastHordeMigrationTick = 0;
    private static long lastInfestSpawnTick   = 0;
    /** Tick at which a combat-pause was last triggered. 0 = no pause active. */
    private static long combatPauseUntilTick  = 0;

    private static final String SAVE_FILE = "worldhordes_hordes.dat";
    private static final Random RAND = new Random();

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        LiveZombieTracker.reset();
        load();
    }

    public static List<WanderingHorde> getActiveHordes() { return Collections.unmodifiableList(activeHordes); }
    public static MinecraftServer getServer() { return server; }

    // -------------------------------------------------------------------------
    // Main tick
    // -------------------------------------------------------------------------

    public static void tick(long gameTick) {
        HordeDensityManager.tick();
        InfestationData.tick();

        // NaturalSpawnGatekeeper uses wall-clock time (System.currentTimeMillis()),
        // so no explicit tick is needed — windows reset automatically.

        int spawnInterval = WorldHordesConfig.COMMON.hordeSpawnIntervalTicks.get();
        if (gameTick - lastHordeSpawnTick >= spawnInterval) {
            lastHordeSpawnTick = gameTick;
            trySpawnHorde();
        }

        int moveInterval = WorldHordesConfig.COMMON.hordeMoveCooldownTicks.get();
        if (gameTick - lastHordeMigrationTick >= moveInterval) {
            lastHordeMigrationTick = gameTick;
            tickHordeMigration();
        }

        int pulseInterval = WorldHordesConfig.COMMON.infestationChunkSpawnPulseTicks.get();
        if (gameTick - lastInfestSpawnTick >= pulseInterval) {
            lastInfestSpawnTick = gameTick;
            tickInfestationSpawns();
        }

        activeHordes.removeIf(h -> {
            if (h.isDepleted()) {
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} depleted and removed.", h.getId().toString().substring(0,8));
                return true;
            }
            return false;
        });
    }

    // -------------------------------------------------------------------------
    // Horde spawning
    // -------------------------------------------------------------------------

    private static void trySpawnHorde() {
        int maxHordes = WorldHordesConfig.COMMON.maxActiveHordes.get();
        if (activeHordes.size() >= maxHordes) return;
        if (!HordeDensityManager.isAboveHordeThreshold()) return;

        ServerLevel overworld = server.getLevel(Level.OVERWORLD);
        if (overworld == null) return;
        List<net.minecraft.world.entity.player.Player> players = new ArrayList<>(overworld.players());
        if (players.isEmpty()) return;

        net.minecraft.world.entity.player.Player player = players.get(RAND.nextInt(players.size()));
        BlockPos playerPos = player.blockPosition();

        int offsetX = (80 + RAND.nextInt(70)) * (RAND.nextBoolean() ? 1 : -1);
        int offsetZ = (80 + RAND.nextInt(70)) * (RAND.nextBoolean() ? 1 : -1);
        int spawnChunkX = (playerPos.getX() >> 4) + (offsetX / 16);
        int spawnChunkZ = (playerPos.getZ() >> 4) + (offsetZ / 16);

        if (!InfestationData.isRegionDistanceValid(DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ)) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug("[WorldHordes] Horde spawn rejected — too close to existing infested region.");
            }
            return;
        }

        int minSize = WorldHordesConfig.COMMON.hordeMinSize.get();
        int maxSize = WorldHordesConfig.COMMON.hordeMaxSize.get();
        int size    = minSize + RAND.nextInt(Math.max(1, maxSize - minSize));

        int density   = HordeDensityManager.getDensity();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        float densityScale = Math.min(3.0f, (float) density / threshold);
        size = (int)(size * densityScale);
        size = Math.max(minSize, Math.min(size, maxSize));

        WanderingHorde horde = new WanderingHorde(DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ, size);
        activeHordes.add(horde);

        // Seed the zone-based infestation — shared entity receives full horde size as initial population
        int arrivalBonus = WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get();
        InfestationZone zone = InfestationData.seedInfestationRegion(
                DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ,
                size + arrivalBonus);

        if (zone == null) {
            // Fallback: no zone created (too close), just track the horde itself
            WorldHordesMod.LOGGER.info("[WorldHordes] Zone rejected — horde {} will wander without settling.",
                    horde.getId().toString().substring(0, 8));
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Spawned {} [size={}] at chunk ({},{}). Active hordes: {}",
                horde, size, spawnChunkX, spawnChunkZ, activeHordes.size());
    }

    // -------------------------------------------------------------------------
    // Horde migration
    // -------------------------------------------------------------------------

    private static void tickHordeMigration() {
        int chunksPerMove  = WorldHordesConfig.COMMON.hordeChunksPerMove.get();
        double settleChance = WorldHordesConfig.COMMON.hordeEnterInfestedChunkChance.get();

        for (WanderingHorde horde : activeHordes) {
            if (horde.isSettled()) {
                InfestationData.addInfestation(horde.getDimension(), horde.getChunkX(), horde.getChunkZ(), 3);
                if (RAND.nextInt(20) == 0) {
                    horde.setSettled(false);
                    WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} moving again from ({},{})",
                            horde.getId().toString().substring(0,8), horde.getChunkX(), horde.getChunkZ());
                }
                continue;
            }

            // FIX: Hordes no longer leave infestation trails when they move.
            // The horde's population is carried with it cleanly to the new chunk.
            int prevCx = horde.getChunkX(), prevCz = horde.getChunkZ();
            ChunkInfestationLevel prevInf = InfestationData.getOrCreate(horde.getDimension(), prevCx, prevCz);
            int carryReserve = prevInf.getZombieReserve();
            prevInf.removeFromReserve(carryReserve); // Carry reserve away — leave NO trail

            int[] next = horde.nextChunkPosition(chunksPerMove);
            int nx = next[0], nz = next[1];
            horde.setChunkX(nx); horde.setChunkZ(nz); horde.incrementSteps();

            // Only add infestation to the new destination — no spreading to old chunks
            InfestationData.addInfestation(horde.getDimension(), nx, nz,
                    WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get());
            ChunkInfestationLevel newInf = InfestationData.getOrCreate(horde.getDimension(), nx, nz);

            // Respect population limit for the chunk's role
            InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(horde.getDimension(), nx, nz);
            int limit = (role == InfestationZone.ZoneRole.CORE)
                    ? WorldHordesConfig.COMMON.coreHordePopulationLimit.get()
                    : WorldHordesConfig.COMMON.outerRingHordePopulationLimit.get();
            int toAdd = Math.min(carryReserve, Math.max(0, limit - newInf.getZombieReserve()));
            newInf.addToReserve(toAdd);

            int existingInfest = InfestationData.getLevel(horde.getDimension(), nx, nz);
            if (existingInfest >= WorldHordesConfig.COMMON.infestationTier2.get()
                    && RAND.nextDouble() < settleChance) {
                horde.setSettled(true);
                newInf.setHasActiveHorde(true);
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} settled in heavily infested chunk ({},{})",
                        horde.getId().toString().substring(0,8), nx, nz);
            }

            if (horde.hasExhausted()) {
                if (RAND.nextBoolean()) { horde.setSettled(true); newInf.setHasActiveHorde(true); }
                else { horde.setSize(0); }
            }

            spawnHordeZombiesNearPlayer(horde);
        }
    }

    // -------------------------------------------------------------------------
    // Infested chunk spawn pulses
    //
    // BEHAVIOUR (post-fix):
    //   Phase 1 – PRE-POPULATION  : When a zone's chunks are loaded (chunks become
    //             available in the world), zombies are spawned INSIDE those chunks
    //             (random positions within each chunk's bounds).  This happens once
    //             per zone, on the first pulse tick after the zone entity becomes
    //             active (player enters proximity).  The pre-population draw
    //             comes from the shared spawn reserve.
    //
    //   Phase 2 – WAVE SPAWNING   : Once the zone has been pre-populated AND a player
    //             kills a zombie in the zone (triggering combat mode), subsequent
    //             pulse ticks spawn additional waves around the player.  Waves only
    //             fire while the zone entity is in active combat (isInCombat()).
    //
    // All 64 chunks (8×8) in a zone share ONE InfestationEntity and its member count.
    // The member count displayed / tracked represents the whole zone as a single entity.
    // -------------------------------------------------------------------------

    /** Set of zone keys that have already been pre-populated on load. */
    private static final Set<String> prePoppedZones = new java.util.HashSet<>();

    /**
     * Activates infestations that players have entered, pre-populates zone chunks on load,
     * and then spawns combat waves only when players are actively fighting the zone.
     * Also updates global World Horde Density from each active zone's population.
     */
    private static void tickInfestationSpawns() {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;

        // --- Performance gate 1: hard global zombie cap ---
        if (LiveZombieTracker.isAtHardCap()) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Spawn pulse skipped — live zombie cap reached ({}/{})",
                        LiveZombieTracker.get(),
                        WorldHordesConfig.COMMON.maxLiveHordeZombies.get());
            }
            return;
        }

        int coreMax  = WorldHordesConfig.COMMON.coreSpawnPerPulse.get();
        int outerMax = WorldHordesConfig.COMMON.outerRingSpawnPerPulse.get();
        String dim   = DimUtil.OVERWORLD_DIM;

        // ---- 1. Update global density from zone (den) populations ----
        int totalZoneDensityDelta = 0;
        for (com.worldhordes.mod.data.InfestationEntity entity
                : InfestationZoneRegistry.getAllEntities().values()) {
            totalZoneDensityDelta += entity.computeDensityDelta();
        }
        if (totalZoneDensityDelta > 0) {
            HordeDensityManager.addDensity(totalZoneDensityDelta);
        } else if (totalZoneDensityDelta < 0) {
            HordeDensityManager.removeDensity(-totalZoneDensityDelta);
        }

        // ---- 2. Per-player: activate zones, pre-populate on load, then wave-spawn on engagement ----
        for (net.minecraft.world.entity.player.Player player : level.players()) {
            BlockPos playerPos = player.blockPosition();
            int playerCx = playerPos.getX() >> 4;
            int playerCz = playerPos.getZ() >> 4;

            // Search radius to cover the full 8×8 zone plus a buffer
            int searchRadius = 8;
            for (int dx = -searchRadius; dx <= searchRadius; dx++) {
                for (int dz = -searchRadius; dz <= searchRadius; dz++) {
                    int cx = playerCx + dx;
                    int cz = playerCz + dz;
                    if (!level.hasChunk(cx, cz)) continue;

                    com.worldhordes.mod.data.InfestationEntity entity =
                            InfestationZoneRegistry.getEntityFor(dim, cx, cz);
                    if (entity == null || entity.isMarkedForDestruction()) continue;

                    // --- Performance gate: skip cleared / claimed chunks ---
                    ChunkInfestationLevel chunkState = InfestationData.get(dim, cx, cz);
                    if (chunkState != null && chunkState.isCleared()) continue;
                    if (PlayerClaimedChunkManager.isChunkClaimed(dim, cx, cz)) continue;

                    // ---- Phase 1: Activate zone on first player entry ----
                    if (!entity.isActive()) {
                        entity.setActive(true);
                        WorldHordesMod.LOGGER.info(
                                "[WorldHordes] Infestation zone activated by player entry at ({},{}). Pop={}",
                                cx, cz, entity.getPopulation());
                        placeInitialBloodDecals(level, dim, cx, cz);
                    }

                    // ---- Phase 1b: Pre-populate all zone chunks on first load ----
                    // Spawn members INSIDE each zone chunk so zombies are already present
                    // before any player engages.  Only done once per zone.
                    String zoneKey = entity.getZoneKey();
                    if (zoneKey != null && !prePoppedZones.contains(zoneKey)
                            && entity.getSpawnReserve() > 0) {
                        InfestationZone zone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
                        if (zone != null) {
                            prePoppedZones.add(zoneKey);
                            int preSpawned = prePopulateZoneChunks(level, dim, zone, entity, coreMax, outerMax);
                            WorldHordesMod.LOGGER.info(
                                    "[WorldHordes] Pre-populated zone {} with {} zombies inside chunk bounds.",
                                    zoneKey, preSpawned);
                        }
                    }

                    // ---- Phase 2: Wave spawning — only when player is in active combat ----
                    // Waves do NOT fire just because a player is nearby.
                    // They only fire after a player has killed a zombie in this zone
                    // (which sets the combat lock on the entity).
                    if (!entity.isInCombat()) continue;
                    if (entity.getSpawnReserve() <= 0) continue;

                    // Combat-pause gates (prevent runaway wave flooding)
                    long currentTick = level.getServer().getTickCount();
                    if (combatPauseUntilTick > currentTick) continue;
                    if (LiveZombieTracker.isInActiveCombat()) {
                        combatPauseUntilTick = currentTick + WorldHordesConfig.COMMON.combatPauseTicks.get();
                        continue;
                    }

                    InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(dim, cx, cz);
                    int maxPerPulse;
                    if (role == InfestationZone.ZoneRole.CORE) {
                        maxPerPulse = coreMax;
                    } else if (role == InfestationZone.ZoneRole.OUTER_RING) {
                        maxPerPulse = outerMax;
                    } else {
                        continue;
                    }

                    // Wave zombies spawn around the player (engagement-driven)
                    int minDist = WorldHordesConfig.COMMON.infestationSpawnMinDistFromPlayer.get();
                    int maxDist = WorldHordesConfig.COMMON.infestationSpawnMaxDistFromPlayer.get();
                    int toSpawn = Math.min(RAND.nextInt(maxPerPulse + 1) + 1, entity.getSpawnReserve());
                    int drawn   = entity.drawFromReserve(toSpawn);
                    int spawned = 0;

                    for (int i = 0; i < drawn; i++) {
                        double angle = RAND.nextDouble() * Math.PI * 2;
                        double dist  = minDist + RAND.nextDouble() * (maxDist - minDist);
                        int spawnX   = (int)(playerPos.getX() + Math.cos(angle) * dist);
                        int spawnZ   = (int)(playerPos.getZ() + Math.sin(angle) * dist);
                        BlockPos spawnPos = findDarkOrValidSpawn(level, spawnX, spawnZ);
                        if (spawnPos != null) {
                            Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                            zombie.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
                            zombie.getPersistentData().putInt("worldhordes_src_cx", cx);
                            zombie.getPersistentData().putInt("worldhordes_src_cz", cz);
                            zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                            zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                                    MobSpawnType.MOB_SUMMONED, null, null);
                            level.addFreshEntity(zombie);
                            LiveZombieTracker.onSpawn();
                            spawned++;
                        }
                    }
                    if (drawn - spawned > 0) entity.returnToReserve(drawn - spawned);

                    if (spawned > 0 && WorldHordesConfig.COMMON.debugMode.get()) {
                        WorldHordesMod.LOGGER.debug(
                                "[WorldHordes] Wave spawn: zone ({},{}) {} — {} zombies. Reserve={}",
                                cx, cz, role, spawned, entity.getSpawnReserve());
                    }
                }
            }
        }
    }

    /**
     * Pre-populates all loaded chunks in a zone with zombies spawned INSIDE the chunk bounds.
     * This is called once per zone when it first activates (player enters proximity).
     * The member count of the shared entity is shown in all 64 chunks — they are one entity.
     *
     * @return total zombies spawned across all zone chunks
     */
    private static int prePopulateZoneChunks(ServerLevel level, String dim,
                                              InfestationZone zone,
                                              com.worldhordes.mod.data.InfestationEntity entity,
                                              int coreMax, int outerMax) {
        int totalSpawned = 0;
        // Pre-populate core chunks more densely, outer ring less
        for (int[] chunk : zone.getCoreChunks()) {
            totalSpawned += spawnZombiesInsideChunk(level, dim, chunk[0], chunk[1], entity,
                    Math.max(1, coreMax / 2));
        }
        for (int[] chunk : zone.getOuterRingChunks()) {
            totalSpawned += spawnZombiesInsideChunk(level, dim, chunk[0], chunk[1], entity,
                    Math.max(1, outerMax / 2));
        }
        return totalSpawned;
    }

    /**
     * Spawns up to {@code maxCount} zombies at random positions INSIDE the given chunk.
     * Zombies are tagged with their source chunk so the zone's shared entity tracks them.
     */
    private static int spawnZombiesInsideChunk(ServerLevel level, String dim,
                                                int chunkX, int chunkZ,
                                                com.worldhordes.mod.data.InfestationEntity entity,
                                                int maxCount) {
        if (!level.hasChunk(chunkX, chunkZ)) return 0;
        if (entity.getSpawnReserve() <= 0) return 0;
        if (PlayerClaimedChunkManager.isChunkClaimed(dim, chunkX, chunkZ)) return 0;
        if (LiveZombieTracker.isAtHardCap()) return 0;

        net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(chunkX, chunkZ);
        int baseX = lc.getPos().getMinBlockX();
        int baseZ = lc.getPos().getMinBlockZ();

        int count = Math.min(maxCount, entity.getSpawnReserve());
        int drawn = entity.drawFromReserve(count);
        int spawned = 0;

        for (int i = 0; i < drawn; i++) {
            if (LiveZombieTracker.isAtHardCap()) {
                entity.returnToReserve(drawn - i);
                break;
            }
            // Random position inside the chunk (0..15 offset from chunk base)
            int bx = baseX + RAND.nextInt(16);
            int bz = baseZ + RAND.nextInt(16);
            BlockPos spawnPos = findDarkOrValidSpawn(level, bx, bz);
            if (spawnPos != null) {
                Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                zombie.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
                zombie.getPersistentData().putInt("worldhordes_src_cx", chunkX);
                zombie.getPersistentData().putInt("worldhordes_src_cz", chunkZ);
                zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                        MobSpawnType.MOB_SUMMONED, null, null);
                level.addFreshEntity(zombie);
                LiveZombieTracker.onSpawn();
                spawned++;
            }
        }
        // Return any unspawned draws (failed placement)
        if (drawn - spawned > 0) entity.returnToReserve(drawn - spawned);
        return spawned;
    }

    /**
     * Places initial blood decals when an infestation zone first becomes active.
     * Core chunks get dense splatters; outer ring gets sparse splatters.
     */
    private static void placeInitialBloodDecals(ServerLevel level, String dim, int cx, int cz) {
        if (!WorldHordesConfig.COMMON.enableBloodDecals.get()) return;
        InfestationZone zone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
        if (zone == null) return;

        com.worldhordes.mod.registry.ModBlocks.BLOOD_SPLATTER.ifPresent(bloodBlock -> {
            int placed = 0;
            // Core: high density — attempt many placements per chunk
            for (int[] chunk : zone.getCoreChunks()) {
                placed += placeDecalsInChunk(level, chunk[0], chunk[1], bloodBlock, 12);
            }
            // Outer ring: low density — fewer placements per chunk
            for (int[] chunk : zone.getOuterRingChunks()) {
                placed += placeDecalsInChunk(level, chunk[0], chunk[1], bloodBlock, 3);
            }
            if (placed > 0) {
                WorldHordesMod.LOGGER.info(
                        "[WorldHordes] Placed {} initial blood decals for infestation zone at ({},{}).", placed, cx, cz);
            }
        });
    }

    private static int placeDecalsInChunk(ServerLevel level, int chunkX, int chunkZ,
                                           net.minecraft.world.level.block.Block bloodBlock,
                                           int attempts) {
        if (!level.hasChunk(chunkX, chunkZ)) return 0;
        net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(chunkX, chunkZ);
        int baseX = lc.getPos().getMinBlockX();
        int baseZ = lc.getPos().getMinBlockZ();
        int variants = WorldHordesConfig.COMMON.bloodDecalVariants.get();
        int placed = 0;

        for (int a = 0; a < attempts; a++) {
            int bx = baseX + RAND.nextInt(16);
            int bz = baseZ + RAND.nextInt(16);
            int by = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
            BlockPos candidate = new BlockPos(bx, by, bz);
            BlockPos below = candidate.below();
            net.minecraft.world.level.block.state.BlockState ground = level.getBlockState(below);
            if (!ground.isAir() && !ground.liquid()
                    && level.getBlockState(candidate).isAir()) {
                int variant = RAND.nextInt(Math.min(variants, com.worldhordes.mod.block.BloodSplatterBlock.MAX_VARIANTS));
                level.setBlock(candidate,
                        bloodBlock.defaultBlockState()
                                .setValue(com.worldhordes.mod.block.BloodSplatterBlock.VARIANT, variant),
                        net.minecraft.world.level.block.Block.UPDATE_CLIENTS
                        | net.minecraft.world.level.block.Block.UPDATE_SUPPRESS_DROPS);
                placed++;
            }
        }
        return placed;
    }

    /** Returns the spawn role label for a chunk (used in debug / event handler). */
    public static InfestationZone.ZoneRole getChunkRole(String dim, int cx, int cz) {
        return InfestationZoneRegistry.getRoleOf(dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Horde encounter spawns
    // -------------------------------------------------------------------------

    private static void spawnHordeZombiesNearPlayer(WanderingHorde horde) {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;

        // Respect the hard global cap for encounter spawns too
        if (LiveZombieTracker.isAtHardCap()) return;

        int minDist = WorldHordesConfig.COMMON.infestationSpawnMinDistFromPlayer.get();
        int maxDist = WorldHordesConfig.COMMON.infestationSpawnMaxDistFromPlayer.get();

        for (net.minecraft.world.entity.player.Player player : level.players()) {
            BlockPos pos = player.blockPosition();
            int pCx = pos.getX() >> 4, pCz = pos.getZ() >> 4;
            int dx = Math.abs(pCx - horde.getChunkX()), dz = Math.abs(pCz - horde.getChunkZ());
            if (dx <= 8 && dz <= 8) {
                int waveSize = Math.min(horde.getSize(), 3 + RAND.nextInt(5));
                int spawned = 0;
                for (int i = 0; i < waveSize; i++) {
                    double angle = RAND.nextDouble() * Math.PI * 2;
                    double dist  = minDist + RAND.nextDouble() * (maxDist - minDist);
                    int spawnX   = (int)(pos.getX() + Math.cos(angle) * dist);
                    int spawnZ   = (int)(pos.getZ() + Math.sin(angle) * dist);
                    BlockPos spawnPos = findDarkOrValidSpawn(level, spawnX, spawnZ);
                    if (spawnPos != null) {
                        Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                        zombie.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
                        zombie.getPersistentData().putInt("worldhordes_src_cx", horde.getChunkX());
                        zombie.getPersistentData().putInt("worldhordes_src_cz", horde.getChunkZ());
                        zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                        zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                                MobSpawnType.MOB_SUMMONED, null, null);
                        level.addFreshEntity(zombie);
                        LiveZombieTracker.onSpawn();
                        spawned++;
                    }
                }
                horde.shrink(spawned);
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} encountered player — deployed {} zombies. Remaining: {}",
                        horde.getId().toString().substring(0,8), spawned, horde.getSize());
                break;
            }
        }
    }

    /**
     * Finds a valid spawn position near (spawnX, spawnZ). When darkness mode is enabled,
     * tries up to 6 random dark offsets first, then falls back to the surface Y regardless
     * of light — ensuring WorldHordes spawns happen but prefer unlit spots.
     */
    private static BlockPos findDarkOrValidSpawn(ServerLevel level, int spawnX, int spawnZ) {
        boolean preferDark = WorldHordesConfig.COMMON.requireDarknessForNaturalSpawns.get();
        int maxLight = WorldHordesConfig.COMMON.maxLightLevelForSpawn.get();

        if (preferDark) {
            for (int attempt = 0; attempt < 6; attempt++) {
                int ox = RAND.nextInt(11) - 5;
                int oz = RAND.nextInt(11) - 5;
                int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawnX + ox, spawnZ + oz);
                BlockPos candidate = new BlockPos(spawnX + ox, sy, spawnZ + oz);
                if (isValidSpawnPos(level, candidate)
                        && level.getMaxLocalRawBrightness(candidate) <= maxLight) {
                    return candidate;
                }
            }
        }

        // Fallback: surface at exact position
        int spawnY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawnX, spawnZ);
        BlockPos fallback = new BlockPos(spawnX, spawnY, spawnZ);
        return isValidSpawnPos(level, fallback) ? fallback : null;
    }

    private static boolean isValidSpawnPos(ServerLevel level, BlockPos pos) {
        if (pos == null) return false;
        BlockPos below = pos.below();
        return level.getBlockState(pos).isAir()
                && level.getBlockState(pos.above()).isAir()
                && level.getBlockState(below).isCollisionShapeFullBlock(level, below);
    }

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    public static void onInfestZombieUntrack(Zombie zombie) {
        if (!zombie.getPersistentData().getBoolean("worldhordes_infest_spawn")) return;
        // Zombie despawned without being killed — decrement live counter
        LiveZombieTracker.onRemove();
        int cx = zombie.getPersistentData().getInt("worldhordes_src_cx");
        int cz = zombie.getPersistentData().getInt("worldhordes_src_cz");
        // Return zombie to the shared zone reserve
        com.worldhordes.mod.data.InfestationEntity entity =
                InfestationZoneRegistry.getEntityFor(DimUtil.OVERWORLD_DIM, cx, cz);
        if (entity != null) {
            entity.returnToReserve(1);
        } else {
            // Fallback for non-zone chunks
            InfestationData.getOrCreate(DimUtil.OVERWORLD_DIM, cx, cz).addToReserve(1);
        }
        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Infest zombie returned to zone reserve at ({},{}).", cx, cz);
        }
    }

    public static void forceSpawnHorde(String dim, int cx, int cz, int size) {
        WanderingHorde horde = new WanderingHorde(dim, cx, cz, size);
        activeHordes.add(horde);
        int arrivalBonus = WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get();
        InfestationData.seedInfestationRegion(dim, cx, cz, size + arrivalBonus);
        WorldHordesMod.LOGGER.info("[WorldHordes] Force-spawned horde {} [size={}] at chunk ({},{}).",
                horde.getId().toString().substring(0,8), size, cx, cz);
    }

    public static int clearAllHordes() {
        int count = activeHordes.size();
        activeHordes.clear();
        prePoppedZones.clear(); // allow re-spawn pre-population if zones are recreated
        WorldHordesMod.LOGGER.info("[WorldHordes] Cleared {} active hordes via debug command.", count);
        return count;
    }

    public static void onZombieKilledInChunk(String dim, int cx, int cz) {
        for (WanderingHorde horde : activeHordes) {
            if (horde.isSettled() && horde.getDimension().equals(dim)
                    && horde.getChunkX() == cx && horde.getChunkZ() == cz) {
                horde.shrink(1);
                if (horde.isDepleted()) {
                    InfestationData.getOrCreate(dim, cx, cz).setHasActiveHorde(false);
                    WorldHordesMod.LOGGER.info("[WorldHordes] Settled horde {} wiped out at ({},{})",
                            horde.getId().toString().substring(0,8), cx, cz);
                }
            }
        }
    }

    /**
     * Called when infestation in a chunk/zone is cleared by players.
     * Delegates to InfestationData.destroyInfestation for full cleanup.
     * Also clears the pre-population record so a new zone at the same location
     * will be pre-populated again if it forms in the future.
     */
    public static void onChunkFullyCleared(ServerLevel serverLevel, String dim, int cx, int cz) {
        // Remove zone key from the pre-populated set before destroying, so a future zone here re-populates
        com.worldhordes.mod.data.InfestationEntity entity =
                InfestationZoneRegistry.getEntityFor(dim, cx, cz);
        if (entity != null && entity.getZoneKey() != null) {
            prePoppedZones.remove(entity.getZoneKey());
        }
        InfestationData.destroyInfestation(serverLevel, dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(activeHordes.size());
            for (WanderingHorde h : activeHordes) {
                out.writeUTF(h.getId().toString());
                out.writeUTF(h.getDimension());
                out.writeInt(h.getChunkX());
                out.writeInt(h.getChunkZ());
                out.writeInt(h.getSize());
                out.writeInt(h.getTargetChunkX());
                out.writeInt(h.getTargetChunkZ());
                out.writeLong(h.getLastMoveTick());
                out.writeBoolean(h.isSettled());
                out.writeInt(h.getWanderDirection());
                out.writeInt(h.getStepsTaken());
                out.writeInt(h.getMaxSteps());
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved {} active hordes.", activeHordes.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save horde data", e);
        }
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int count = in.readInt();
            for (int i = 0; i < count; i++) {
                UUID id = UUID.fromString(in.readUTF());
                String dim = in.readUTF();
                int cx = in.readInt(), cz = in.readInt(), size = in.readInt();
                int tx = in.readInt(), tz = in.readInt();
                long lastMove = in.readLong();
                boolean settled = in.readBoolean();
                int dir = in.readInt(), steps = in.readInt(), maxSteps = in.readInt();
                activeHordes.add(new WanderingHorde(id, dim, cx, cz, size, tx, tz, lastMove, settled, dir, steps, maxSteps));
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded {} active hordes.", activeHordes.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load horde data", e);
        }
    }
}
