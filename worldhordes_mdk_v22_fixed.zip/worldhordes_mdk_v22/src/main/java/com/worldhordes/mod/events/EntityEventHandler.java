package com.worldhordes.mod.events;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationEntity;
import com.worldhordes.mod.data.InfestationZone;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.data.LiveZombieTracker;
import com.worldhordes.mod.horde.HordeManager;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;
import com.worldhordes.mod.registry.ModBlocks;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Random;

public class EntityEventHandler {

    private static final Random RAND = new Random();

    // -------------------------------------------------------------------------
    // Death handling
    // -------------------------------------------------------------------------

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (!(entity.level() instanceof ServerLevel serverLevel)) return;

        String dim = DimUtil.getDim(serverLevel);
        ChunkPos cpos = new ChunkPos(entity.blockPosition());
        int cx = cpos.x, cz = cpos.z;

        // === Zombie dies ===
        if (entity instanceof Zombie zombie) {
            // Decrement live counter if this was a WorldHordes-tagged zombie
            if (zombie.getPersistentData().getBoolean("worldhordes_infest_spawn")) {
                LiveZombieTracker.onRemove();
                // Decrement the zone's live-in-chunk counter too
                InfestationEntity liveEntity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
                if (liveEntity != null) liveEntity.onZombieRemovedFromChunk();
            }
            zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", false);

            if (event.getSource().getEntity() instanceof Player) {
                // Update global density
                int densityChange = WorldHordesConfig.COMMON.densityPerZombieKillByPlayer.get();
                HordeDensityManager.addDensity(densityChange);

                // Mark combat on the den so regen/growth is suppressed during the fight
                InfestationEntity combatEntity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
                if (combatEntity != null) combatEntity.markCombat();

                // Reduce the zone's shared population — may trigger destruction
                boolean destroyed = InfestationData.onZombieKilledByPlayer(serverLevel, dim, cx, cz);

                if (destroyed) {
                    // Award a claim token to the player who landed the killing blow
                    if (WorldHordesConfig.COMMON.enableClaimedChunks.get()
                            && event.getSource().getEntity() instanceof Player killer) {
                        PlayerClaimedChunkManager.awardToken(killer.getUUID(), killer.getName().getString());
                        killer.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                                "\u00a7a\u2746 Infested zone cleared! You earned \u00a7e1 Claimed Chunk Token\u00a7a. " +
                                "Use \u00a7f/wh tokens\u00a7a to check your balance."));
                    }
                } else {
                    // Legacy: keep HordeManager informed for wandering-horde tracking
                    HordeManager.onZombieKilledInChunk(dim, cx, cz);
                }

                if (WorldHordesConfig.COMMON.debugMode.get()) {
                    int pop = InfestationData.getLevel(dim, cx, cz);
                    WorldHordesMod.LOGGER.debug(
                            "[WorldHordes] Player killed zombie at ({},{}) — zone pop now {}, destroyed={}",
                            cx, cz, pop, destroyed);
                }
            } else {
                // Non-player kill: small passive decay on per-chunk level only
                InfestationData.removeInfestation(dim, cx, cz, 1);
            }
            return;
        }

        // === Player dies ===
        if (entity instanceof Player) {
            if (event.getSource().getEntity() instanceof Zombie) {
                int density = WorldHordesConfig.COMMON.densityPerPlayerKilled.get();
                HordeDensityManager.addDensity(density);
                // Also boost the zone entity if one exists
                InfestationEntity zoneEntity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
                if (zoneEntity != null) zoneEntity.onNaturalSpawn(density / 2);
                else InfestationData.addInfestation(dim, cx, cz, density / 2);
                WorldHordesMod.LOGGER.info("[WorldHordes] Player killed by zombie at ({},{})! +{} density", cx, cz, density);
            }
            return;
        }

        // === NPC / Villager dies ===
        if (entity instanceof AbstractVillager || isVillageMob(entity)) {
            if (event.getSource().getEntity() instanceof Zombie) {
                int density = WorldHordesConfig.COMMON.densityPerNpcKilled.get();
                HordeDensityManager.addDensity(density);
                InfestationEntity zoneEntity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
                if (zoneEntity != null) zoneEntity.onNaturalSpawn(density / 3);
                else InfestationData.addInfestation(dim, cx, cz, density / 3);
                WorldHordesMod.LOGGER.info("[WorldHordes] NPC killed by zombie at ({},{})! +{} density", cx, cz, density);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Zombie tick — blood decal placement
    // -------------------------------------------------------------------------

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof Zombie zombie)) return;
        if (!(zombie.level() instanceof ServerLevel serverLevel)) return;
        // Throttle: run once per second per zombie
        if (zombie.tickCount % 20 != 0) return;

        String dim = DimUtil.getDim(serverLevel);
        BlockPos pos = zombie.blockPosition();
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;

        // Blood splatter decal placement
        if (WorldHordesConfig.COMMON.enableBloodDecals.get()) {
            InfestationEntity zoneEntity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
            if (zoneEntity != null && zoneEntity.isActive()) {
                // Core gets significantly higher density than outer ring
                InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(dim, cx, cz);
                int chance = (role == InfestationZone.ZoneRole.CORE)
                        ? WorldHordesConfig.COMMON.bloodDecalPlaceChanceCore.get()
                        : WorldHordesConfig.COMMON.bloodDecalPlaceChanceOuter.get();

                if (RAND.nextInt(1000) < chance) {
                    tryPlaceBloodDecal(serverLevel, pos);
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Blood Decal placement logic
    // -------------------------------------------------------------------------

    private void tryPlaceBloodDecal(ServerLevel level, BlockPos zombiePos) {
        BlockPos below = zombiePos.below();
        BlockState groundState = level.getBlockState(below);

        if (groundState.isAir() || groundState.liquid()) return;
        Block groundBlock = groundState.getBlock();
        boolean isNaturalGround = (
                groundBlock == Blocks.GRASS_BLOCK  || groundBlock == Blocks.DIRT
             || groundBlock == Blocks.COARSE_DIRT  || groundBlock == Blocks.PODZOL
             || groundBlock == Blocks.STONE        || groundBlock == Blocks.COBBLESTONE
             || groundBlock == Blocks.GRAVEL       || groundBlock == Blocks.SAND
             || groundBlock == Blocks.CLAY         || groundBlock == Blocks.MYCELIUM
             || groundBlock == Blocks.NETHERRACK   || groundBlock == Blocks.SNOW_BLOCK
             || groundBlock == Blocks.MOSS_BLOCK   || groundBlock == Blocks.DEEPSLATE
             || groundBlock == Blocks.TUFF         || groundBlock == Blocks.ROOTED_DIRT
        );
        if (!isNaturalGround) return;

        if (!level.getBlockState(zombiePos).isAir()) return;

        ModBlocks.BLOOD_SPLATTER.ifPresent(bloodBlock -> {
            int variants = WorldHordesConfig.COMMON.bloodDecalVariants.get();
            int variant  = RAND.nextInt(Math.min(variants, com.worldhordes.mod.block.BloodSplatterBlock.MAX_VARIANTS));
            level.setBlock(zombiePos,
                    bloodBlock.defaultBlockState()
                            .setValue(com.worldhordes.mod.block.BloodSplatterBlock.VARIANT, variant),
                    Block.UPDATE_CLIENTS | Block.UPDATE_SUPPRESS_DROPS);
        });
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private boolean isVillageMob(LivingEntity entity) {
        String name = entity.getType().toString().toLowerCase();
        return name.contains("villager") || name.contains("iron_golem") || name.contains("wandering_trader");
    }
}
