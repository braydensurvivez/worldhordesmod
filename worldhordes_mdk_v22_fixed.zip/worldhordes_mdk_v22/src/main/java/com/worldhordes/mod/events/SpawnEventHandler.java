package com.worldhordes.mod.events;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationEntity;
import com.worldhordes.mod.data.InfestationZone;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.data.LiveZombieTracker;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Random;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;

public class SpawnEventHandler {

    private static final Random RAND = new Random();

    // -------------------------------------------------------------------------
    // FinalizeSpawn — claimed-chunk block + cap block + density tracking + bonus
    // -------------------------------------------------------------------------

    @SubscribeEvent
    public void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        // --- Block ALL hostile spawns in player-claimed chunks ---
        if (event.getEntity().getType().getCategory() == MobCategory.MONSTER) {
            BlockPos spawnBlockPos = new BlockPos((int) event.getX(), (int) event.getY(), (int) event.getZ());
            int spawnCx = spawnBlockPos.getX() >> 4;
            int spawnCz = spawnBlockPos.getZ() >> 4;
            String spawnDim = DimUtil.getDim(serverLevel);
            if (PlayerClaimedChunkManager.isChunkClaimed(spawnDim, spawnCx, spawnCz)) {
                event.setSpawnCancelled(true);
                return;
            }
        }

        if (!(event.getEntity() instanceof Zombie zombie)) return;

        // Never interfere with WorldHordes' own summons
        if (zombie.getPersistentData().getBoolean("worldhordes_infest_spawn")) return;

        MobSpawnType reason = event.getSpawnType();
        boolean isNaturalOrExternal = (reason == MobSpawnType.NATURAL
                || reason == MobSpawnType.CHUNK_GENERATION
                || reason == MobSpawnType.MOB_SUMMONED);

        // --- Block external spawns when at the live cap ---
        // ONLY applies inside infested zones — outside zones, vanilla spawns are not restricted.
        if (isNaturalOrExternal && WorldHordesConfig.COMMON.blockExternalSpawnsAtCap.get()) {
            if (LiveZombieTracker.isAtHardCap()) {
                // Check if this spawn is inside an infested zone
                String dimForCap = DimUtil.getDim(serverLevel);
                BlockPos capPos = zombie.blockPosition();
                int capCx = capPos.getX() >> 4;
                int capCz = capPos.getZ() >> 4;
                boolean inZone = InfestationZoneRegistry.getEntityFor(dimForCap, capCx, capCz) != null;
                if (inZone) {
                    // Inside an infested zone — let our pulse spawner handle it, block vanilla overflow
                    event.setSpawnCancelled(true);
                    if (WorldHordesConfig.COMMON.debugMode.get()) {
                        WorldHordesMod.LOGGER.debug(
                                "[WorldHordes] Blocked external zombie spawn in infested zone at ({},{},{}) — live cap ({}/{})",
                                (int) event.getX(), (int) event.getY(), (int) event.getZ(),
                                LiveZombieTracker.get(),
                                WorldHordesConfig.COMMON.maxLiveHordeZombies.get());
                    }
                    return;
                }
                // Outside infested zones: vanilla natural spawns are never blocked by WorldHordes cap
            }
        }

        if (reason != MobSpawnType.NATURAL && reason != MobSpawnType.CHUNK_GENERATION) return;

        // --- Darkness gate ---
        if (WorldHordesConfig.COMMON.requireDarknessForNaturalSpawns.get()) {
            BlockPos spawnPos = zombie.blockPosition();
            int lightLevel = serverLevel.getMaxLocalRawBrightness(spawnPos);
            if (lightLevel > WorldHordesConfig.COMMON.maxLightLevelForSpawn.get()) {
                event.setSpawnCancelled(true);
                if (WorldHordesConfig.COMMON.debugMode.get()) {
                    WorldHordesMod.LOGGER.debug(
                            "[WorldHordes] Natural spawn cancelled — light {} > max {} at {}",
                            lightLevel, WorldHordesConfig.COMMON.maxLightLevelForSpawn.get(), spawnPos);
                }
                return;
            }
        }

        // Trickle density into the bank
        HordeDensityManager.recordNaturalSpawn();

        String dim = DimUtil.getDim(serverLevel);
        BlockPos pos = zombie.blockPosition();
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;

        InfestationEntity existingEntity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);

        if (existingEntity != null) {
            InfestationData.onNaturalZombieSpawnInZone(dim, cx, cz);
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Natural zombie in zone at ({},{}) — zone pop now {}",
                        cx, cz, existingEntity.getPopulation());
            }
        } else {
            int seedPop = WorldHordesConfig.COMMON.infestationGrowthRate.get();
            int density = HordeDensityManager.getDensity();
            if (density >= seedPop) {
                InfestationZone newZone = InfestationData.seedInfestationRegion(dim, cx, cz, seedPop);
                if (newZone != null && WorldHordesConfig.COMMON.debugMode.get()) {
                    WorldHordesMod.LOGGER.debug(
                            "[WorldHordes] Natural zombie at ({},{}) seeded new zone (cost={}, bank={})",
                            cx, cz, seedPop, HordeDensityManager.getDensity());
                }
            } else if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Natural zombie at ({},{}) — bank {} < seed cost {}, no zone.",
                        cx, cz, density, seedPop);
            }
        }

        ChunkInfestationLevel infest = InfestationData.get(dim, cx, cz);
        if (infest.isInfested()) {
            spawnExtraZombies(serverLevel, pos, infest);
        }
    }

    // -------------------------------------------------------------------------
    // Extra zombie spawning (tier-based bonus on top of a natural spawn)
    // -------------------------------------------------------------------------

    private void spawnExtraZombies(ServerLevel level, BlockPos origin, ChunkInfestationLevel infest) {
        int extraCount = infest.getExtraZombies();
        int groupBonus = infest.getGroupSizeBonus();
        int totalExtra = extraCount + (groupBonus > 0 ? RAND.nextInt(groupBonus + 1) : 0);
        if (totalExtra <= 0) return;

        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Infested chunk (tier {}) spawning +{} extra zombies",
                    infest.getTier(), totalExtra);
        }

        for (int i = 0; i < totalExtra; i++) {
            if (LiveZombieTracker.isAtHardCap()) break;

            int dx = RAND.nextInt(17) - 8;
            int dz = RAND.nextInt(17) - 8;

            BlockPos spawnPos = findSafeSpawn(level, origin.offset(dx, 0, dz),
                    WorldHordesConfig.COMMON.requireDarknessForNaturalSpawns.get());
            if (spawnPos == null) continue;

            Zombie z = new Zombie(EntityType.ZOMBIE, level);
            z.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
            z.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
            z.getPersistentData().putInt("worldhordes_src_cx", origin.getX() >> 4);
            z.getPersistentData().putInt("worldhordes_src_cz", origin.getZ() >> 4);
            z.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos), MobSpawnType.MOB_SUMMONED, null, null);
            level.addFreshEntity(z);
            LiveZombieTracker.onSpawn();

            HordeDensityManager.recordNaturalSpawn();
        }
    }

    // -------------------------------------------------------------------------
    // Safe spawn position finder
    // -------------------------------------------------------------------------

    private BlockPos findSafeSpawn(ServerLevel level, BlockPos base, boolean preferDark) {
        int maxLight = WorldHordesConfig.COMMON.maxLightLevelForSpawn.get();

        if (preferDark) {
            for (int attempt = 0; attempt < 8; attempt++) {
                int ox = RAND.nextInt(9) - 4;
                int oz = RAND.nextInt(9) - 4;
                BlockPos candidate = findValidColumn(level, base.offset(ox, 0, oz));
                if (candidate != null && level.getMaxLocalRawBrightness(candidate) <= maxLight) {
                    return candidate;
                }
            }
        }

        return findValidColumn(level, base);
    }

    private BlockPos findValidColumn(ServerLevel level, BlockPos base) {
        for (int dy = 5; dy >= -5; dy--) {
            BlockPos pos   = base.above(dy);
            BlockPos below = pos.below();
            if (level.getBlockState(pos).isAir()
                    && level.getBlockState(pos.above()).isAir()
                    && level.getBlockState(below).isCollisionShapeFullBlock(level, below)) {
                return pos;
            }
        }
        return null;
    }
}
