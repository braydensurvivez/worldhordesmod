package com.worldhordes.mod.command;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.LiveZombieTracker;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationEntity;
import com.worldhordes.mod.data.InfestationZone;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.horde.HordeManager;
import com.worldhordes.mod.horde.WanderingHorde;
import com.worldhordes.mod.util.DimUtil;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.List;
import java.util.Map;
import com.worldhordes.mod.data.NaturalSpawnGatekeeper;
import com.worldhordes.mod.data.PlayerClaimedChunkManager;
import java.util.Set;
import java.util.UUID;

public class WorldHordesCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {

        // /wh — any player, no op
        dispatcher.register(Commands.literal("wh")
            .executes(WorldHordesCommand::cmdPlayerInfo)
            .then(Commands.literal("tokens")
                .executes(WorldHordesCommand::cmdPlayerTokenInfo))
            .then(Commands.literal("map")
                .executes(WorldHordesCommand::cmdClaimMap))
            .then(Commands.literal("claim")
                .executes(WorldHordesCommand::cmdPlayerClaim))
            .then(Commands.literal("unclaim")
                .executes(WorldHordesCommand::cmdPlayerUnclaim)));

        // /worldhordes — any player (no permission required), shows quick summary
        dispatcher.register(Commands.literal("worldhordes")
            // No-op player overview (no permission required)
            .executes(WorldHordesCommand::cmdPublicOverview)

            // All sub-commands below require op
            .then(Commands.literal("status")
                .requires(src -> src.hasPermission(2))
                .executes(WorldHordesCommand::cmdStatus))

            .then(Commands.literal("density")
                .requires(src -> src.hasPermission(2))
                .executes(WorldHordesCommand::cmdDensityGet)
                .then(Commands.literal("set")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0))
                        .executes(WorldHordesCommand::cmdDensitySet)))
                .then(Commands.literal("add")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(-100000, 100000))
                        .executes(WorldHordesCommand::cmdDensityAdd))))

            .then(Commands.literal("infest")
                .requires(src -> src.hasPermission(2))
                .executes(WorldHordesCommand::cmdInfestGet)
                .then(Commands.literal("set")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0))
                        .executes(WorldHordesCommand::cmdInfestSet)))
                .then(Commands.literal("add")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(-100000, 100000))
                        .executes(WorldHordesCommand::cmdInfestAdd)))
                .then(Commands.literal("clear")
                    .executes(WorldHordesCommand::cmdInfestClear))
                .then(Commands.literal("list")
                    .executes(WorldHordesCommand::cmdInfestList)))

            .then(Commands.literal("horde")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("list")
                    .executes(WorldHordesCommand::cmdHordeList))
                .then(Commands.literal("spawn")
                    .executes(WorldHordesCommand::cmdHordeSpawn))
                .then(Commands.literal("clear")
                    .executes(WorldHordesCommand::cmdHordeClear))
                .then(Commands.literal("tp")
                    .then(Commands.argument("index", IntegerArgumentType.integer(1))
                        .executes(WorldHordesCommand::cmdHordeTp))))

            .then(Commands.literal("spawnpoints")
                .requires(src -> src.hasPermission(2))
                .executes(WorldHordesCommand::cmdSpawnPointsGet)
                .then(Commands.literal("percentage")
                    .then(Commands.argument("percent", IntegerArgumentType.integer(0, 100))
                        .executes(WorldHordesCommand::cmdSpawnPointsPct)))
                .then(Commands.literal("deduct")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0, 10000))
                        .executes(WorldHordesCommand::cmdSpawnPointsDeduct)))
                .then(Commands.literal("reset")
                    .executes(WorldHordesCommand::cmdSpawnPointsReset)))

            // /worldhordes naturalspawns <value> — any player (no op)
            .then(Commands.literal("naturalspawns")
                .then(Commands.argument("multiplier", DoubleArgumentType.doubleArg(0.0))
                    .executes(WorldHordesCommand::cmdNaturalSpawns)))

            .then(Commands.literal("debug")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("toggle")
                    .executes(WorldHordesCommand::cmdDebugToggle))
                .then(Commands.literal("overlay")
                    .executes(WorldHordesCommand::cmdDebugOverlay))
                .then(Commands.literal("zone")
                    .then(Commands.literal("delete")
                        .executes(WorldHordesCommand::cmdDebugZoneDelete))))

            .then(Commands.literal("help")
                .executes(WorldHordesCommand::cmdHelp))

            .then(Commands.literal("naturalspawn")
                .requires(src -> src.hasPermission(2))
                .executes(WorldHordesCommand::cmdNaturalSpawnGateGet)
                .then(Commands.argument("time", IntegerArgumentType.integer(1))
                    .then(Commands.argument("members", IntegerArgumentType.integer(1))
                        .executes(WorldHordesCommand::cmdNaturalSpawnGateSet)))
                .then(Commands.literal("reset")
                    .executes(WorldHordesCommand::cmdNaturalSpawnGateReset)))

            .then(Commands.literal("claim")
                .requires(src -> src.hasPermission(2))
                .executes(WorldHordesCommand::cmdClaimStatus)
                .then(Commands.literal("tokens")
                    .then(Commands.literal("give")
                        .then(Commands.argument("player", net.minecraft.commands.arguments.EntityArgument.player())
                            .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                .executes(WorldHordesCommand::cmdClaimGiveTokens))))
                    .then(Commands.literal("set")
                        .then(Commands.argument("player", net.minecraft.commands.arguments.EntityArgument.player())
                            .then(Commands.argument("amount", IntegerArgumentType.integer(0))
                                .executes(WorldHordesCommand::cmdClaimSetTokens)))))
                .then(Commands.literal("list")
                    .executes(WorldHordesCommand::cmdClaimList)))
        );
    }

    // =========================================================================
    //  PUBLIC OVERVIEW — /worldhordes (no op required)
    // =========================================================================

    /**
     * /worldhordes with no sub-command — available to ALL players.
     * Shows: active infestation count, total zone members, and whether a horde
     * is close to forming.  Quick at-a-glance world state.
     */
    private static int cmdPublicOverview(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();

        int zoneCount   = InfestationZoneRegistry.getZoneCount();
        int totalPop    = 0;
        for (InfestationEntity e : InfestationZoneRegistry.getAllEntities().values()) {
            totalPop += e.getPopulation();
        }
        int activeHordes = HordeManager.getActiveHordes().size();
        int density      = HordeDensityManager.getDensity();
        int threshold    = WorldHordesConfig.COMMON.densityThresholdForHorde.get();

        send(src, "§6=== WorldHordes Overview ===");
        send(src, "§7Active infested zones: §e" + zoneCount
                + " §7(each covers 64 chunks)");
        send(src, "§7Total infestation members: §e" + totalPop);
        send(src, "§7Wandering hordes active: §e" + activeHordes);

        if (density >= threshold) {
            send(src, "§c⚠ Horde density threshold reached! A wandering horde may form soon.");
        } else {
            int needed = threshold - density;
            send(src, "§7Horde density: §f" + density + "§7/§f" + threshold
                    + " §7(§f" + needed + "§7 away from threshold)");
        }

        send(src, "§7Tip: §e/wh §7for your local area · §e/worldhordes help §7for all commands");
        return 1;
    }

    // =========================================================================
    //  PLAYER INFO  (/wh)
    // =========================================================================

    private static int cmdPlayerInfo(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ServerPlayer player = getPlayer(src);

        int density    = HordeDensityManager.getDensity();
        int threshold  = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        int maxDensity = WorldHordesConfig.COMMON.maxGlobalDensity.get();
        int zones      = InfestationZoneRegistry.getZoneCount();
        int spawnRate  = HordeDensityManager.getRecentSpawnRate();

        int barWidth = 20;
        int filled   = maxDensity > 0 ? Math.min(barWidth, density * barWidth / maxDensity) : 0;
        String bar   = "§a" + "█".repeat(filled) + "§7" + "░".repeat(barWidth - filled);

        send(src, "§6★ World Horde Density ★");
        send(src, "  " + bar + " §f" + density + "§7/" + maxDensity);

        int seedCost = WorldHordesConfig.COMMON.infestationGrowthRate.get();
        if (density >= seedCost) {
            send(src, "  §cInfestation can form! §7(bank ≥ seed cost " + seedCost + ")");
        } else {
            int needed = seedCost - density;
            send(src, "  §eNext infestation needs §f" + needed + " §emore density §7(seed cost: " + seedCost + ")");
        }

        if (density >= threshold) {
            send(src, "  §c⚠ Wandering horde threshold met! (" + density + " ≥ " + threshold + ")");
        } else {
            send(src, "  §7Horde threshold: §f" + threshold + " §7(" + (threshold - density) + " away)");
        }

        send(src, "  §7Active infestations: §f" + zones
                + "  §7Spawn rate: §f" + spawnRate + "/min"
                + "  §7NatSpawn mult: §f" + String.format("%.3f", HordeDensityManager.getNaturalSpawnMultiplier()));

        if (player != null) {
            ServerLevel level = player.serverLevel();
            String dim = DimUtil.getDim(level);
            ChunkPos cp = new ChunkPos(player.blockPosition());
            int cx = cp.x, cz = cp.z;

            InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(dim, cx, cz);
            InfestationEntity zoneEntity  = InfestationZoneRegistry.getEntityFor(dim, cx, cz);

            send(src, "§6★ Your Location ★  §7chunk (" + cx + "," + cz + ")");

            if (zoneEntity != null) {
                int pop = zoneEntity.getPopulation();
                ChunkInfestationLevel infest = InfestationData.get(dim, cx, cz);
                String roleStr = switch (role) {
                    case CORE       -> "§c[CORE]";
                    case OUTER_RING -> "§6[OUTER RING]";
                    default         -> "§7[zone]";
                };
                String combatStr = zoneEntity.isInCombat()
                        ? " §c[COMBAT LOCK " + (zoneEntity.getCombatLockRemainingMs() / 1000) + "s]" : "";
                send(src, "  " + roleStr + " §fZone population: §e" + pop
                        + "  " + tierLabel(infest.getTier()) + combatStr);
                ChunkInfestationLevel.Tier tier = infest.getTier();
                String danger;
                if      (tier == ChunkInfestationLevel.Tier.TIER3) danger = "§c★★★ DANGER";
                else if (tier == ChunkInfestationLevel.Tier.TIER2) danger = "§6★★ ELEVATED";
                else if (tier == ChunkInfestationLevel.Tier.TIER1) danger = "§e★ CAUTION";
                else                                                danger = "§a✔ CLEAR";
                send(src, "  Threat level: " + danger);
            } else {
                send(src, "  §a✔ No active infestation here.");
            }

            int[] nearest = InfestationData.getNearestInfestedRegionCentre(dim, cx, cz, 64);
            if (nearest != null && zoneEntity == null) {
                int dist = Math.max(Math.abs(cx - nearest[0]), Math.abs(cz - nearest[1]));
                send(src, "  §7Nearest infestation: §e" + dist + " chunk(s) away");
            }

            // Token balance reminder
            int tokens = PlayerClaimedChunkManager.getTokens(player.getUUID());
            send(src, "  §7Claim tokens: §e" + tokens + " §7(§f/wh tokens§7 for details)");
        }
        return 1;
    }

    // =========================================================================
    //  NATURAL SPAWNS MULTIPLIER — /worldhordes naturalspawns <value> (no op)
    // =========================================================================

    /**
     * /worldhordes naturalspawns <multiplier>
     *
     * Any player can call this to set the natural-spawn density multiplier for the world.
     * 0.05 = each spawn contributes 5% of a single density point (very slow growth).
     * 1.0  = default, full contribution.
     * 5.0  = each spawn contributes 5× more than normal (amplified growth).
     *
     * This multiplier is applied AFTER the automatic devaluation pass, so it scales the
     * final effective contribution up or down.
     */
    private static int cmdNaturalSpawns(CommandContext<CommandSourceStack> ctx) {
        double mult = DoubleArgumentType.getDouble(ctx, "multiplier");
        HordeDensityManager.setNaturalSpawnMultiplier(mult);

        String description;
        if      (mult <= 0.0)  description = "§cOFF §7(natural spawns contribute 0 density)";
        else if (mult < 0.1)   description = "§7very slow §7(~" + String.format("%.2f", mult) + "× normal)";
        else if (mult < 0.5)   description = "§etrickle §7(" + String.format("%.2f", mult) + "× normal)";
        else if (mult < 1.0)   description = "§ebelow normal §7(" + String.format("%.2f", mult) + "×)";
        else if (mult == 1.0)  description = "§anormal §7(1.0× — default)";
        else if (mult <= 2.0)  description = "§6elevated §7(" + String.format("%.2f", mult) + "×)";
        else                   description = "§camplified §7(" + String.format("%.2f", mult) + "×)";

        send(ctx.getSource(), "§6[NaturalSpawns] §fMultiplier set to §e"
                + String.format("%.4f", mult) + "§f — " + description);
        send(ctx.getSource(), "§7Effect: every natural zombie spawn contributes §f"
                + String.format("%.4f", mult) + "× §7its computed density value to the world horde bank.");
        return 1;
    }

    // =========================================================================
    //  STATUS (op)
    // =========================================================================

    private static int cmdStatus(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ServerPlayer player = getPlayer(src);

        int density = HordeDensityManager.getDensity();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        int activeHordes = HordeManager.getActiveHordes().size();
        int zoneCount = InfestationZoneRegistry.getZoneCount();

        send(src, "§6=== WorldHordes Status ===");
        send(src, "§eGlobal Density: §f" + density + " §7/ " + WorldHordesConfig.COMMON.maxGlobalDensity.get()
                + (density >= threshold ? " §c[HORDE THRESHOLD MET]" : ""));
        send(src, "§eActive Hordes: §f" + activeHordes + " §7/ " + WorldHordesConfig.COMMON.maxActiveHordes.get());
        send(src, "§eActive Infestations: §f" + zoneCount
                + " §7(each covers 64 chunks: 4×4 core + outer ring (8×8 total))");
        send(src, "§eNatural Spawn Rate: §f"
                + HordeDensityManager.getRecentSpawnRate()
                + "§7/min  baseline=§f" + WorldHordesConfig.COMMON.naturalSpawnRateBaseline.get()
                + "  §eNatSpawn mult: §f" + String.format("%.4f", HordeDensityManager.getNaturalSpawnMultiplier())
                + "  §eSeed cost: §f" + WorldHordesConfig.COMMON.infestationGrowthRate.get());
        send(src, "§eSpawn-Point Overrides: §fpct=§e"
                + HordeDensityManager.getSpawnPointPercentage() + "%"
                + " §fdeduct=§e" + HordeDensityManager.getSpawnPointFlatDeduct());
        send(src, "§eLive Horde Zombies: §f"
                + LiveZombieTracker.get()
                + "§7/§f" + WorldHordesConfig.COMMON.maxLiveHordeZombies.get()
                + (LiveZombieTracker.isAtHardCap() ? " §c[CAP REACHED]" : "")
                + (LiveZombieTracker.isInActiveCombat() ? " §6[COMBAT PAUSE ACTIVE]" : ""));

        // Show which dens are in combat lock
        int combatDens = 0;
        for (InfestationEntity e : InfestationZoneRegistry.getAllEntities().values()) {
            if (e.isInCombat()) combatDens++;
        }
        if (combatDens > 0) {
            send(src, "§6[Combat Lock] §f" + combatDens + " den(s) currently suppressing regen/growth.");
        }

        if (player != null) {
            ServerLevel level = player.serverLevel();
            String dim = DimUtil.getDim(level);
            ChunkPos cp = new ChunkPos(player.blockPosition());
            ChunkInfestationLevel infest = InfestationData.get(dim, cp.x, cp.z);
            InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(dim, cp.x, cp.z);
            String roleLabel = switch (role) {
                case CORE       -> "§c[CORE ZONE]";
                case OUTER_RING -> "§6[OUTER RING]";
                default         -> "§7[no zone]";
            };
            InfestationEntity localEntity = InfestationZoneRegistry.getEntityFor(dim, cp.x, cp.z);
            String combatStr = (localEntity != null && localEntity.isInCombat())
                    ? " §c[COMBAT LOCK " + (localEntity.getCombatLockRemainingMs() / 1000) + "s]" : "";
            send(src, "§eYour Chunk (" + cp.x + "," + cp.z + "): §f" + infest.getLevel()
                    + " §7[" + tierLabel(infest.getTier()) + "§7]"
                    + " " + roleLabel
                    + (infest.hasActiveHorde() ? " §c[ACTIVE HORDE]" : "")
                    + (infest.isCleared() ? " §a[CLEARED]" : "")
                    + " §7reserve=" + infest.getZombieReserve()
                    + combatStr);
        }

        send(src, "§eDebug Mode: " + (WorldHordesConfig.COMMON.debugMode.get() ? "§aON" : "§cOFF"));
        return 1;
    }

    // =========================================================================
    //  DENSITY (op)
    // =========================================================================

    private static int cmdDensityGet(CommandContext<CommandSourceStack> ctx) {
        int d = HordeDensityManager.getDensity();
        int max = WorldHordesConfig.COMMON.maxGlobalDensity.get();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        send(ctx.getSource(), "§6[Density] §fCurrent: §e" + d + " §7/ " + max
                + (d >= threshold ? " §c[ABOVE HORDE THRESHOLD " + threshold + "]" : " §7[threshold: " + threshold + "]"));
        return 1;
    }

    private static int cmdDensitySet(CommandContext<CommandSourceStack> ctx) {
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        int current = HordeDensityManager.getDensity();
        HordeDensityManager.addDensity(amount - current);
        send(ctx.getSource(), "§6[Density] §fSet to §e" + HordeDensityManager.getDensity());
        return 1;
    }

    private static int cmdDensityAdd(CommandContext<CommandSourceStack> ctx) {
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        HordeDensityManager.addDensity(amount);
        send(ctx.getSource(), "§6[Density] §f" + (amount >= 0 ? "+" : "") + amount + " → §e" + HordeDensityManager.getDensity());
        return 1;
    }

    // =========================================================================
    //  INFEST (op)
    // =========================================================================

    private static int cmdInfestGet(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        ChunkInfestationLevel infest = InfestationData.get(dim, cp.x, cp.z);
        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + "): "
                + "§e" + infest.getLevel() + " §7/ " + WorldHordesConfig.COMMON.infestationMaxLevel.get()
                + " " + tierLabel(infest.getTier())
                + (infest.hasActiveHorde() ? " §c[ACTIVE HORDE]" : "")
                + (infest.isCleared() ? " §a[CLEARED]" : "")
                + (infest.shouldSpread() ? " §d[SPREADING]" : "")
                + " §7reserve=§f" + infest.getZombieReserve());
        return 1;
    }

    private static int cmdInfestSet(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        InfestationData.getOrCreate(dim, cp.x, cp.z).setLevel(amount);
        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + ") set to §e" + amount
                + " " + tierLabel(InfestationData.get(dim, cp.x, cp.z).getTier()));
        return 1;
    }

    private static int cmdInfestAdd(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        if (amount >= 0) InfestationData.addInfestation(dim, cp.x, cp.z, amount);
        else InfestationData.removeInfestation(dim, cp.x, cp.z, -amount);
        int newLevel = InfestationData.get(dim, cp.x, cp.z).getLevel();
        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + ") "
                + (amount >= 0 ? "+" : "") + amount + " → §e" + newLevel
                + " " + tierLabel(InfestationData.get(dim, cp.x, cp.z).getTier()));
        return 1;
    }

    private static int cmdInfestClear(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        InfestationData.markChunkCleared(dim, cp.x, cp.z);
        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + ") §acleared.");
        return 1;
    }

    private static int cmdInfestList(CommandContext<CommandSourceStack> ctx) {
        Map<String, InfestationZone>   zones    = InfestationZoneRegistry.getAllZoneMap();
        Map<String, InfestationEntity> entities = InfestationZoneRegistry.getAllEntities();
        if (zones.isEmpty()) { send(ctx.getSource(), "§6[Infest] §fNo active infestations."); return 1; }
        send(ctx.getSource(), "§6[Infest] §f" + zones.size() + " active infestation(s):");
        int count = 0;
        for (Map.Entry<String, InfestationZone> e : zones.entrySet()) {
            if (count++ >= 25) { send(ctx.getSource(), "§7  ... and " + (zones.size() - 25) + " more."); break; }
            String key = e.getKey();
            InfestationZone zone = e.getValue();
            InfestationEntity entity = entities.get(key);
            String dim = InfestationZoneRegistry.extractDim(key);
            int cx = zone.getZoneCentreX(), cz = zone.getZoneCentreZ();
            int pop = entity != null ? entity.getPopulation() : -1;
            ChunkInfestationLevel centre = InfestationData.get(dim, cx, cz);
            String combatStr = (entity != null && entity.isInCombat()) ? " §c[COMBAT]" : "";
            send(ctx.getSource(), "  §7" + dim + " centre=(" + cx + "," + cz + ")"
                    + " §f→ pop=§e" + pop + " " + tierLabel(centre.getTier())
                    + (entity != null && entity.isMarkedForDestruction() ? " §c[DYING]" : "")
                    + (entity != null && entity.isActive() ? " §a[ACTIVE]" : "")
                    + combatStr);
        }
        return 1;
    }

    // =========================================================================
    //  HORDE (op)
    // =========================================================================

    private static int cmdHordeList(CommandContext<CommandSourceStack> ctx) {
        List<WanderingHorde> hordes = HordeManager.getActiveHordes();
        if (hordes.isEmpty()) { send(ctx.getSource(), "§6[Horde] §fNo active hordes."); return 1; }
        send(ctx.getSource(), "§6[Horde] §f" + hordes.size() + " active horde(s):");
        int i = 1;
        for (WanderingHorde h : hordes) {
            send(ctx.getSource(), "  §e#" + i + " " + h.getId().toString().substring(0, 8)
                    + " §7dim=§f" + h.getDimension()
                    + " §7chunk=§f(" + h.getChunkX() + "," + h.getChunkZ() + ")"
                    + " §7size=§f" + h.getSize()
                    + " §7steps=§f" + h.getStepsTaken() + "/" + h.getMaxSteps()
                    + (h.isSettled() ? " §a[SETTLED]" : " §b[WANDERING]"));
            i++;
        }
        return 1;
    }

    private static int cmdHordeSpawn(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        if (HordeDensityManager.getDensity() < threshold)
            HordeDensityManager.addDensity(threshold - HordeDensityManager.getDensity());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        java.util.Random rand = new java.util.Random();
        int offsetX = (10 + rand.nextInt(20)) * (rand.nextBoolean() ? 1 : -1);
        int offsetZ = (10 + rand.nextInt(20)) * (rand.nextBoolean() ? 1 : -1);
        int hcx = cp.x + offsetX, hcz = cp.z + offsetZ;
        int minSize = WorldHordesConfig.COMMON.hordeMinSize.get();
        int maxSize = WorldHordesConfig.COMMON.hordeMaxSize.get();
        int size = minSize + rand.nextInt(Math.max(1, maxSize - minSize));
        HordeManager.forceSpawnHorde(DimUtil.getDim(player.serverLevel()), hcx, hcz, size);
        send(ctx.getSource(), "§6[Horde] §fForce-spawned horde [size=" + size + "] at chunk ("
                + hcx + "," + hcz + ").");
        return 1;
    }

    private static int cmdHordeClear(CommandContext<CommandSourceStack> ctx) {
        int count = HordeManager.clearAllHordes();
        send(ctx.getSource(), "§6[Horde] §fRemoved §e" + count + "§f active horde(s).");
        return 1;
    }

    private static int cmdHordeTp(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        int index = IntegerArgumentType.getInteger(ctx, "index");
        List<WanderingHorde> hordes = HordeManager.getActiveHordes();
        if (hordes.isEmpty()) { send(ctx.getSource(), "§c[Horde] No active hordes."); return 0; }
        if (index < 1 || index > hordes.size()) { send(ctx.getSource(), "§c[Horde] Index out of range."); return 0; }
        WanderingHorde horde = hordes.get(index - 1);
        ServerLevel level = HordeManager.getServer().getLevel(Level.OVERWORLD);
        if (level == null) { send(ctx.getSource(), "§cCould not access overworld."); return 0; }
        int blockX = horde.getChunkX() * 16 + 8;
        int blockZ = horde.getChunkZ() * 16 + 8;
        int blockY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, blockX, blockZ) + 1;
        player.teleportTo(level, blockX + 0.5, blockY, blockZ + 0.5, player.getYRot(), player.getXRot());
        send(ctx.getSource(), "§6[Horde] §fTeleported to horde §e#" + index + " §fat §e(" + blockX + "," + blockY + "," + blockZ + ").");
        return 1;
    }

    // =========================================================================
    //  SPAWNPOINTS (op)
    // =========================================================================

    private static int cmdSpawnPointsGet(CommandContext<CommandSourceStack> ctx) {
        int pct    = HordeDensityManager.getSpawnPointPercentage();
        int deduct = HordeDensityManager.getSpawnPointFlatDeduct();
        double mult = HordeDensityManager.getNaturalSpawnMultiplier();
        int basePts = WorldHordesConfig.COMMON.densityPerZombieSpawn.get();
        send(ctx.getSource(), "§6=== Spawn-Point Tuning ===");
        send(ctx.getSource(), "§7Base density per spawn (config): §f" + basePts);
        send(ctx.getSource(), "§7NatSpawn multiplier: §e" + String.format("%.4f", mult) + " §7(via /worldhordes naturalspawns)");
        send(ctx.getSource(), "§7Runtime percentage: §e" + pct + "%");
        send(ctx.getSource(), "§7Runtime flat deduct: §e" + deduct);
        send(ctx.getSource(), "§7Natural spawn gate: §e"
                + NaturalSpawnGatekeeper.getEffectiveMaxMembers() + " §7members per §e"
                + NaturalSpawnGatekeeper.getEffectiveCooldownSeconds() + "s §7(§e"
                + NaturalSpawnGatekeeper.globalRemaining() + " §7slots remain)");
        return 1;
    }

    private static int cmdSpawnPointsPct(CommandContext<CommandSourceStack> ctx) {
        int pct = IntegerArgumentType.getInteger(ctx, "percent");
        HordeDensityManager.setSpawnPointPercentage(pct);
        send(ctx.getSource(), "§6[SpawnPoints] §fPercentage set to §e" + pct + "%.");
        return 1;
    }

    private static int cmdSpawnPointsDeduct(CommandContext<CommandSourceStack> ctx) {
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        HordeDensityManager.setSpawnPointFlatDeduct(amount);
        send(ctx.getSource(), "§6[SpawnPoints] §fFlat deduct set to §e" + amount + ".");
        return 1;
    }

    private static int cmdSpawnPointsReset(CommandContext<CommandSourceStack> ctx) {
        HordeDensityManager.setSpawnPointPercentage(100);
        HordeDensityManager.setSpawnPointFlatDeduct(0);
        HordeDensityManager.setNaturalSpawnMultiplier(1.0);
        send(ctx.getSource(), "§6[SpawnPoints] §fReset to defaults (100%, 0 deduct, 1.0× mult).");
        return 1;
    }

    // =========================================================================
    //  DEBUG (op)
    // =========================================================================

    private static int cmdDebugZoneDelete(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        ServerLevel level = player.serverLevel();
        String dim = DimUtil.getDim(level);
        ChunkPos cp = new ChunkPos(player.blockPosition());
        int cx = cp.x, cz = cp.z;

        com.worldhordes.mod.data.InfestationEntity entity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
        if (entity == null) {
            send(ctx.getSource(), "§c[Debug] No infested zone at your current chunk (" + cx + "," + cz + ").");
            send(ctx.getSource(), "§7Move into an infested zone first, then run this command.");
            return 0;
        }

        InfestationZone zone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
        int centre_x = zone != null ? zone.getZoneCentreX() : cx;
        int centre_z = zone != null ? zone.getZoneCentreZ() : cz;
        int pop = entity.getPopulation();

        // Kill all WorldHordes-tagged zombies in the zone
        int killed = 0;
        if (zone != null) {
            for (int[] chunk : zone.getAllChunks()) {
                if (!level.hasChunk(chunk[0], chunk[1])) continue;
                net.minecraft.world.level.chunk.LevelChunk lc = level.getChunk(chunk[0], chunk[1]);
                int bx = lc.getPos().getMinBlockX();
                int bz = lc.getPos().getMinBlockZ();
                net.minecraft.world.phys.AABB chunkBox = new net.minecraft.world.phys.AABB(
                        bx, level.getMinBuildHeight(), bz,
                        bx + 16, level.getMaxBuildHeight(), bz + 16);
                for (net.minecraft.world.entity.monster.Zombie z : level.getEntitiesOfClass(
                        net.minecraft.world.entity.monster.Zombie.class, chunkBox,
                        zz -> zz.getPersistentData().getBoolean("worldhordes_infest_spawn"))) {
                    z.discard();
                    killed++;
                }
            }
        }

        // Destroy the zone fully
        HordeManager.onChunkFullyCleared(level, dim, cx, cz);

        send(ctx.getSource(), "§6[Debug] §fDeleted infested zone at centre (§e" + centre_x + "§f, §e" + centre_z + "§f).");
        send(ctx.getSource(), "§7  Population was §e" + pop + "§7. Discarded §e" + killed + "§7 tagged zombie(s).");
        send(ctx.getSource(), "§7  Zone and all blood decals removed. NaturalSpawn gate cleared for this zone.");
        return 1;
    }

    private static int cmdDebugToggle(CommandContext<CommandSourceStack> ctx) {
        boolean current = WorldHordesConfig.COMMON.debugMode.get();
        WorldHordesConfig.COMMON.debugMode.set(!current);
        send(ctx.getSource(), "§6[Debug] §fDebug mode: " + (!current ? "§aON" : "§cOFF"));
        return 1;
    }

    private static int cmdDebugOverlay(CommandContext<CommandSourceStack> ctx) {
        send(ctx.getSource(), "§6[Debug] §fUse §eF3 + I§f in-game to toggle the chunk overlay.");
        return 1;
    }

    // =========================================================================
    //  NATURAL SPAWN GATE — /wordhordes naturalspawn [time] [members]  (op)
    // =========================================================================

    /**
     * /worldhordes naturalspawn — show current gate settings
     */
    private static int cmdNaturalSpawnGateGet(CommandContext<CommandSourceStack> ctx) {
        int secs    = NaturalSpawnGatekeeper.getEffectiveCooldownSeconds();
        int members = NaturalSpawnGatekeeper.getEffectiveMaxMembers();
        int secOverride  = NaturalSpawnGatekeeper.getCooldownSecondsOverride();
        int memOverride  = NaturalSpawnGatekeeper.getMaxMembersOverride();
        long globalCdMs  = NaturalSpawnGatekeeper.globalCooldownRemainingMs();

        send(ctx.getSource(), "§6=== Natural Spawn Gate ===");
        send(ctx.getSource(), "§7Cooldown: §e" + secs + "s"
                + (secOverride > 0 ? " §c[override]" : " §a[config]")
                + "  Members/window: §e" + members
                + (memOverride > 0 ? " §c[override]" : " §a[config]"));
        send(ctx.getSource(), "§7Global window: §e" + NaturalSpawnGatekeeper.globalRemaining()
                + "§7 slots left, resets in §e" + (globalCdMs / 1000) + "s");
        send(ctx.getSource(), "§7Usage: §f/worldhordes naturalspawn [time_seconds] [max_members]");
        return 1;
    }

    /**
     * /worldhordes naturalspawn [time] [members] — set cooldown + quota
     */
    private static int cmdNaturalSpawnGateSet(CommandContext<CommandSourceStack> ctx) {
        int secs    = IntegerArgumentType.getInteger(ctx, "time");
        int members = IntegerArgumentType.getInteger(ctx, "members");
        NaturalSpawnGatekeeper.setCooldownSecondsOverride(secs);
        NaturalSpawnGatekeeper.setMaxMembersOverride(members);
        NaturalSpawnGatekeeper.forceReset(); // reset current windows immediately
        send(ctx.getSource(), "§6[NaturalSpawn Gate] §fSet to §e" + members + " §fmembers per §e" + secs + "s §fcooldown.");
        return 1;
    }

    /**
     * /worldhordes naturalspawn reset — restore config defaults
     */
    private static int cmdNaturalSpawnGateReset(CommandContext<CommandSourceStack> ctx) {
        NaturalSpawnGatekeeper.resetOverrides();
        NaturalSpawnGatekeeper.forceReset();
        send(ctx.getSource(), "§6[NaturalSpawn Gate] §fOverrides cleared — using config values ("
                + NaturalSpawnGatekeeper.getEffectiveCooldownSeconds() + "s / "
                + NaturalSpawnGatekeeper.getEffectiveMaxMembers() + " members).");
        return 1;
    }

    // =========================================================================
    //  CLAIM SYSTEM (op management + player token views)
    // =========================================================================

    // =========================================================================
    //  PLAYER CLAIM / UNCLAIM — /wh claim  /wh unclaim  (no op required)
    // =========================================================================

    /**
     * /wh claim — spends 1 token and immediately claims the chunk the player is
     * standing in.  No block placement required.
     */
    private static int cmdPlayerClaim(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        if (!WorldHordesConfig.COMMON.enableClaimedChunks.get()) {
            send(ctx.getSource(), "§c[Claim] The claim system is currently disabled.");
            return 0;
        }

        int tokens = PlayerClaimedChunkManager.getTokens(player.getUUID());
        if (tokens <= 0) {
            send(ctx.getSource(), "§c[Claim] You have no claim tokens!");
            send(ctx.getSource(), "§7Earn tokens by fully clearing an infested zone.");
            send(ctx.getSource(), "§7Check your balance with §f/wh tokens§7.");
            return 0;
        }

        ServerLevel level = player.serverLevel();
        String dim = DimUtil.getDim(level);
        ChunkPos cp = new ChunkPos(player.blockPosition());
        int cx = cp.x, cz = cp.z;

        if (PlayerClaimedChunkManager.isChunkClaimed(dim, cx, cz)) {
            send(ctx.getSource(), "§e[Claim] This chunk (§f" + cx + "§e, §f" + cz + "§e) is already claimed.");
            return 0;
        }

        // Spend token and register the claim
        PlayerClaimedChunkManager.spendToken(player.getUUID());
        PlayerClaimedChunkManager.claimChunk(dim, cx, cz);

        int remaining = PlayerClaimedChunkManager.getTokens(player.getUUID());
        send(ctx.getSource(), "§a[Claim] Chunk (§f" + cx + "§a, §f" + cz + "§a) is now claimed!");
        send(ctx.getSource(), "§7Tokens remaining: §e" + remaining
                + "  §7|  §f/wh map §7to view · §f/wh unclaim §7to release this chunk");
        return 1;
    }

    /**
     * /wh unclaim — releases the claim on the chunk the player is standing in.
     * Returns the token to the player.
     */
    private static int cmdPlayerUnclaim(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        ServerLevel level = player.serverLevel();
        String dim = DimUtil.getDim(level);
        ChunkPos cp = new ChunkPos(player.blockPosition());
        int cx = cp.x, cz = cp.z;

        if (!PlayerClaimedChunkManager.isChunkClaimed(dim, cx, cz)) {
            send(ctx.getSource(), "§e[Claim] This chunk (§f" + cx + "§e, §f" + cz + "§e) is not claimed.");
            return 0;
        }

        PlayerClaimedChunkManager.unclaimChunk(dim, cx, cz);
        // Refund the token
        int current = PlayerClaimedChunkManager.getTokens(player.getUUID());
        PlayerClaimedChunkManager.setTokens(player.getUUID(), current + 1);

        send(ctx.getSource(), "§6[Claim] Chunk (§f" + cx + "§6, §f" + cz + "§6) unclaimed. Token refunded.");
        send(ctx.getSource(), "§7Tokens: §e" + (current + 1) + "  §7|  §f/wh map §7to view your area");
        return 1;
    }

    /** /wh tokens — no op required */
    private static int cmdPlayerTokenInfo(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        int tokens = PlayerClaimedChunkManager.getTokens(player.getUUID());
        // Cost is always 1 token per 1 chunk
        send(ctx.getSource(), "§6★ Claim Tokens ★");
        send(ctx.getSource(), "§7You have: §e" + tokens + " §7token" + (tokens == 1 ? "" : "s"));
        send(ctx.getSource(), "§7Cost: §f1 token §7= §f1 chunk §7claimed");
        if (tokens == 0) {
            send(ctx.getSource(), "§cYou need §e1 token §cto claim a chunk.");
            send(ctx.getSource(), "§7Earn tokens by fully clearing an infested zone.");
        } else {
            send(ctx.getSource(), "§aYou can claim §e" + tokens + " chunk" + (tokens == 1 ? "" : "s") + "§a right now.");
            send(ctx.getSource(), "§7Place a Claimed Chunk Block to spend 1 token and protect a chunk.");
        }
        send(ctx.getSource(), "§7Active claimed chunks: §e" + PlayerClaimedChunkManager.getClaimedChunkCount());
        send(ctx.getSource(), "§7View local claims: §f/wh map");
        return 1;
    }

    /** /worldhordes claim — op status page */
    private static int cmdClaimStatus(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        int claimed = PlayerClaimedChunkManager.getClaimedChunkCount();
        boolean enabled = WorldHordesConfig.COMMON.enableClaimedChunks.get();
        send(ctx.getSource(), "§6=== Player Claimed Chunks ===");
        send(ctx.getSource(), "§7System enabled: " + (enabled ? "§aYES" : "§cNO"));
        send(ctx.getSource(), "§7Total active claimed chunks: §e" + claimed);
        send(ctx.getSource(), "§7Cost: §f1 token §7per §f1 chunk §7(base rate, earned by clearing infestations)");
        if (player != null) {
            int tokens = PlayerClaimedChunkManager.getTokens(player.getUUID());
            send(ctx.getSource(), "§7Your tokens: §e" + tokens
                    + (tokens > 0 ? " §a(can claim " + tokens + " chunk" + (tokens == 1 ? "" : "s") + ")" : " §c(need 1 to claim)"));
        }
        return 1;
    }

    private static int cmdClaimGiveTokens(CommandContext<CommandSourceStack> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer target = net.minecraft.commands.arguments.EntityArgument.getPlayer(ctx, "player");
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        int current = PlayerClaimedChunkManager.getTokens(target.getUUID());
        PlayerClaimedChunkManager.setTokens(target.getUUID(), current + amount);
        target.sendSystemMessage(Component.literal(
                "§a[WorldHordes] You received §e" + amount + " §aClaim Token" + (amount == 1 ? "" : "s")
                + "§a. You now have §e" + (current + amount) + "§a. Cost: §f1 token = 1 chunk§a."));
        send(ctx.getSource(), "§6[Claim] §fGave §e" + amount + " §ftoken(s) to §e" + target.getName().getString()
                + "§f. They now have §e" + (current + amount) + "§f.");
        return 1;
    }

    private static int cmdClaimSetTokens(CommandContext<CommandSourceStack> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer target = net.minecraft.commands.arguments.EntityArgument.getPlayer(ctx, "player");
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        PlayerClaimedChunkManager.setTokens(target.getUUID(), amount);
        send(ctx.getSource(), "§6[Claim] §fSet §e" + target.getName().getString() + "§f's tokens to §e" + amount + "§f.");
        return 1;
    }

    private static int cmdClaimList(CommandContext<CommandSourceStack> ctx) {
        Set<String> claimed = PlayerClaimedChunkManager.getAllClaimedChunks();
        if (claimed.isEmpty()) { send(ctx.getSource(), "§7No player-claimed chunks active."); return 1; }
        send(ctx.getSource(), "§6=== Active Claimed Chunks (" + claimed.size() + ") ===");
        int i = 0;
        for (String key : claimed) {
            send(ctx.getSource(), "§e " + (++i) + ". §f" + key);
            if (i >= 30) { send(ctx.getSource(), "§7... and " + (claimed.size() - 30) + " more."); break; }
        }
        return 1;
    }

    // =========================================================================
    //  CLAIMS MAP — /wh map  (no op required)
    // =========================================================================

    /**
     * /wh map — renders a 15×15 chunk ASCII mini-map centred on the player.
     *
     * Legend:
     *   §a[C]  = claimed chunk (yours or another player's)
     *   §c[I]  = infested zone core
     *   §6[O]  = infested zone outer ring
     *   §e[+]  = your position
     *   §7[ ]  = normal chunk
     */
    private static int cmdClaimMap(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        ServerLevel level = player.serverLevel();
        String dim = DimUtil.getDim(level);
        ChunkPos cp = new ChunkPos(player.blockPosition());
        int px = cp.x, pz = cp.z;

        int radius = 7; // 15×15 map
        send(ctx.getSource(), "§6=== Chunk Map (radius " + radius + " chunks) ===");
        send(ctx.getSource(), "§a[C]§7=Claimed §c[I]§7=InfestCore §6[O]§7=InfestRing §e[+]§7=You §7[ ]=Normal");

        for (int dz = -radius; dz <= radius; dz++) {
            StringBuilder row = new StringBuilder();
            for (int dx = -radius; dx <= radius; dx++) {
                int cx = px + dx, cz = pz + dz;
                boolean isPlayer = (dx == 0 && dz == 0);
                boolean isClaimed = PlayerClaimedChunkManager.isChunkClaimed(dim, cx, cz);
                InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(dim, cx, cz);

                if (isPlayer) {
                    row.append("§e[+]");
                } else if (isClaimed) {
                    row.append("§a[C]");
                } else if (role == InfestationZone.ZoneRole.CORE) {
                    row.append("§c[I]");
                } else if (role == InfestationZone.ZoneRole.OUTER_RING) {
                    row.append("§6[O]");
                } else {
                    row.append("§7[ ]");
                }
            }
            send(ctx.getSource(), row.toString());
        }

        send(ctx.getSource(), "§7Centre: chunk (" + px + ", " + pz + ")  |  "
                + "§7Claimed: §e" + PlayerClaimedChunkManager.getClaimedChunkCount()
                + "  §7Your tokens: §e" + PlayerClaimedChunkManager.getTokens(player.getUUID())
                + " §7(§f1 token = 1 chunk§7)");
        return 1;
    }

    // =========================================================================
    //  HELP
    // =========================================================================

    private static int cmdHelp(CommandContext<CommandSourceStack> ctx) {
        send(ctx.getSource(), "§6=== WorldHordes Commands ===");
        send(ctx.getSource(), "§6-- No op required --");
        send(ctx.getSource(), "§e/worldhordes §7— Quick world overview (infestations, members, hordes)");
        send(ctx.getSource(), "§e/wh §7— Detailed density + your local infestation");
        send(ctx.getSource(), "§e/wh tokens §7— Your claim token balance (cost: 1 token = 1 chunk)");
        send(ctx.getSource(), "§e/wh map §7— 15×15 ASCII chunk map showing claims & infestations");
        send(ctx.getSource(), "§e/wh claim §7— Spend 1 token to claim the chunk you're standing in");
        send(ctx.getSource(), "§e/wh unclaim §7— Release your claim on the current chunk (refunds token)");
        send(ctx.getSource(), "§e/worldhordes naturalspawns <value> §7— Set natural spawn density multiplier");
        send(ctx.getSource(), "  §7Examples: §f0.05 §7(very slow), §f1.0 §7(default), §f5.0 §7(amplified)");
        send(ctx.getSource(), "§6-- Op required --");
        send(ctx.getSource(), "§e/worldhordes status §7— Full server overview");
        send(ctx.getSource(), "§e/worldhordes density [set|add <n>] §7— View/modify global density");
        send(ctx.getSource(), "§e/worldhordes infest [set|add|clear|list] §7— Manage infestations");
        send(ctx.getSource(), "§e/worldhordes horde [list|spawn|clear|tp <n>] §7— Manage hordes");
        send(ctx.getSource(), "§e/worldhordes spawnpoints [percentage|deduct|reset] §7— Tune spawn density");
        send(ctx.getSource(), "§e/worldhordes debug [toggle|overlay] §7— Debug tools");
        send(ctx.getSource(), "§e/worldhordes debug zone delete §7— §cDelete the entire infested zone at your position");
        send(ctx.getSource(), "§e/worldhordes naturalspawn [time] [members] §7— Natural spawn time gate");
        send(ctx.getSource(), "§e/worldhordes claim [tokens give/set|list] §7— Manage claims & tokens");
        return 1;
    }

    // =========================================================================
    //  HELPERS
    // =========================================================================

    private static void send(CommandSourceStack src, String msg) {
        src.sendSuccess(() -> Component.literal(msg), false);
    }

    private static ServerPlayer getPlayer(CommandSourceStack src) {
        try { return src.getPlayerOrException(); }
        catch (Exception e) { return null; }
    }

    private static String tierLabel(ChunkInfestationLevel.Tier tier) {
        return switch (tier) {
            case TIER1 -> "§a[T1]";
            case TIER2 -> "§6[T2]";
            case TIER3 -> "§c[T3]";
            default    -> "§7[NONE]";
        };
    }
}
