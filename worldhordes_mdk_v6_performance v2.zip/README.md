# World Hordes: Zombie Horde Ecosystem Mod

A dynamic zombie population and territory system for Minecraft. The world reacts to every zombie spawned, every kill made, and every survivor lost — building toward a living ecosystem of roaming hordes and infested territories.

## Requirements
- Minecraft 1.20.1
- Forge 47.4.10+

## Installation
1. Build with `./gradlew build`
2. Drop the compiled `worldhordes-1.0.0.jar` into your `mods/` folder
3. Start the game — config file generates at `config/worldhordes-common.toml`

## Building from Source
```bash
./gradlew build
# Output: build/libs/worldhordes-1.0.0.jar
```

## Core Systems

### Horde Density
A global pressure meter that rises when zombies spawn or kill players/NPCs, and falls when players kill zombies. When density crosses the threshold, wandering hordes spawn.

### Wandering Hordes
Groups of zombies that migrate across the overworld. They infest chunks as they travel and eventually settle in heavily infested areas.

### Infestation Zones
When a horde arrives or natural spawns accumulate, a 4×4 zone (2×2 core + 1-chunk outer ring) forms. The zone tracks a shared population and periodically sends zombie waves at nearby players.

### Performance Cap
A hard global cap (default 75, configurable) prevents WorldHordes from spawning more than that many tagged zombies at once. A combat-pause system also suppresses new waves while players are already fighting.

### Cleared Chunks
When players fully clear an infestation zone, affected chunks stop spawning zombies entirely. The only way to re-seed a cleared chunk is for a zombie to physically wander in and despawn there.

## Debug Overlay
Press **F3+I** in-game to toggle the World Hordes debug overlay, which shows:
- Current Horde Density
- Active horde count
- Nearby infestation zone info and tier
- Live zombie count vs. cap

## Save Files (in world folder)
- `<world>/worldhordes_density.dat` — Global Horde Density state
- `<world>/worldhordes_infestation.dat` — All chunk infestation levels
- `<world>/worldhordes_hordes.dat` — All active wandering horde states

## Configuration (`config/worldhordes-common.toml`)
All values are documented inline in the config file. Key sections:
- `[horde_density]` — How fast pressure builds and decays
- `[horde_spawning]` — Horde size, spawn intervals, max active hordes
- `[infestation_core_zone]` / `[infestation_outer_ring]` — Zone spawn rates and population limits
- `[performance]` — Live zombie cap and combat-pause tuning
- `[misc]` — Debug mode toggle

## Source Layout
```
src/main/java/com/worldhordes/mod/
├── WorldHordesMod.java              - Mod entrypoint
├── config/
│   └── WorldHordesConfig.java       - All config values
├── data/
│   ├── HordeDensityManager.java     - Global pressure tracking
│   ├── InfestationData.java         - Per-chunk infestation API
│   ├── InfestationEntity.java       - Shared zone population state
│   ├── InfestationZone.java         - Zone geometry (core + ring)
│   ├── InfestationZoneRegistry.java - Zone lookup and management
│   ├── ChunkInfestationLevel.java   - Per-chunk tier/cleared state
│   └── LiveZombieTracker.java       - Live tagged-zombie counter
├── horde/
│   ├── HordeManager.java            - Spawn/migration/pulse logic
│   └── WanderingHorde.java          - Individual horde state
├── events/
│   ├── EntityEventHandler.java      - Death, tick, blood decals
│   ├── SpawnEventHandler.java       - Natural spawn hooks
│   └── WorldEventHandler.java       - Server tick, entity leave
└── client/
    ├── InfestationOverlayRenderer.java - Debug HUD
    ├── ClientEventHandler.java          - Key input
    └── DebugOverlayState.java           - Overlay toggle state
```
