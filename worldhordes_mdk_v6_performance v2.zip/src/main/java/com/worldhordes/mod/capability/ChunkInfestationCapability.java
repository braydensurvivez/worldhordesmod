package com.worldhordes.mod.capability;

/**
 * Stub capability class - reserved for future per-chunk capability attachments
 * if needed for integration with other mods.
 */
public class ChunkInfestationCapability {
    // No implementation needed currently - infestation data is stored in InfestationData
}
