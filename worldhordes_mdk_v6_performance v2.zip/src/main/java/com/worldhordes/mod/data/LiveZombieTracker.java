package com.worldhordes.mod.data;

import com.worldhordes.mod.config.WorldHordesConfig;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Global counter tracking how many WorldHordes-tagged zombies are currently alive
 * across the entire server.  Used by HordeManager to enforce the hard population cap
 * and to detect "active combat" that should pause new spawn waves.
 *
 * <p>A zombie is "live" from the moment it is added to the world until it either:
 * <ul>
 *   <li>dies (LivingDeathEvent in EntityEventHandler)</li>
 *   <li>despawns / is unloaded far from players (EntityLeaveLevelEvent → onInfestZombieUntrack)</li>
 * </ul>
 *
 * <p>The counter is intentionally allowed to momentarily go slightly negative due to
 * potential double-decrements (e.g., death fires AND untrack fires); {@link #get()} always
 * clamps to zero on read so callers always see a sane value.
 */
public class LiveZombieTracker {

    private static final AtomicInteger liveCount = new AtomicInteger(0);

    private LiveZombieTracker() {}

    /** Increment when a tagged zombie is spawned into the world. */
    public static void onSpawn() {
        liveCount.incrementAndGet();
    }

    /** Decrement when a tagged zombie dies or despawns. Clamps to 0. */
    public static void onRemove() {
        liveCount.updateAndGet(n -> Math.max(0, n - 1));
    }

    /** Current live count (never negative). */
    public static int get() {
        return Math.max(0, liveCount.get());
    }

    /** True if the live count has reached or exceeded the configured hard cap. */
    public static boolean isAtHardCap() {
        return get() >= WorldHordesConfig.COMMON.maxLiveHordeZombies.get();
    }

    /**
     * True if enough tagged zombies are alive to be considered "active combat".
     * Spawn pulses should be deferred when this returns true.
     */
    public static boolean isInActiveCombat() {
        return get() >= WorldHordesConfig.COMMON.combatPauseZombieThreshold.get();
    }

    /** Reset to zero (used on server stop / world reload). */
    public static void reset() {
        liveCount.set(0);
    }
}
