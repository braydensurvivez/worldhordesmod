package com.worldhordes.mod.data;

import com.worldhordes.mod.config.WorldHordesConfig;

/**
 * Represents the shared, zone-level population state of a single infestation.
 * The entire 4×4 zone (2×2 core + 1-chunk outer ring) shares ONE InfestationEntity.
 *
 * Population is increased by:
 *   - natural zombie spawns within the zone
 *   - periodic regen
 * Population is decreased by:
 *   - player kills of zombies in the zone
 *
 * When population drops below the configurable destroyThreshold the infestation
 * is flagged for removal and all related data / blood decals are cleaned up.
 */
public class InfestationEntity {

    /** The shared zombie-population count for the whole zone. */
    private int population;

    /**
     * Reserve pool used by the wave-spawner. Spawned zombies are drawn from
     * the reserve; reserve is replenished from population over time.
     */
    private int spawnReserve;

    /** True once a player (or the server) has activated this infestation. */
    private boolean active;

    /** True when population has fallen below destroyThreshold → pending cleanup. */
    private boolean markedForDestruction;

    private long lastActivityTime;

    /**
     * The density contribution this entity added to the global World Horde Density
     * the last time it was sampled. Used to compute a delta rather than blindly
     * re-adding the full contribution every sample, so a den's contribution to the
     * world population total only ever reflects its *current* population — shrinking
     * automatically as players kill zombies in it, instead of compounding forever.
     */
    private int lastDensityContribution = 0;

    // -------------------------------------------------------------------------

    public InfestationEntity(int initialPopulation) {
        this.population        = initialPopulation;
        this.spawnReserve      = initialPopulation;
        this.active            = false;
        this.markedForDestruction = false;
        this.lastActivityTime  = System.currentTimeMillis();
    }

    /** Full constructor for deserialization. */
    public InfestationEntity(int population, int spawnReserve, boolean active,
                              boolean markedForDestruction, long lastActivityTime) {
        this.population           = population;
        this.spawnReserve         = spawnReserve;
        this.active               = active;
        this.markedForDestruction = markedForDestruction;
        this.lastActivityTime     = lastActivityTime;
    }

    // -------------------------------------------------------------------------
    // Population mutation
    // -------------------------------------------------------------------------

    /**
     * Natural zombie spawn within the zone increases shared population.
     * Called by SpawnEventHandler for every natural/chunk-gen zombie inside the zone.
     */
    public void onNaturalSpawn(int amount) {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        population = Math.min(population + amount, max);
        spawnReserve = Math.min(spawnReserve + amount, max);
        lastActivityTime = System.currentTimeMillis();
    }

    /**
     * Player kill reduces shared population and checks destroy threshold.
     * Returns true if the population just fell below the destroy threshold.
     */
    public boolean onZombieKilledByPlayer(int decayPerKill) {
        population = Math.max(0, population - decayPerKill);
        spawnReserve = Math.max(0, spawnReserve - 1);
        lastActivityTime = System.currentTimeMillis();
        int threshold = WorldHordesConfig.COMMON.infestationDestroyThreshold.get();
        if (population <= threshold && !markedForDestruction) {
            markedForDestruction = true;
            return true; // caller should trigger cleanup
        }
        return false;
    }

    /** Passive regen tick — adds points back each regen interval. */
    public void applyRegen(int regenAmount) {
        if (markedForDestruction) return;
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        population    = Math.min(population + regenAmount, max);
        spawnReserve  = Math.min(spawnReserve + regenAmount / 2 + 1, max);
    }

    // -------------------------------------------------------------------------
    // Wave spawning
    // -------------------------------------------------------------------------

    /** Draw up to {@code count} zombies from the spawn reserve. Returns actual drawn. */
    public int drawFromReserve(int count) {
        int drawn = Math.min(count, spawnReserve);
        spawnReserve = Math.max(0, spawnReserve - drawn);
        return drawn;
    }

    /** Return zombies to reserve when they despawn (unloaded, not killed). */
    public void returnToReserve(int count) {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        spawnReserve = Math.min(spawnReserve + count, max);
    }

    /** Refill reserve from population (called periodically). */
    public void refillReserve() {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        // Reserve is capped to a fraction of population to keep it realistic
        int cap = Math.max(1, population / 2);
        if (spawnReserve < cap) {
            spawnReserve = Math.min(cap, spawnReserve + Math.max(1, population / 10));
            spawnReserve = Math.min(spawnReserve, max);
        }
    }

    // -------------------------------------------------------------------------
    // Global density contribution
    // -------------------------------------------------------------------------

    /**
     * Returns how many global density points this infestation contributes.
     * Called each density-tick; the density manager will set (not add) this value
     * so contributions don't compound.
     */
    public int computeDensityContribution() {
        // 1 density point per 10 population, minimum 1 when active
        return active ? Math.max(1, population / 10) : 0;
    }

    /**
     * Returns the change in this den's density contribution since it was last sampled,
     * and updates the stored baseline. Callers should add the (possibly negative) result
     * to the global World Horde Density instead of re-adding the full contribution —
     * this is what makes the world population total track each den's *current* member
     * count, so clearing/shrinking a den actually reduces the world population instead
     * of leaving its earlier contribution permanently baked in.
     */
    public int computeDensityDelta() {
        int current = computeDensityContribution();
        int delta = current - lastDensityContribution;
        lastDensityContribution = current;
        return delta;
    }

    /** The density contribution last recorded for this den (used to clean up on destruction). */
    public int getLastDensityContribution() { return lastDensityContribution; }

    // -------------------------------------------------------------------------
    // State queries
    // -------------------------------------------------------------------------

    public int  getPopulation()           { return population; }
    public int  getSpawnReserve()         { return spawnReserve; }
    public boolean isActive()             { return active; }
    public boolean isMarkedForDestruction() { return markedForDestruction; }
    public long getLastActivityTime()     { return lastActivityTime; }

    public void setActive(boolean active) { this.active = active; }
    public void setPopulation(int pop)    { this.population = Math.max(0, pop); }
}
