package com.worldhordes.mod.data;

/**
 * Represents a single infestation zone centred on a 2×2 Core.
 *
 * Layout (each cell = 1 chunk):
 * <pre>
 *   O O O O
 *   O C C O
 *   O C C O
 *   O O O O
 * </pre>
 * C = Core Zone  (4 chunks, offsets (-1,-1),(-1,0),(0,-1),(0,0) relative to centre-origin)
 * O = Outer Ring (12 chunks, 1-chunk thick border around the core)
 *
 * The "origin" chunk stored here is the top-left core chunk (C at offset 0,0 in the grid
 * shown as the upper-left C). That is: coreOriginX/Z = centre of the 4×4 zone - 1.
 *
 * Core chunks: (originX, originZ), (originX+1, originZ), (originX, originZ+1), (originX+1, originZ+1)
 * Outer ring:  all chunks in the 4×4 area that are NOT core chunks.
 */
public class InfestationZone {

    /** Top-left chunk of the 2×2 core (the zone spans originX-1..originX+2, originZ-1..originZ+2). */
    private final int originX;
    private final int originZ;

    public InfestationZone(int originX, int originZ) {
        this.originX = originX;
        this.originZ = originZ;
    }

    /**
     * Creates an InfestationZone whose 2×2 core is centred as close as possible to (centreX, centreZ).
     * The core occupies (centreX-1, centreZ-1) to (centreX, centreZ).
     */
    public static InfestationZone centredAt(int centreX, int centreZ) {
        return new InfestationZone(centreX - 1, centreZ - 1);
    }

    public int getOriginX() { return originX; }
    public int getOriginZ() { return originZ; }

    /** Centre chunk X of the 4×4 zone (for distance checks). */
    public int getZoneCentreX() { return originX + 1; }
    /** Centre chunk Z of the 4×4 zone (for distance checks). */
    public int getZoneCentreZ() { return originZ + 1; }

    /** Returns true if (cx, cz) is one of the 4 Core Zone chunks. */
    public boolean isCore(int cx, int cz) {
        int dx = cx - originX;
        int dz = cz - originZ;
        return dx >= 0 && dx <= 1 && dz >= 0 && dz <= 1;
    }

    /** Returns true if (cx, cz) is in the Outer Ring (the 1-chunk border around the core). */
    public boolean isOuterRing(int cx, int cz) {
        int dx = cx - (originX - 1);  // position within the 4×4 area (0..3)
        int dz = cz - (originZ - 1);
        if (dx < 0 || dx > 3 || dz < 0 || dz > 3) return false; // outside zone entirely
        return !isCore(cx, cz); // in 4×4 but not core → ring
    }

    /** Returns true if (cx, cz) is anywhere within this zone (core or ring). */
    public boolean contains(int cx, int cz) {
        int dx = cx - (originX - 1);
        int dz = cz - (originZ - 1);
        return dx >= 0 && dx <= 3 && dz >= 0 && dz <= 3;
    }

    /**
     * Returns ZoneRole for (cx, cz): CORE, OUTER_RING, or NONE.
     */
    public ZoneRole roleOf(int cx, int cz) {
        if (isCore(cx, cz)) return ZoneRole.CORE;
        if (isOuterRing(cx, cz)) return ZoneRole.OUTER_RING;
        return ZoneRole.NONE;
    }

    public enum ZoneRole {
        CORE,
        OUTER_RING,
        NONE
    }

    /**
     * Lists all 4 core chunk positions as int[]{cx, cz} pairs.
     */
    public int[][] getCoreChunks() {
        return new int[][]{
            {originX,     originZ    },
            {originX + 1, originZ    },
            {originX,     originZ + 1},
            {originX + 1, originZ + 1}
        };
    }

    /**
     * Lists all 12 outer ring chunk positions as int[]{cx, cz} pairs.
     * The outer ring is the 1-chunk border around the 2×2 core, giving a 4×4 total zone.
     */
    public int[][] getOuterRingChunks() {
        int startX = originX - 1;
        int startZ = originZ - 1;
        int[][] result = new int[12][2];
        int idx = 0;
        for (int dx = 0; dx < 4; dx++) {
            for (int dz = 0; dz < 4; dz++) {
                int cx = startX + dx;
                int cz = startZ + dz;
                if (!isCore(cx, cz)) {
                    result[idx][0] = cx;
                    result[idx][1] = cz;
                    idx++;
                }
            }
        }
        return result;
    }

    /**
     * Lists all 16 chunks in this zone (core + ring).
     */
    public int[][] getAllChunks() {
        int startX = originX - 1;
        int startZ = originZ - 1;
        int[][] result = new int[16][2];
        int idx = 0;
        for (int dx = 0; dx < 4; dx++) {
            for (int dz = 0; dz < 4; dz++) {
                result[idx][0] = startX + dx;
                result[idx][1] = startZ + dz;
                idx++;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "InfestationZone{core=(" + originX + "," + originZ + ")..(" +
                (originX+1) + "," + (originZ+1) + ")}";
    }
}
