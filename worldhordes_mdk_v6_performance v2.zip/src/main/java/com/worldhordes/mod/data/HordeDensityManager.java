package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Tracks the global World Horde Density — the "bank" that funds new infestations.
 *
 * BANK MODEL
 * ----------
 * - Density is the bank balance.  It grows slowly from meaningful events (player killed,
 *   NPC killed) and from den population changes flowing back in via the delta-sync tick.
 * - Natural zombie spawns contribute a dynamically devalued trickle (see below).
 * - When a new infestation zone is seeded the bank is DEBITED by the initial population
 *   cost — those members are now "in the field", not in the bank.
 * - As a den’s population grows/shrinks the delta is credited/debited back into the bank
 *   each tick, so the bank always reflects the total free + den-held density.
 * - When a den is destroyed its remaining population is RETURNED to the bank.
 *
 * DYNAMIC SPAWN DEVALUATION
 * -------------------------
 * Natural zombie spawns are the noisiest density source and must not overwhelm the system
 * when modded spawn rates are high.  We keep a rolling 60-second spawn count and scale the
 * per-spawn contribution down as the rate climbs:
 *
 *   effectivePoints = basePoints / max(1, recentSpawns / naturalSpawnRateBaseline)
 *
 * At the vanilla baseline (~naturalSpawnRateBaseline spawns/minute) each spawn is worth
 * basePoints.  Double the rate → half the points per spawn.  30× the rate → 1/30 each.
 * Total density gain from natural spawns is therefore roughly constant regardless of how
 * aggressively a mod floods zombies.
 */
public class HordeDensityManager {

    private static int  globalDensity  = 0;
    private static long lastDecayTime  = 0;
    private static MinecraftServer server;

    private static final String SAVE_FILE = "worldhordes_density.dat";

    // Rolling window of natural-spawn timestamps (epoch ms) for rate devaluation
    private static final Deque<Long> recentSpawnTimestamps = new ArrayDeque<>();
    /** Window length in ms over which we count recent spawns (default 60 s). */
    private static final long SPAWN_WINDOW_MS = 60_000L;

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        load();
        lastDecayTime = System.currentTimeMillis();
    }

    // -------------------------------------------------------------------------
    // Bank deposit / withdrawal helpers
    // -------------------------------------------------------------------------

    /**
     * Generic add (positive) or remove (negative) from the bank.
     * Clamps to [0, maxGlobalDensity].
     */
    public static void addDensity(int amount) {
        int max = WorldHordesConfig.COMMON.maxGlobalDensity.get();
        globalDensity = Math.max(0, Math.min(globalDensity + amount, max));
        if (WorldHordesConfig.COMMON.debugMode.get() && amount != 0) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Density {:+d} → {}", amount, globalDensity);
        }
    }

    /**
     * Unconditional removal (always non-negative result).
     * Use for direct debits; prefer addDensity(-n) when you have a signed delta.
     */
    public static void removeDensity(int amount) {
        addDensity(-amount);
    }

    // -------------------------------------------------------------------------
    // Natural-spawn trickle (devalued dynamically)
    // -------------------------------------------------------------------------

    /**
     * Called once per natural zombie spawn.  Contributes a small trickle to the bank
     * but devalues automatically when the spawn rate is unusually high, so modded
     * servers with burst-heavy spawners don’t flood the bank.
     *
     * The contribution formula:
     *   effective = max(1, basePoints / max(1, recentSpawns / baseline))
     *
     * where recentSpawns is the count of spawns in the last 60 seconds and baseline
     * is the config value naturalSpawnRateBaseline (default 20 = roughly vanilla).
     */
    public static void recordNaturalSpawn() {
        long now = System.currentTimeMillis();

        // Prune timestamps outside the window
        while (!recentSpawnTimestamps.isEmpty() && now - recentSpawnTimestamps.peekFirst() > SPAWN_WINDOW_MS) {
            recentSpawnTimestamps.pollFirst();
        }
        recentSpawnTimestamps.addLast(now);

        int basePoints  = WorldHordesConfig.COMMON.densityPerZombieSpawn.get();
        int baseline    = Math.max(1, WorldHordesConfig.COMMON.naturalSpawnRateBaseline.get());
        int recentCount = recentSpawnTimestamps.size();

        // Scale factor: 1.0 at baseline, drops toward 0 as rate climbs
        double scale = (double) baseline / Math.max(baseline, recentCount);
        int effective = Math.max(basePoints > 0 ? 1 : 0, (int) Math.round(basePoints * scale));

        addDensity(effective);

        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug(
                    "[WorldHordes] NaturalSpawn trickle +{} (base={}, rate={}/min, scale={})",
                    effective, basePoints, recentCount, String.format("%.2f", scale));
        }
    }

    // -------------------------------------------------------------------------
    // Zone creation / destruction (withdraw / deposit)
    // -------------------------------------------------------------------------

    /**
     * WITHDRAW: debit the bank when a new infestation zone is seeded.
     * The members are now “in the field”; the delta-sync tick will track them going
     * forward and credit/debit changes back into the bank automatically.
     *
     * @return true if the bank had sufficient funds (density ≥ cost); false if not
     *         enough density was available (caller should reject the seeding).
     */
    public static boolean withdrawForZone(int initialPopulation) {
        if (globalDensity < initialPopulation) return false;
        addDensity(-initialPopulation);
        WorldHordesMod.LOGGER.info(
                "[WorldHordes] Bank withdrawal −{} for new zone → balance={}", initialPopulation, globalDensity);
        return true;
    }

    /**
     * DEPOSIT: return a den’s remaining population to the bank when the zone is destroyed.
     * This is the counterpart to withdrawForZone and ensures clearing a den returns
     * its unconsumed “investment” to the world density pool.
     */
    public static void depositFromDestroyedZone(int remainingPopulation) {
        if (remainingPopulation <= 0) return;
        addDensity(remainingPopulation);
        WorldHordesMod.LOGGER.info(
                "[WorldHordes] Bank deposit +{} from destroyed zone → balance={}", remainingPopulation, globalDensity);
    }

    // -------------------------------------------------------------------------
    // Threshold / state queries
    // -------------------------------------------------------------------------

    public static int getDensity() { return globalDensity; }

    public static boolean isAboveHordeThreshold() {
        return globalDensity >= WorldHordesConfig.COMMON.densityThresholdForHorde.get();
    }

    /** How many natural spawns have occurred in the last 60 seconds (for debug display). */
    public static int getRecentSpawnRate() { return recentSpawnTimestamps.size(); }

    // -------------------------------------------------------------------------
    // Periodic decay tick
    // -------------------------------------------------------------------------

    public static void tick() {
        long now = System.currentTimeMillis();
        long elapsed = now - lastDecayTime;
        if (elapsed >= 60_000L) {
            int decay = WorldHordesConfig.COMMON.densityDecayPerMinute.get();
            removeDensity(decay);
            lastDecayTime = now;
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug("[WorldHordes] Density decay −{} → {}", decay, globalDensity);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(file)))) {
            out.writeInt(globalDensity);
            out.writeLong(lastDecayTime);
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved horde density: {}", globalDensity);
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save density data", e);
        }
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(new java.io.FileInputStream(file)))) {
            globalDensity = in.readInt();
            lastDecayTime = in.readLong();
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded horde density: {}", globalDensity);
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load density data", e);
        }
    }
}
