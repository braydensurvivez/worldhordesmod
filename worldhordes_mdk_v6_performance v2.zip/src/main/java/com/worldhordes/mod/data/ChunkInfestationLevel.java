package com.worldhordes.mod.data;

import com.worldhordes.mod.config.WorldHordesConfig;

public class ChunkInfestationLevel {

    public enum Tier {
        NONE, TIER1, TIER2, TIER3
    }

    private int level;
    private long lastActivityTime;
    private boolean hasActiveHorde;
    /**
     * When true, this chunk has been fully cleared by players and cannot gain
     * infestation from the spread system — only from zombies physically entering.
     */
    private boolean cleared;
    /**
     * Reserve pool of zombies that "belong" to this infested chunk.
     * Zombies spawned from this chunk add to it; zombies that despawn return here.
     */
    private int zombieReserve;

    public ChunkInfestationLevel() {
        this.level = 0;
        this.lastActivityTime = System.currentTimeMillis();
        this.hasActiveHorde = false;
        this.cleared = false;
        this.zombieReserve = 0;
    }

    public ChunkInfestationLevel(int level, long lastActivityTime, boolean hasActiveHorde) {
        this.level = level;
        this.lastActivityTime = lastActivityTime;
        this.hasActiveHorde = hasActiveHorde;
        this.cleared = false;
        this.zombieReserve = 0;
    }

    public ChunkInfestationLevel(int level, long lastActivityTime, boolean hasActiveHorde,
                                  boolean cleared, int zombieReserve) {
        this.level = level;
        this.lastActivityTime = lastActivityTime;
        this.hasActiveHorde = hasActiveHorde;
        this.cleared = cleared;
        this.zombieReserve = zombieReserve;
    }

    public int getLevel() { return level; }

    public void addInfestation(int amount) {
        if (cleared) return; // cleared chunks ignore spread-based infestation
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        level = Math.min(level + amount, max);
        lastActivityTime = System.currentTimeMillis();
    }

    /** Used when zombies physically enter the chunk — bypasses cleared flag. */
    public void addInfestationForced(int amount) {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        level = Math.min(level + amount, max);
        lastActivityTime = System.currentTimeMillis();
        if (level > 0) cleared = false; // reinfesting clears the cleared flag
    }

    public void removeInfestation(int amount) {
        level = Math.max(0, level - amount);
        lastActivityTime = System.currentTimeMillis();
    }

    public void setLevel(int level) {
        this.level = Math.max(0, Math.min(level, WorldHordesConfig.COMMON.infestationMaxLevel.get()));
    }

    /** Called when a chunk is fully destroyed by players — locks out spread-based regrowth. */
    public void markCleared() {
        level = 0;
        cleared = true;
        hasActiveHorde = false;
        zombieReserve = 0;
        lastActivityTime = System.currentTimeMillis();
    }

    public boolean isCleared() { return cleared; }

    public boolean isInfested() {
        return level >= WorldHordesConfig.COMMON.infestationTier1.get();
    }

    public boolean shouldSpread() {
        return !cleared && level >= WorldHordesConfig.COMMON.infestationSpreadThreshold.get();
    }

    public boolean hasActiveHorde() { return hasActiveHorde; }
    public void setHasActiveHorde(boolean val) { hasActiveHorde = val; }
    public long getLastActivityTime() { return lastActivityTime; }

    // --- Zombie Reserve ---
    public int getZombieReserve() { return zombieReserve; }
    public void addToReserve(int count) { zombieReserve = Math.min(zombieReserve + count, 500); }
    public void removeFromReserve(int count) { zombieReserve = Math.max(0, zombieReserve - count); }

    public Tier getTier() {
        int t3 = WorldHordesConfig.COMMON.infestationTier3.get();
        int t2 = WorldHordesConfig.COMMON.infestationTier2.get();
        int t1 = WorldHordesConfig.COMMON.infestationTier1.get();
        if (level >= t3) return Tier.TIER3;
        if (level >= t2) return Tier.TIER2;
        if (level >= t1) return Tier.TIER1;
        return Tier.NONE;
    }

    public int getExtraZombies() {
        return switch (getTier()) {
            case TIER1 -> WorldHordesConfig.COMMON.tier1ExtraZombies.get();
            case TIER2 -> WorldHordesConfig.COMMON.tier2ExtraZombies.get();
            case TIER3 -> WorldHordesConfig.COMMON.tier3ExtraZombies.get();
            default -> 0;
        };
    }

    public int getGroupSizeBonus() {
        return switch (getTier()) {
            case TIER1 -> WorldHordesConfig.COMMON.tier1GroupSizeBonus.get();
            case TIER2 -> WorldHordesConfig.COMMON.tier2GroupSizeBonus.get();
            case TIER3 -> WorldHordesConfig.COMMON.tier3GroupSizeBonus.get();
            default -> 0;
        };
    }
}
