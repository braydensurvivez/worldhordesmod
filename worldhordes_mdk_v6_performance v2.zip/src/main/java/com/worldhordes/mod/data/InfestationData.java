package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central API for infestation state.
 *
 * After the refactor, population tracking is zone-level (shared entity) rather
 * than per-chunk.  ChunkInfestationLevel still exists but is used only for
 * tier / visual / spread queries based on the zone entity's population.
 *
 * All public surface methods remain so other classes need minimal changes.
 */
public class InfestationData {

    /** One Minecraft day, in game ticks (matches the vanilla day/night cycle length). */
    private static final long TICKS_PER_MINECRAFT_DAY = 24000L;

    // Legacy per-chunk map — kept for backwards compatibility and spread/decay logic.
    // Going forward, the authoritative population lives in InfestationZoneRegistry entities.
    private static final Map<String, ChunkInfestationLevel> chunkData = new ConcurrentHashMap<>();
    private static MinecraftServer server;
    private static long lastDecayTime  = 0;
    /** The in-game Minecraft day number on which regen was last applied. */
    private static long lastRegenDay   = 0;

    private static final String SAVE_FILE = "worldhordes_infestation.dat";

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        load();
        long now = System.currentTimeMillis();
        lastDecayTime = now;
        lastRegenDay = getCurrentMinecraftDay();
    }

    /** Returns the current in-game Minecraft day number for the Overworld, or -1 if unavailable. */
    private static long getCurrentMinecraftDay() {
        if (server == null) return -1;
        ServerLevel overworld = server.getLevel(Level.OVERWORLD);
        if (overworld == null) return -1;
        return overworld.getDayTime() / TICKS_PER_MINECRAFT_DAY;
    }

    private static String key(String dim, int cx, int cz) {
        return dim + ":" + cx + ":" + cz;
    }

    // -------------------------------------------------------------------------
    // Zone creation (used by HordeManager / SpawnEventHandler)
    // -------------------------------------------------------------------------

    /**
     * Seeds a brand-new infestation zone centred near (cx, cz).
     * The zone's shared entity is initialised with {@code initialPopulation}.
     * Returns the created zone, or null if rejected (distance check or insufficient density).
     *
     * BANK CONTRACT: the bank must hold at least initialPopulation density.  That amount is
     * debited before the zone is registered.  As the den grows/shrinks the delta-sync tick
     * credits/debits the difference back.  When the den is destroyed its remaining population
     * is returned to the bank.
     */
    public static InfestationZone seedInfestationRegion(String dim, int cx, int cz,
                                                         int initialPopulation) {
        // BANK CHECK FIRST: verify sufficient funds before any zone data is created.
        if (!HordeDensityManager.withdrawForZone(initialPopulation)) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Zone at ({},{}) rejected — bank balance {} < cost {}",
                        cx, cz, HordeDensityManager.getDensity(), initialPopulation);
            }
            return null;
        }

        InfestationZone zone = InfestationZoneRegistry.createZone(dim, cx, cz, initialPopulation);
        if (zone == null) {
            // Distance check failed — refund the withdrawal
            HordeDensityManager.depositFromDestroyedZone(initialPopulation);
            return null;
        }

        // Mirror infestation level into per-chunk map so tier-based effects still work.
        // All 16 chunks share ONE InfestationEntity; uniform level keeps tier reads consistent.
        for (int[] chunk : zone.getAllChunks()) {
            getOrCreate(dim, chunk[0], chunk[1]).addInfestation(initialPopulation);
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Seeded infestation {} in dim={} pop={} (bank balance={})",
                zone, dim, initialPopulation, HordeDensityManager.getDensity());
        return zone;
    }

    // -------------------------------------------------------------------------
    // Natural zombie spawn — grows zone population
    // -------------------------------------------------------------------------

    /**
     * Called when a zombie spawns naturally inside an existing zone.
     * Increases the zone's shared population.
     */
    public static void onNaturalZombieSpawnInZone(String dim, int cx, int cz) {
        InfestationEntity entity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
        if (entity == null) return;
        int growth = WorldHordesConfig.COMMON.infestationGrowthPerZombie.get();
        entity.onNaturalSpawn(growth);
        // Keep per-chunk level in sync
        getOrCreate(dim, cx, cz).addInfestationForced(growth);
        // Density is synced 1:1 via the delta tick in InfestationData.tick() — no manual add needed here.
    }

    // -------------------------------------------------------------------------
    // Zombie kill — reduces zone population
    // -------------------------------------------------------------------------

    /**
     * Called when a player kills a zombie in chunk (cx,cz).
     * Reduces the zone population.  Returns true if the zone should now be destroyed.
     */
    public static boolean onZombieKilledByPlayer(net.minecraft.server.level.ServerLevel serverLevel,
                                                  String dim, int cx, int cz) {
        InfestationEntity entity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
        if (entity == null) return false;

        int decay = WorldHordesConfig.COMMON.infestationDecayPerKill.get();
        boolean shouldDestroy = entity.onZombieKilledByPlayer(decay);

        // Keep per-chunk level in sync
        ChunkInfestationLevel chunk = chunkData.get(key(dim, cx, cz));
        if (chunk != null) chunk.removeInfestation(decay);
        // Density shrinks automatically via the delta tick — no manual remove needed here.

        if (shouldDestroy) {
            destroyInfestation(serverLevel, dim, cx, cz);
            return true;
        }
        return false;
    }

    // -------------------------------------------------------------------------
    // Infestation destruction
    // -------------------------------------------------------------------------

    /**
     * Destroys the infestation zone that contains (cx,cz):
     * removes all blood decals, removes per-chunk data, and deregisters the zone.
     */
    public static void destroyInfestation(net.minecraft.server.level.ServerLevel serverLevel,
                                           String dim, int cx, int cz) {
        InfestationZone zone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
        if (zone == null) {
            WorldHordesMod.LOGGER.info("[WorldHordes] destroyInfestation called but no zone at ({},{})", cx, cz);
            return;
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Infestation destroyed at zone centred ({},{}) dim={}",
                zone.getZoneCentreX(), zone.getZoneCentreZ(), dim);

        // 1. BANK DEPOSIT: return this den's remaining population to the bank.
        //    Players clearing a den "frees" its population back into the world density pool
        //    so it can eventually fund a new infestation elsewhere.
        InfestationEntity entity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
        if (entity != null && entity.getPopulation() > 0) {
            HordeDensityManager.depositFromDestroyedZone(entity.getPopulation());
        }

        // 2. Remove blood decals
        removeBloodDecalsInZone(serverLevel, zone);

        // 3. Remove per-chunk infestation data
        for (int[] chunk : zone.getAllChunks()) {
            String k = key(dim, chunk[0], chunk[1]);
            ChunkInfestationLevel inf = chunkData.get(k);
            if (inf != null) inf.markCleared();
            chunkData.remove(k);
        }

        // 4. Deregister the zone (removes entity + chunk mappings)
        InfestationZoneRegistry.removeZone(dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Blood decal removal
    // -------------------------------------------------------------------------

    private static void removeBloodDecalsInZone(net.minecraft.server.level.ServerLevel serverLevel,
                                                  InfestationZone zone) {
        com.worldhordes.mod.registry.ModBlocks.BLOOD_SPLATTER.ifPresent(bloodBlock -> {
            int removed = 0;
            for (int[] chunk : zone.getAllChunks()) {
                if (!serverLevel.hasChunk(chunk[0], chunk[1])) continue;
                net.minecraft.world.level.chunk.LevelChunk lc = serverLevel.getChunk(chunk[0], chunk[1]);
                net.minecraft.core.BlockPos.MutableBlockPos mpos = new net.minecraft.core.BlockPos.MutableBlockPos();
                int baseX = lc.getPos().getMinBlockX();
                int baseZ = lc.getPos().getMinBlockZ();
                int minY  = serverLevel.getMinBuildHeight();
                int maxY  = serverLevel.getMaxBuildHeight();
                for (int bx = baseX; bx < baseX + 16; bx++) {
                    for (int bz = baseZ; bz < baseZ + 16; bz++) {
                        for (int by = minY; by < maxY; by++) {
                            mpos.set(bx, by, bz);
                            if (serverLevel.getBlockState(mpos).getBlock() == bloodBlock) {
                                serverLevel.setBlock(mpos,
                                        net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),
                                        net.minecraft.world.level.block.Block.UPDATE_CLIENTS
                                        | net.minecraft.world.level.block.Block.UPDATE_SUPPRESS_DROPS);
                                removed++;
                            }
                        }
                    }
                }
            }
            if (removed > 0)
                WorldHordesMod.LOGGER.info("[WorldHordes] Removed {} blood decals from destroyed zone.", removed);
        });
    }

    /**
     * Legacy entry point called by HordeManager.onChunkFullyCleared().
     * Delegates to destroyInfestation.
     */
    public static void removeBloodDecalsInRegion(net.minecraft.server.level.ServerLevel serverLevel,
                                                  String dim, int cx, int cz) {
        destroyInfestation(serverLevel, dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Passive-decay / regen tick (called by HordeManager.tick)
    // -------------------------------------------------------------------------

    public static void tick() {
        long now = System.currentTimeMillis();

        // Passive decay of per-chunk infestation levels (visual/tier sync)
        if (now - lastDecayTime >= 60_000L) {
            lastDecayTime = now;
            applyPassiveDecay();
        }

        // Population regen for zone (den) entities — ticks with the Minecraft day/night
        // cycle, not real-world time, so it stays consistent regardless of server TPS
        // or how long the server has been left running.
        int regenIntervalDays = WorldHordesConfig.COMMON.infestationRegenIntervalDays.get();
        if (regenIntervalDays > 0) {
            long currentDay = getCurrentMinecraftDay();
            if (currentDay >= 0 && currentDay - lastRegenDay >= regenIntervalDays) {
                lastRegenDay = currentDay;
                applyPopulationRegen();
            }
        }

        // Refill spawn reserves from population
        for (InfestationEntity entity : InfestationZoneRegistry.getAllEntities().values()) {
            entity.refillReserve();
        }

        // NOTE: den population ↔ bank density sync is handled by HordeManager.tickInfestationSpawns()
        // via entity.computeDensityDelta().  Do NOT duplicate that loop here.
    }

    private static void applyPassiveDecay() {
        int decay = WorldHordesConfig.COMMON.infestationDecayPerMinute.get();
        List<String> toRemove = new ArrayList<>();
        for (Map.Entry<String, ChunkInfestationLevel> entry : chunkData.entrySet()) {
            ChunkInfestationLevel inf = entry.getValue();
            if (!inf.hasActiveHorde()) {
                inf.removeInfestation(decay);
                if (inf.getLevel() <= 0 && !inf.isCleared()) toRemove.add(entry.getKey());
            }
        }
        toRemove.forEach(chunkData::remove);
    }

    /**
     * Applies one Minecraft-day regen tick to every active den (infestation zone).
     * The amount regenerated is capped by the den's current danger tier: Tier 2/3
     * dens regenerate up to {@code infestationRegenAmountHighTier} (default 10),
     * while a den that's only Tier 1 (or has decayed below Tier 1) is capped at
     * {@code infestationRegenAmountTier1} (default 1).
     */
    private static void applyPopulationRegen() {
        int tier1Amount    = WorldHordesConfig.COMMON.infestationRegenAmountTier1.get();
        int highTierAmount = WorldHordesConfig.COMMON.infestationRegenAmountHighTier.get();
        if (tier1Amount <= 0 && highTierAmount <= 0) return;

        Map<String, InfestationZone>   zones    = InfestationZoneRegistry.getAllZoneMap();
        Map<String, InfestationEntity> entities = InfestationZoneRegistry.getAllEntities();

        int count = 0;
        for (Map.Entry<String, InfestationEntity> e : entities.entrySet()) {
            InfestationEntity entity = e.getValue();
            if (entity.isMarkedForDestruction()) continue;

            InfestationZone zone = zones.get(e.getKey());
            int regenAmount = (zone == null)
                    ? tier1Amount // no zone geometry on record — fall back to the conservative cap
                    : regenCapForZone(InfestationZoneRegistry.extractDim(e.getKey()), zone, tier1Amount, highTierAmount);

            if (regenAmount <= 0) continue;
            entity.applyRegen(regenAmount);
            count++;
        }

        if (WorldHordesConfig.COMMON.debugMode.get() && count > 0) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Daily population regen applied to {} den(s).", count);
        }
    }

    /**
     * Determines the regen cap for a den based on the highest chunk tier found anywhere
     * in its zone (core + outer ring). Tier 2 or Tier 3 anywhere in the zone unlocks the
     * higher cap; otherwise (Tier 1 or no tier at all) the den is limited to the Tier 1 cap.
     */
    private static int regenCapForZone(String dim, InfestationZone zone, int tier1Amount, int highTierAmount) {
        ChunkInfestationLevel.Tier maxTier = ChunkInfestationLevel.Tier.NONE;
        for (int[] chunk : zone.getAllChunks()) {
            ChunkInfestationLevel.Tier t = get(dim, chunk[0], chunk[1]).getTier();
            if (t.ordinal() > maxTier.ordinal()) maxTier = t;
        }
        boolean highTier = maxTier == ChunkInfestationLevel.Tier.TIER2
                || maxTier == ChunkInfestationLevel.Tier.TIER3;
        return highTier ? highTierAmount : tier1Amount;
    }

    // -------------------------------------------------------------------------
    // Distance / placement helpers (delegated to registry)
    // -------------------------------------------------------------------------

    public static boolean isRegionDistanceValid(String dim, int cx, int cz) {
        return InfestationZoneRegistry.isDistanceValid(dim, cx, cz);
    }

    public static int[] getNearestInfestedRegionCentre(String dim, int cx, int cz, int searchRadius) {
        return InfestationZoneRegistry.getNearestZoneCentre(dim, cx, cz, searchRadius);
    }

    // -------------------------------------------------------------------------
    // Per-chunk helpers (still used for tier-based effects / spawning)
    // -------------------------------------------------------------------------

    public static ChunkInfestationLevel getOrCreate(String dim, int cx, int cz) {
        return chunkData.computeIfAbsent(key(dim, cx, cz), k -> new ChunkInfestationLevel());
    }

    public static ChunkInfestationLevel get(String dim, int cx, int cz) {
        return chunkData.getOrDefault(key(dim, cx, cz), new ChunkInfestationLevel());
    }

    public static void addInfestation(String dim, int cx, int cz, int amount) {
        getOrCreate(dim, cx, cz).addInfestation(amount);
    }

    public static void addInfestationFromZombie(String dim, int cx, int cz, int amount) {
        getOrCreate(dim, cx, cz).addInfestationForced(amount);
    }

    public static void removeInfestation(String dim, int cx, int cz, int amount) {
        String k = key(dim, cx, cz);
        ChunkInfestationLevel inf = chunkData.get(k);
        if (inf != null) {
            inf.removeInfestation(amount);
            if (inf.getLevel() <= 0 && !inf.isCleared()) chunkData.remove(k);
        }
    }

    public static void markChunkCleared(String dim, int cx, int cz) {
        ChunkInfestationLevel inf = getOrCreate(dim, cx, cz);
        inf.markCleared();
    }

    public static boolean isChunkCleared(String dim, int cx, int cz) {
        ChunkInfestationLevel inf = chunkData.get(key(dim, cx, cz));
        return inf != null && inf.isCleared();
    }

    public static int getLevel(String dim, int cx, int cz) {
        // Prefer zone entity's population if the chunk is in a zone
        InfestationEntity entity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);
        if (entity != null) return entity.getPopulation();
        return get(dim, cx, cz).getLevel();
    }

    public static ChunkInfestationLevel.Tier getTier(String dim, int cx, int cz) {
        return get(dim, cx, cz).getTier();
    }

    public static Set<Map.Entry<String, ChunkInfestationLevel>> getAllEntries() {
        return chunkData.entrySet();
    }

    public static Map<String, ChunkInfestationLevel> getChunkData() {
        return chunkData;
    }

    // -------------------------------------------------------------------------
    // Persistence (per-chunk map)
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(2); // version
            out.writeInt(chunkData.size());
            for (Map.Entry<String, ChunkInfestationLevel> entry : chunkData.entrySet()) {
                out.writeUTF(entry.getKey());
                ChunkInfestationLevel inf = entry.getValue();
                out.writeInt(inf.getLevel());
                out.writeLong(inf.getLastActivityTime());
                out.writeBoolean(inf.hasActiveHorde());
                out.writeBoolean(inf.isCleared());
                out.writeInt(inf.getZombieReserve());
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved {} infested chunks.", chunkData.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save infestation data", e);
        }
        // Also save zone registry
        InfestationZoneRegistry.save(mcServer);
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int version = in.readInt();
            int count   = in.readInt();
            for (int i = 0; i < count; i++) {
                String k     = in.readUTF();
                int level    = in.readInt();
                long time    = in.readLong();
                boolean horde = in.readBoolean();
                boolean cleared = false;
                int reserve = 0;
                if (version >= 2) {
                    cleared = in.readBoolean();
                    reserve = in.readInt();
                }
                chunkData.put(k, new ChunkInfestationLevel(level, time, horde, cleared, reserve));
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded {} infested chunks.", chunkData.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load infestation data", e);
        }
    }
}
