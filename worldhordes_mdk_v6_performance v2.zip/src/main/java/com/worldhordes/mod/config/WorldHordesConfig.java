package com.worldhordes.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class WorldHordesConfig {

    public static final ForgeConfigSpec COMMON_SPEC;
    public static final WorldHordesConfig COMMON;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        COMMON = new WorldHordesConfig(builder);
        COMMON_SPEC = builder.build();
    }

    // === Horde Density ===
    public final ForgeConfigSpec.IntValue densityPerZombieSpawn;
    /**
     * Baseline natural zombie spawns per 60 s considered "vanilla normal".
     * At or below this rate each spawn contributes full densityPerZombieSpawn points.
     * Above this rate the contribution is scaled down proportionally so that modded
     * servers with high spawn rates cannot flood the density bank.
     */
    public final ForgeConfigSpec.IntValue naturalSpawnRateBaseline;
    public final ForgeConfigSpec.IntValue densityPerZombieKillByPlayer;
    public final ForgeConfigSpec.IntValue densityPerPlayerKilled;
    public final ForgeConfigSpec.IntValue densityPerNpcKilled;
    public final ForgeConfigSpec.IntValue densityDecayPerMinute;
    public final ForgeConfigSpec.IntValue densityThresholdForHorde;
    public final ForgeConfigSpec.IntValue maxGlobalDensity;

    // === Horde Spawning ===
    public final ForgeConfigSpec.IntValue hordeMinSize;
    public final ForgeConfigSpec.IntValue hordeMaxSize;
    public final ForgeConfigSpec.IntValue hordeSpawnIntervalTicks;
    public final ForgeConfigSpec.IntValue maxActiveHordes;
    public final ForgeConfigSpec.IntValue hordeMoveCooldownTicks;
    public final ForgeConfigSpec.IntValue hordeChunksPerMove;

    // === Infestation Zone Layout ===
    /** Minimum Chebyshev chunk distance between infestation zone centres. */
    public final ForgeConfigSpec.IntValue infestationRegionMinDistance;
    /** Infestation growth rate: points seeded per chunk when a horde arrives. */
    public final ForgeConfigSpec.IntValue infestationGrowthRate;

    // === Infestation Core Zone Spawning ===
    /** Max zombies spawned per pulse from a Core Zone chunk reserve. */
    public final ForgeConfigSpec.IntValue coreSpawnPerPulse;
    /** Infestation amount seeded into each Core chunk when an infestation is created. */
    public final ForgeConfigSpec.IntValue coreInitialInfestation;
    /** Horde population limit for the Core Zone (max reserve per core chunk). */
    public final ForgeConfigSpec.IntValue coreHordePopulationLimit;

    // === Infestation Outer Ring Spawning ===
    /** Max zombies spawned per pulse from an Outer Ring chunk reserve. */
    public final ForgeConfigSpec.IntValue outerRingSpawnPerPulse;
    /** Infestation amount seeded into each Outer Ring chunk when an infestation is created. */
    public final ForgeConfigSpec.IntValue outerRingInitialInfestation;
    /** Horde population limit for the Outer Ring (max reserve per ring chunk). */
    public final ForgeConfigSpec.IntValue outerRingHordePopulationLimit;

    // === Common Infestation ===
    public final ForgeConfigSpec.IntValue infestationGrowthPerZombie;
    public final ForgeConfigSpec.IntValue infestationDecayPerKill;
    public final ForgeConfigSpec.IntValue infestationDecayPerMinute;
    public final ForgeConfigSpec.IntValue infestationMaxLevel;
    public final ForgeConfigSpec.IntValue infestationSpreadThreshold;
    public final ForgeConfigSpec.DoubleValue infestationSpreadChance;
    public final ForgeConfigSpec.IntValue infestationTier1;
    public final ForgeConfigSpec.IntValue infestationTier2;
    public final ForgeConfigSpec.IntValue infestationTier3;
    public final ForgeConfigSpec.IntValue infestationRegionRadius;
    public final ForgeConfigSpec.IntValue infestationChunkSpawnPulseTicks;
    public final ForgeConfigSpec.IntValue infestationSpawnMinDistFromPlayer;
    public final ForgeConfigSpec.IntValue infestationSpawnMaxDistFromPlayer;
    public final ForgeConfigSpec.IntValue infestationFromZombieEntry;
    public final ForgeConfigSpec.IntValue infestationClearedThreshold;
    public final ForgeConfigSpec.IntValue infestationDestroyThreshold;
    public final ForgeConfigSpec.IntValue infestationRegenIntervalDays;
    public final ForgeConfigSpec.IntValue infestationRegenAmountTier1;
    public final ForgeConfigSpec.IntValue infestationRegenAmountHighTier;
    /** Chunk radius in which a player triggers a proximity warning. */
    public final ForgeConfigSpec.IntValue infestationWarningDetectionChunks;

    // === Blood Splatter Decals ===
    /** Enable the custom blood splatter decal system (replaces old redstone). */
    public final ForgeConfigSpec.BooleanValue enableBloodDecals;
    /** Chance out of 1000 per zombie tick that it places a blood decal (Core Zone). */
    public final ForgeConfigSpec.IntValue bloodDecalPlaceChanceCore;
    /** Chance out of 1000 per zombie tick that it places a blood decal (Outer Ring). */
    public final ForgeConfigSpec.IntValue bloodDecalPlaceChanceOuter;
    /** Max blood decal variants (textures 0 to N-1). */
    public final ForgeConfigSpec.IntValue bloodDecalVariants;

    // === Spawn Modifiers ===
    public final ForgeConfigSpec.IntValue tier1ExtraZombies;
    public final ForgeConfigSpec.IntValue tier2ExtraZombies;
    public final ForgeConfigSpec.IntValue tier3ExtraZombies;
    public final ForgeConfigSpec.IntValue tier1GroupSizeBonus;
    public final ForgeConfigSpec.IntValue tier2GroupSizeBonus;
    public final ForgeConfigSpec.IntValue tier3GroupSizeBonus;

    // === Horde Migration ===
    public final ForgeConfigSpec.DoubleValue hordeEnterInfestedChunkChance;
    public final ForgeConfigSpec.IntValue hordeInfestOnArrivalAmount;
    public final ForgeConfigSpec.IntValue hordeZombiesLeftBehindOnExit;

    // === Performance / Population Cap ===
    /**
     * Hard cap on the total number of WorldHordes-spawned zombies alive at the same time
     * across all players on the server.  New spawn pulses are skipped entirely while live
     * count >= this value.  Range 50-100 is recommended to prevent server lag.
     */
    public final ForgeConfigSpec.IntValue maxLiveHordeZombies;
    /**
     * Ticks after a spawn pulse during which the spawner will NOT emit another wave if
     * players are still in active combat (live zombie count > combatPauseZombieThreshold).
     * This prevents back-to-back wave spam while a fight is already in progress.
     */
    public final ForgeConfigSpec.IntValue combatPauseTicks;
    /**
     * Minimum number of currently-alive WorldHordes zombies that counts as "active combat".
     * If live count exceeds this value the spawn pulse is deferred for combatPauseTicks.
     */
    public final ForgeConfigSpec.IntValue combatPauseZombieThreshold;

    // === Misc ===
    public final ForgeConfigSpec.BooleanValue debugMode;
    public final ForgeConfigSpec.IntValue ticksPerInfestationUpdate;

    public WorldHordesConfig(ForgeConfigSpec.Builder builder) {

        builder.push("horde_density");
        densityPerZombieSpawn = builder.comment(
                "Base density points added per natural zombie spawn. " +
                "The actual contribution is devalued automatically when the spawn rate " +
                "exceeds naturalSpawnRateBaseline, so modded servers with burst spawners " +
                "cannot overwhelm the density bank. Set to 0 to disable natural-spawn density entirely.")
                .defineInRange("densityPerZombieSpawn", 1, 0, 100);
        naturalSpawnRateBaseline = builder.comment(
                "Expected number of natural zombie spawns per 60 seconds under vanilla conditions. " +
                "When recent spawns exceed this baseline the per-spawn density contribution is scaled " +
                "down proportionally (effective = base / (recentSpawns / baseline)), keeping total " +
                "natural-spawn density roughly constant regardless of mod spawn rates. " +
                "Increase this if your pack has higher baseline zombie spawn rates. Default: 20.")
                .defineInRange("naturalSpawnRateBaseline", 20, 1, 10000);
        densityPerZombieKillByPlayer = builder.comment("Density removed per zombie killed by a player")
                .defineInRange("densityPerZombieKillByPlayer", -2, -100, 0);
        densityPerPlayerKilled = builder.comment("Density added when a player is killed by a zombie")
                .defineInRange("densityPerPlayerKilled", 25, 0, 1000);
        densityPerNpcKilled = builder.comment("Density added when an NPC (villager, etc.) is killed by a zombie")
                .defineInRange("densityPerNpcKilled", 10, 0, 500);
        densityDecayPerMinute = builder.comment("Density decay per real minute (server tick cycle)")
                .defineInRange("densityDecayPerMinute", 3, 0, 100);
        densityThresholdForHorde = builder.comment("Minimum Horde Density to trigger a wandering horde spawn")
                .defineInRange("densityThresholdForHorde", 100, 1, 100000);
        maxGlobalDensity = builder.comment("Maximum global Horde Density cap")
                .defineInRange("maxGlobalDensity", 10000, 100, Integer.MAX_VALUE);
        builder.pop();

        builder.push("horde_spawning");
        hordeMinSize = builder.comment("Minimum number of zombies in a spawned horde")
                .defineInRange("hordeMinSize", 8, 1, 200);
        hordeMaxSize = builder.comment("Maximum number of zombies in a spawned horde")
                .defineInRange("hordeMaxSize", 30, 1, 500);
        hordeSpawnIntervalTicks = builder.comment("Ticks between horde spawn checks (20 ticks = 1 second)")
                .defineInRange("hordeSpawnIntervalTicks", 6000, 100, 72000);
        maxActiveHordes = builder.comment("Maximum number of active wandering hordes at once")
                .defineInRange("maxActiveHordes", 5, 1, 50);
        hordeMoveCooldownTicks = builder.comment("Ticks between horde movement steps")
                .defineInRange("hordeMoveCooldownTicks", 1200, 20, 24000);
        hordeChunksPerMove = builder.comment("Number of chunks a horde travels per movement step")
                .defineInRange("hordeChunksPerMove", 1, 1, 10);
        builder.pop();

        builder.push("infestation_zone_layout");
        infestationRegionMinDistance = builder.comment(
                "Minimum Chebyshev chunk distance between infestation zone centres. " +
                "Natural zombie spawns can only create a new infestation if no existing infestation " +
                "is closer than this many chunks. Default: 15 chunks (~240 blocks).")
                .defineInRange("infestationRegionMinDistance", 18, 0, 10000);
        infestationGrowthRate = builder.comment(
                "Infestation growth rate: points seeded into each chunk when a horde first arrives. " +
                "Higher values = larger initial infestation footprint.")
                .defineInRange("infestationGrowthRate", 150, 1, 10000);
        builder.pop();

        builder.push("infestation_core_zone");
        coreSpawnPerPulse = builder.comment(
                "Max zombies spawned per pulse from a Core Zone (2x2 centre chunks) reserve. " +
                "Core is the densest, most dangerous part of the infestation.")
                .defineInRange("coreSpawnPerPulse", 6, 0, 50);
        coreInitialInfestation = builder.comment(
                "Infestation points seeded into each Core Zone chunk when an infestation is created. " +
                "Must be below infestationTier1 (default 50) so new dens start at Tier 0 and grow naturally. " +
                "Old default of 800 caused day-one Tier 3 spawns because it exceeded the Tier 3 threshold (400).")
                .defineInRange("coreInitialInfestation", 30, 0, 100000);
        coreHordePopulationLimit = builder.comment(
                "Maximum zombie reserve population per Core chunk. " +
                "Limits how many zombies can accumulate in the core before no more are added.")
                .defineInRange("coreHordePopulationLimit", 40, 1, 500);
        builder.pop();

        builder.push("infestation_outer_ring");
        outerRingSpawnPerPulse = builder.comment(
                "Max zombies spawned per pulse from an Outer Ring chunk reserve. " +
                "Lower than core — the ring is a transitional buffer zone.")
                .defineInRange("outerRingSpawnPerPulse", 2, 0, 50);
        outerRingInitialInfestation = builder.comment(
                "Infestation points seeded into each Outer Ring chunk when an infestation is created. " +
                "Must be below infestationTier1 (default 50) so new dens start at Tier 0 and grow naturally. " +
                "Old default of 300 caused day-one Tier 2 spawns because it exceeded the Tier 2 threshold (200).")
                .defineInRange("outerRingInitialInfestation", 10, 0, 100000);
        outerRingHordePopulationLimit = builder.comment(
                "Maximum zombie reserve population per Outer Ring chunk.")
                .defineInRange("outerRingHordePopulationLimit", 12, 1, 500);
        builder.pop();

        builder.push("infestation");
        infestationGrowthPerZombie = builder.comment("Infestation level added per zombie in a chunk")
                .defineInRange("infestationGrowthPerZombie", 2, 0, 100);
        infestationDecayPerKill = builder.comment("Infestation level removed per zombie kill in that chunk")
                .defineInRange("infestationDecayPerKill", 5, 0, 1000);
        infestationDecayPerMinute = builder.comment("Passive infestation decay per minute in a chunk with no zombies")
                .defineInRange("infestationDecayPerMinute", 1, 0, 100);
        infestationMaxLevel = builder.comment("Maximum infestation level a chunk can reach")
                .defineInRange("infestationMaxLevel", 1000, 10, 100000);
        infestationSpreadThreshold = builder.comment("Infestation level at which a chunk begins spreading to neighbors")
                .defineInRange("infestationSpreadThreshold", 200, 1, 100000);
        infestationSpreadChance = builder.comment("Chance per minute that infestation spreads to an adjacent chunk (0.0-1.0)")
                .defineInRange("infestationSpreadChance", 0.15, 0.0, 1.0);
        infestationTier1 = builder.comment("Infestation level for Tier 1 (low infestation effects). Default: 50.")
                .defineInRange("infestationTier1", 50, 0, 100000);
        infestationTier2 = builder.comment("Infestation level for Tier 2 (medium infestation effects). Default: 200.")
                .defineInRange("infestationTier2", 200, 0, 100000);
        infestationTier3 = builder.comment("Infestation level for Tier 3 (max infestation effects). Default: 400.")
                .defineInRange("infestationTier3", 400, 0, 100000);
        infestationRegionRadius = builder.comment(
                "Radius in chunks used for infestation spread reach. " +
                "Controls how far spread logic searches outward from each infested chunk.")
                .defineInRange("infestationRegionRadius", 4, 1, 64);
        infestationChunkSpawnPulseTicks = builder.comment(
                "Ticks between infested-chunk zombie spawn pulses when a player is inside the region.")
                .defineInRange("infestationChunkSpawnPulseTicks", 400, 20, 72000);
        infestationSpawnMinDistFromPlayer = builder.comment(
                "Minimum block distance from a player when spawning infested-chunk zombies.")
                .defineInRange("infestationSpawnMinDistFromPlayer", 20, 8, 200);
        infestationSpawnMaxDistFromPlayer = builder.comment(
                "Maximum block distance from a player when spawning infested-chunk zombies.")
                .defineInRange("infestationSpawnMaxDistFromPlayer", 48, 16, 400);
        infestationFromZombieEntry = builder.comment(
                "Infestation points added when a zombie physically walks into a chunk (including cleared ones).")
                .defineInRange("infestationFromZombieEntry", 8, 0, 500);
        infestationClearedThreshold = builder.comment(
                "Infestation level at or below which a chunk is automatically marked cleared after players kill all zombies.")
                .defineInRange("infestationClearedThreshold", 0, 0, 1000);
        infestationDestroyThreshold = builder.comment(
                "Zone population threshold below which the entire infestation is destroyed. " +
                "When the shared zone population falls to or below this value all blood decals are removed " +
                "and the infestation data is wiped. Set to 0 to only destroy on complete elimination.")
                .defineInRange("infestationDestroyThreshold", 10, 0, 100000);
        infestationRegenIntervalDays = builder.comment(
                "In-game Minecraft days between zombie population regeneration ticks for established " +
                "infestations (tied to the world's day/night cycle, not real-world time). " +
                "Default: 1 Minecraft day. Set to 0 to disable regen entirely.")
                .defineInRange("infestationRegenIntervalDays", 1, 0, 30);
        infestationRegenAmountTier1 = builder.comment(
                "Max zombies regenerated per regen tick for a Tier 1 (low danger) infestation zone. " +
                "Default: 1 — Tier 1 zones recover slowly.")
                .defineInRange("infestationRegenAmountTier1", 1, 0, 100);
        infestationRegenAmountHighTier = builder.comment(
                "Max zombies regenerated per regen tick for a Tier 2 or Tier 3 (established/dangerous) " +
                "infestation zone. Default: 10.")
                .defineInRange("infestationRegenAmountHighTier", 10, 0, 100);
        infestationWarningDetectionChunks = builder.comment(
                "Chunk radius in which a player triggers a proximity warning for a nearby active infestation. " +
                "Set to 0 to disable player warnings.")
                .defineInRange("infestationWarningDetectionChunks", 6, 0, 64);
        builder.pop();

        builder.push("blood_splatter_decals");
        enableBloodDecals = builder.comment(
                "If true, enables the custom blood splatter decal system. " +
                "Decals are placed by zombies on natural ground inside infested zones, " +
                "do not drop items when broken, and are removed when the infestation is cleared.")
                .define("enableBloodDecals", true);
        bloodDecalPlaceChanceCore = builder.comment(
                "Chance out of 1000 per zombie per 20-tick check that it places a blood decal " +
                "while in the Core Zone (default 8 = 0.8%). Core has higher density than Outer Ring.")
                .defineInRange("bloodDecalPlaceChanceCore", 8, 0, 1000);
        bloodDecalPlaceChanceOuter = builder.comment(
                "Chance out of 1000 per zombie per 20-tick check that it places a blood decal " +
                "while in the Outer Ring (default 3 = 0.3%). Lower than core.")
                .defineInRange("bloodDecalPlaceChanceOuter", 3, 0, 1000);
        bloodDecalVariants = builder.comment(
                "Number of blood splatter texture variants available (textures named blood_splatter_0 to blood_splatter_N-1). " +
                "The system picks randomly among these for natural-looking contamination.")
                .defineInRange("bloodDecalVariants", 4, 1, 16);
        builder.pop();

        builder.push("spawn_modifiers");
        tier1ExtraZombies = builder.comment(
                "Extra zombies guaranteed per natural spawn in Tier 1 chunks. " +
                "This only ever triggers off an actual natural spawn happening nearby — it never " +
                "summons zombies on its own.")
                .defineInRange("tier1ExtraZombies", 1, 0, 20);
        tier2ExtraZombies = builder.comment(
                "Extra zombies guaranteed per natural spawn in Tier 2 chunks. " +
                "Default 0: Tier 2 no longer force-spawns bonus zombies on top of a natural spawn — " +
                "pressure instead comes only from the group-size roll below and the zone's own " +
                "population-driven wave spawner, keeping growth from compounding unfairly.")
                .defineInRange("tier2ExtraZombies", 0, 0, 50);
        tier3ExtraZombies = builder.comment(
                "Extra zombies guaranteed per natural spawn in Tier 3 chunks. " +
                "Default 0: same reasoning as Tier 2 — at the highest danger tier we still don't want " +
                "every single natural spawn to also force-summon a flat extra batch of zombies. " +
                "Tier 3 only counts and amplifies natural spawns that actually happen nearby.")
                .defineInRange("tier3ExtraZombies", 0, 0, 100);
        tier1GroupSizeBonus = builder.comment("Bonus to zombie group spawn size in Tier 1 chunks")
                .defineInRange("tier1GroupSizeBonus", 2, 0, 20);
        tier2GroupSizeBonus = builder.comment("Bonus to zombie group spawn size in Tier 2 chunks")
                .defineInRange("tier2GroupSizeBonus", 5, 0, 50);
        tier3GroupSizeBonus = builder.comment("Bonus to zombie group spawn size in Tier 3 chunks")
                .defineInRange("tier3GroupSizeBonus", 10, 0, 100);
        builder.pop();

        builder.push("horde_migration");
        hordeEnterInfestedChunkChance = builder.comment("Chance a horde enters a heavily infested chunk instead of continuing (0.0-1.0)")
                .defineInRange("hordeEnterInfestedChunkChance", 0.3, 0.0, 1.0);
        hordeInfestOnArrivalAmount = builder.comment("Infestation amount added when a horde arrives in a chunk")
                .defineInRange("hordeInfestOnArrivalAmount", 150, 0, 10000);
        hordeZombiesLeftBehindOnExit = builder.comment("Number of infestation points left behind when a horde moves out")
                .defineInRange("hordeZombiesLeftBehindOnExit", 50, 0, 1000);
        builder.pop();

        builder.push("performance");
        maxLiveHordeZombies = builder.comment(
                "Hard cap on the total WorldHordes-tagged zombies alive at once across all players. " +
                "No new spawn pulse fires while the live count is at or above this value. " +
                "Recommended: 50–100. Lower = better server performance. Default: 75.")
                .defineInRange("maxLiveHordeZombies", 75, 10, 500);
        combatPauseTicks = builder.comment(
                "Ticks the spawner is silenced after a wave if players are still in combat " +
                "(live count > combatPauseZombieThreshold). Prevents wave stacking during fights. " +
                "Default: 200 ticks = 10 seconds.")
                .defineInRange("combatPauseTicks", 200, 20, 72000);
        combatPauseZombieThreshold = builder.comment(
                "Minimum live WorldHordes zombie count considered 'active combat'. " +
                "If this many or more tagged zombies are alive when a pulse fires, " +
                "the pulse is deferred by combatPauseTicks. Default: 15.")
                .defineInRange("combatPauseZombieThreshold", 15, 1, 200);
        builder.pop();

        builder.push("misc");
        debugMode = builder.comment("Enable debug logging for horde and infestation events")
                .define("debugMode", false);
        ticksPerInfestationUpdate = builder.comment("How often (in ticks) infestation levels are recalculated globally")
                .defineInRange("ticksPerInfestationUpdate", 1200, 20, 72000);
        builder.pop();
    }
}
