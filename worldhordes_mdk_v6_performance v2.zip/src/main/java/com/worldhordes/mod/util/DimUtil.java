package com.worldhordes.mod.util;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

public class DimUtil {

    public static final String OVERWORLD_DIM = "minecraft:overworld";
    public static final String NETHER_DIM = "minecraft:the_nether";
    public static final String END_DIM = "minecraft:the_end";

    public static String getDim(ServerLevel level) {
        return level.dimension().location().toString();
    }

    public static boolean isOverworld(ServerLevel level) {
        return level.dimension() == Level.OVERWORLD;
    }
}
