package com.worldhordes.mod.registry;

import net.minecraftforge.eventbus.api.IEventBus;

public class ModCapabilities {

    public static void register(IEventBus modEventBus) {
        // Placeholder for future capability registration (e.g. per-player zombie kill tracking)
    }
}
