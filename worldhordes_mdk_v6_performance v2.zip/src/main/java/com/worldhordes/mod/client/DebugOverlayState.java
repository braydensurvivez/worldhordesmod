package com.worldhordes.mod.client;

/**
 * Singleton state for client-side debug features.
 * Keeps track of whether the chunk infestation overlay is enabled.
 */
public class DebugOverlayState {

    private static boolean overlayEnabled = false;

    public static boolean isOverlayEnabled() {
        return overlayEnabled;
    }

    public static void setOverlayEnabled(boolean enabled) {
        overlayEnabled = enabled;
    }

    public static void toggle() {
        overlayEnabled = !overlayEnabled;
    }
}
