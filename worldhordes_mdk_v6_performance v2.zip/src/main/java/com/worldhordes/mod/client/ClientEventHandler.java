package com.worldhordes.mod.client;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.command.WorldHordesCommand;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;

/**
 * Handles client-only events:
 *   - F3+I keypress → toggle chunk infestation overlay
 *   - RegisterCommandsEvent → register /worldhordes command tree
 */
@OnlyIn(Dist.CLIENT)
public class ClientEventHandler {

    /**
     * Called from the mod event bus (client only) to register key mappings.
     * The actual F3+I detection is done via InputEvent since F3 combos bypass KeyMapping.
     */
    @SubscribeEvent
    public void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        // No custom KeyMapping needed — F3+I is handled via InputEvent below.
        // This is here as a hook in case you want to add a standalone toggle key later.
    }

    /**
     * Detect F3+I to toggle the overlay.
     * F3 is GLFW_KEY_F3. We check that F3 is held and I is freshly pressed.
     */
    @SubscribeEvent
    public void onKeyInput(InputEvent.Key event) {
        if (event.getKey() == GLFW.GLFW_KEY_I && event.getAction() == GLFW.GLFW_PRESS) {
            long window = net.minecraft.client.Minecraft.getInstance().getWindow().getWindow();
            boolean f3Held = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_F3) == GLFW.GLFW_PRESS;
            if (f3Held) {
                DebugOverlayState.toggle();
                WorldHordesMod.LOGGER.info("[WorldHordes] Chunk overlay toggled: {}",
                        DebugOverlayState.isOverlayEnabled() ? "ON" : "OFF");
            }
        }
    }
}
