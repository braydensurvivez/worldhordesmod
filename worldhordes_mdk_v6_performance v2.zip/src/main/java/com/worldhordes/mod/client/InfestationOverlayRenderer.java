package com.worldhordes.mod.client;

import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.horde.HordeManager;
import com.worldhordes.mod.horde.WanderingHorde;
import com.worldhordes.mod.util.DimUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Map;

/**
 * Client-side renderer that draws:
 *   1. Colored chunk borders in the world (T1=yellow, T2=orange, T3=red, horde=magenta)
 *   2. A HUD overlay showing current chunk infestation info and global stats
 *
 * Toggle with F3+I (handled in ClientEventHandler).
 * Renders chunks within RENDER_RADIUS of the player.
 */
@OnlyIn(Dist.CLIENT)
public class InfestationOverlayRenderer {

    private static final int RENDER_RADIUS = 8; // chunks in each direction

    // ARGB colours for the chunk border lines
    private static final int COLOR_TIER1  = 0xFFFFFF00; // yellow
    private static final int COLOR_TIER2  = 0xFFFF8800; // orange
    private static final int COLOR_TIER3  = 0xFFFF2200; // red
    private static final int COLOR_HORDE  = 0xFFFF00FF; // magenta
    private static final int COLOR_SPREAD = 0xFFAA00FF; // purple (spreading but no tier yet)

    @SubscribeEvent
    public void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!DebugOverlayState.isOverlayEnabled()) return;

        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) return;

        // InfestationData is a server-side class but accessible from the integrated server
        // in single-player. In multiplayer this won't have data, which is fine – the map
        // will simply show no chunks. A proper implementation would use a network packet.
        if (mc.level == null) return;

        Camera camera = event.getCamera();
        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        VertexConsumer lines = bufferSource.getBuffer(RenderType.lines());

        double camX = camera.getPosition().x;
        double camY = camera.getPosition().y;
        double camZ = camera.getPosition().z;

        ChunkPos playerChunk = new ChunkPos(player.blockPosition());

        // Get dimension string via the level's dimension key
        String dim = mc.level.dimension().location().toString();

        poseStack.pushPose();
        poseStack.translate(-camX, -camY, -camZ);
        Matrix4f matrix = poseStack.last().pose();

        for (int dcx = -RENDER_RADIUS; dcx <= RENDER_RADIUS; dcx++) {
            for (int dcz = -RENDER_RADIUS; dcz <= RENDER_RADIUS; dcz++) {
                int cx = playerChunk.x + dcx;
                int cz = playerChunk.z + dcz;

                ChunkInfestationLevel infest = InfestationData.get(dim, cx, cz);
                if (infest.getLevel() <= 0) continue;

                int color = getColor(infest);
                drawChunkBorder(lines, matrix, cx, cz, camY, color);
            }
        }

        // Draw horde positions as a pulsing cross marker
        List<WanderingHorde> hordes = HordeManager.getActiveHordes();
        for (WanderingHorde horde : hordes) {
            if (!horde.getDimension().equals(dim)) continue;
            int hcx = horde.getChunkX();
            int hcz = horde.getChunkZ();
            if (Math.abs(hcx - playerChunk.x) > RENDER_RADIUS * 2) continue;
            if (Math.abs(hcz - playerChunk.z) > RENDER_RADIUS * 2) continue;
            drawHordeMarker(lines, matrix, horde, camY);
        }

        bufferSource.endBatch(RenderType.lines());
        poseStack.popPose();
    }

    @SubscribeEvent
    public void onRenderGuiOverlay(RenderGuiOverlayEvent.Post event) {
        if (!DebugOverlayState.isOverlayEnabled()) return;

        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.level == null) return;

        GuiGraphics gui = event.getGuiGraphics();
        int screenW = mc.getWindow().getGuiScaledWidth();

        String dim = mc.level.dimension().location().toString();
        ChunkPos cp = new ChunkPos(player.blockPosition());
        ChunkInfestationLevel infest = InfestationData.get(dim, cp.x, cp.z);

        int density = HordeDensityManager.getDensity();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        int maxDensity = WorldHordesConfig.COMMON.maxGlobalDensity.get();
        int activeHordes = HordeManager.getActiveHordes().size();
        int infestCount = InfestationData.getAllEntries().size();

        // Draw HUD panel in top-right corner
        int x = screenW - 160;
        int y = 5;
        int lineH = 10;
        int padding = 4;
        int panelW = 155;
        int panelH = lineH * 8 + padding * 2;

        // Semi-transparent background
        gui.fill(x - padding, y - padding, x + panelW, y + panelH, 0x88000000);

        // Title
        gui.drawString(mc.font, "§6§lWorld Hordes Debug", x, y, 0xFFFFFF);
        y += lineH + 2;

        // Current chunk info
        String tierStr = tierColorLabel(infest.getTier());
        gui.drawString(mc.font, "§7Chunk: §f(" + cp.x + "," + cp.z + ")", x, y, 0xFFFFFF);
        y += lineH;
        gui.drawString(mc.font, "§7Infest: §f" + infest.getLevel() + " " + tierStr
                + (infest.hasActiveHorde() ? " §c[HORDE]" : ""), x, y, 0xFFFFFF);
        y += lineH;

        // Density bar
        float densityPct = Math.min(1.0f, (float) density / maxDensity);
        float thresholdPct = Math.min(1.0f, (float) threshold / maxDensity);
        int barW = panelW - 2;
        int barY = y + 1;
        gui.fill(x, barY, x + barW, barY + 6, 0xFF333333);
        int filledW = (int)(barW * densityPct);
        int barColor = density >= threshold ? 0xFFFF4444 : 0xFF44AA44;
        if (filledW > 0) gui.fill(x, barY, x + filledW, barY + 6, barColor);
        // Threshold line
        int threshX = x + (int)(barW * thresholdPct);
        gui.fill(threshX, barY, threshX + 1, barY + 6, 0xFFFFFFFF);
        y += lineH;

        gui.drawString(mc.font, "§7Density: §f" + density + " §7/ " + maxDensity
                + (density >= threshold ? " §c▲" : ""), x, y, 0xFFFFFF);
        y += lineH;

        // Hordes
        gui.drawString(mc.font, "§7Active Hordes: §f" + activeHordes
                + " §7/ " + WorldHordesConfig.COMMON.maxActiveHordes.get(), x, y, 0xFFFFFF);
        y += lineH;

        gui.drawString(mc.font, "§7Infested Chunks: §f" + infestCount, x, y, 0xFFFFFF);
        y += lineH;

        // Legend
        gui.drawString(mc.font, "§a■§7T1 §6■§7T2 §c■§7T3 §d■§7Horde", x, y, 0xFFFFFF);
        y += lineH;

        gui.drawString(mc.font, "§7[F3+I] Toggle Overlay", x, y, 0x888888);
    }

    // =========================================================================
    //  Drawing helpers
    // =========================================================================

    private static void drawChunkBorder(VertexConsumer lines, Matrix4f matrix,
                                         int cx, int cz, double camY, int argbColor) {
        float r = ((argbColor >> 16) & 0xFF) / 255f;
        float g = ((argbColor >> 8)  & 0xFF) / 255f;
        float b = ( argbColor        & 0xFF) / 255f;
        float a = ((argbColor >> 24) & 0xFF) / 255f;

        double x0 = cx * 16.0;
        double z0 = cz * 16.0;
        double x1 = x0 + 16.0;
        double z1 = z0 + 16.0;

        // Draw border at 3 heights so it's visible through terrain
        double[] yLevels = {camY - 3, camY + 2, camY + 20};

        for (double y : yLevels) {
            // Four edges of the chunk square
            drawLine(lines, matrix, x0, y, z0, x1, y, z0, r, g, b, a);
            drawLine(lines, matrix, x1, y, z0, x1, y, z1, r, g, b, a);
            drawLine(lines, matrix, x1, y, z1, x0, y, z1, r, g, b, a);
            drawLine(lines, matrix, x0, y, z1, x0, y, z0, r, g, b, a);
        }

        // Vertical pillars at corners
        double yBot = camY - 3;
        double yTop = camY + 20;
        drawLine(lines, matrix, x0, yBot, z0, x0, yTop, z0, r, g, b, a * 0.5f);
        drawLine(lines, matrix, x1, yBot, z0, x1, yTop, z0, r, g, b, a * 0.5f);
        drawLine(lines, matrix, x0, yBot, z1, x0, yTop, z1, r, g, b, a * 0.5f);
        drawLine(lines, matrix, x1, yBot, z1, x1, yTop, z1, r, g, b, a * 0.5f);
    }

    private static void drawHordeMarker(VertexConsumer lines, Matrix4f matrix,
                                         WanderingHorde horde, double camY) {
        double cx = horde.getChunkX() * 16.0 + 8.0; // centre of chunk
        double cz = horde.getChunkZ() * 16.0 + 8.0;
        float r = 1.0f, g = 0.0f, b = 1.0f, a = 1.0f; // magenta
        double half = 8.0;

        // X cross at eye level
        drawLine(lines, matrix, cx - half, camY + 1, cz - half, cx + half, camY + 1, cz + half, r, g, b, a);
        drawLine(lines, matrix, cx + half, camY + 1, cz - half, cx - half, camY + 1, cz + half, r, g, b, a);

        // Vertical spike
        drawLine(lines, matrix, cx, camY - 5, cz, cx, camY + 30, cz, r, g, b, a * 0.6f);
    }

    private static void drawLine(VertexConsumer consumer, Matrix4f matrix,
                                  double x0, double y0, double z0,
                                  double x1, double y1, double z1,
                                  float r, float g, float b, float a) {
        float nx = (float)(x1 - x0);
        float ny = (float)(y1 - y0);
        float nz = (float)(z1 - z0);
        float len = (float)Math.sqrt(nx*nx + ny*ny + nz*nz);
        if (len == 0) return;
        nx /= len; ny /= len; nz /= len;

        consumer.vertex(matrix, (float)x0, (float)y0, (float)z0)
                .color(r, g, b, a).normal(nx, ny, nz).endVertex();
        consumer.vertex(matrix, (float)x1, (float)y1, (float)z1)
                .color(r, g, b, a).normal(nx, ny, nz).endVertex();
    }

    // =========================================================================
    //  Colour helpers
    // =========================================================================

    private static int getColor(ChunkInfestationLevel infest) {
        if (infest.hasActiveHorde()) return COLOR_HORDE;
        return switch (infest.getTier()) {
            case TIER3 -> COLOR_TIER3;
            case TIER2 -> COLOR_TIER2;
            case TIER1 -> COLOR_TIER1;
            default    -> infest.shouldSpread() ? COLOR_SPREAD : 0xFF888888;
        };
    }

    private static String tierColorLabel(ChunkInfestationLevel.Tier tier) {
        return switch (tier) {
            case TIER1 -> "§a[T1]";
            case TIER2 -> "§6[T2]";
            case TIER3 -> "§c[T3]";
            default    -> "§7[NONE]";
        };
    }
}
