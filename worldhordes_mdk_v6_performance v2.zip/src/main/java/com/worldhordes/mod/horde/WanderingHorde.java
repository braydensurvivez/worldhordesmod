package com.worldhordes.mod.horde;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.UUID;

public class WanderingHorde {

    private final UUID id;
    private String dimension;
    private int chunkX;
    private int chunkZ;
    private int size;
    private int targetChunkX;
    private int targetChunkZ;
    private long lastMoveTick;
    private boolean isSettled; // settled into a territory, not wandering
    private int wanderDirection; // 0=N, 1=E, 2=S, 3=W, -1=random each step
    private int stepsTaken;
    private int maxSteps;

    public WanderingHorde(String dimension, int chunkX, int chunkZ, int size) {
        this.id = UUID.randomUUID();
        this.dimension = dimension;
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        this.size = size;
        this.targetChunkX = chunkX;
        this.targetChunkZ = chunkZ;
        this.lastMoveTick = 0;
        this.isSettled = false;
        this.wanderDirection = -1;
        this.stepsTaken = 0;
        this.maxSteps = 20 + (int)(Math.random() * 30); // wander 20-50 chunks before settling
    }

    public WanderingHorde(UUID id, String dimension, int chunkX, int chunkZ, int size,
                          int targetX, int targetZ, long lastMove, boolean settled,
                          int dir, int steps, int maxSteps) {
        this.id = id;
        this.dimension = dimension;
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        this.size = size;
        this.targetChunkX = targetX;
        this.targetChunkZ = targetZ;
        this.lastMoveTick = lastMove;
        this.isSettled = settled;
        this.wanderDirection = dir;
        this.stepsTaken = steps;
        this.maxSteps = maxSteps;
    }

    // Getters
    public UUID getId() { return id; }
    public String getDimension() { return dimension; }
    public int getChunkX() { return chunkX; }
    public int getChunkZ() { return chunkZ; }
    public int getSize() { return size; }
    public int getTargetChunkX() { return targetChunkX; }
    public int getTargetChunkZ() { return targetChunkZ; }
    public long getLastMoveTick() { return lastMoveTick; }
    public boolean isSettled() { return isSettled; }
    public int getWanderDirection() { return wanderDirection; }
    public int getStepsTaken() { return stepsTaken; }
    public int getMaxSteps() { return maxSteps; }

    // Setters
    public void setChunkX(int x) { this.chunkX = x; }
    public void setChunkZ(int z) { this.chunkZ = z; }
    public void setSize(int size) { this.size = Math.max(0, size); }
    public void setTargetChunkX(int x) { this.targetChunkX = x; }
    public void setTargetChunkZ(int z) { this.targetChunkZ = z; }
    public void setLastMoveTick(long tick) { this.lastMoveTick = tick; }
    public void setSettled(boolean settled) { this.isSettled = settled; }
    public void setWanderDirection(int dir) { this.wanderDirection = dir; }
    public void incrementSteps() { this.stepsTaken++; }
    public void setStepsTaken(int steps) { this.stepsTaken = steps; }
    public void setMaxSteps(int max) { this.maxSteps = max; }

    public boolean hasExhausted() {
        return stepsTaken >= maxSteps;
    }

    public boolean isDepleted() {
        return size <= 0;
    }

    public void shrink(int amount) {
        size = Math.max(0, size - amount);
    }

    /**
     * Picks the next chunk position in the wander direction.
     */
    public int[] nextChunkPosition(int chunksPerStep) {
        java.util.Random rand = new java.util.Random();
        int dir = wanderDirection == -1 ? rand.nextInt(4) : wanderDirection;
        int nx = chunkX;
        int nz = chunkZ;
        switch (dir) {
            case 0 -> nz -= chunksPerStep; // North
            case 1 -> nx += chunksPerStep; // East
            case 2 -> nz += chunksPerStep; // South
            case 3 -> nx -= chunksPerStep; // West
        }
        // Occasionally shift direction
        if (rand.nextInt(4) == 0) {
            wanderDirection = rand.nextInt(4);
        }
        return new int[]{nx, nz};
    }

    @Override
    public String toString() {
        return String.format("WanderingHorde[%s, dim=%s, chunk=(%d,%d), size=%d, steps=%d/%d, settled=%b]",
                id.toString().substring(0,8), dimension, chunkX, chunkZ, size, stepsTaken, maxSteps, isSettled);
    }
}
