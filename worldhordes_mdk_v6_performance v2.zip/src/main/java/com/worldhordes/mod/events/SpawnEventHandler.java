package com.worldhordes.mod.events;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationEntity;
import com.worldhordes.mod.data.InfestationZone;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Random;

public class SpawnEventHandler {

    private static final Random RAND = new Random();

    @SubscribeEvent
    public void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn event) {
        if (!(event.getEntity() instanceof Zombie zombie)) return;
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        MobSpawnType reason = event.getSpawnType();
        if (reason != MobSpawnType.NATURAL && reason != MobSpawnType.CHUNK_GENERATION) return;

        // Trickle density into the bank — dynamically devalued when spawn rate is high
        HordeDensityManager.recordNaturalSpawn();

        String dim = DimUtil.getDim(serverLevel);
        BlockPos pos = zombie.blockPosition();
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;

        // Is this spawn inside an existing zone?
        InfestationEntity existingEntity = InfestationZoneRegistry.getEntityFor(dim, cx, cz);

        if (existingEntity != null) {
            // Natural spawn within the zone → grow shared population
            InfestationData.onNaturalZombieSpawnInZone(dim, cx, cz);

            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Natural zombie in zone at ({},{}) — zone pop now {}",
                        cx, cz, existingEntity.getPopulation());
            }
        } else {
            // Outside any zone — may seed a new infestation, but ONLY when world density
            // has reached the horde threshold. Density 0 (or below threshold) → no new dens form.
            // The bank must hold at least the seed cost before a new zone can be funded.
            // seedInfestationRegion() performs the actual withdrawal and distance check;
            // we do a cheap pre-check here to skip the call entirely when funds are clearly low.
            int seedPop = WorldHordesConfig.COMMON.infestationGrowthRate.get();
            int density = HordeDensityManager.getDensity();
            if (density >= seedPop) {
                InfestationZone newZone = InfestationData.seedInfestationRegion(dim, cx, cz, seedPop);
                if (newZone != null && WorldHordesConfig.COMMON.debugMode.get()) {
                    WorldHordesMod.LOGGER.debug(
                            "[WorldHordes] Natural zombie at ({},{}) seeded new zone (cost={}, bank={})",
                            cx, cz, seedPop, HordeDensityManager.getDensity());
                }
            } else if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug(
                        "[WorldHordes] Natural zombie at ({},{}) — bank {} < seed cost {}, no zone.",
                        cx, cz, density, seedPop);
            }
        }

        // Bonus spawns based on per-chunk tier (unchanged behaviour)
        ChunkInfestationLevel infest = InfestationData.get(dim, cx, cz);
        if (infest.isInfested()) {
            spawnExtraZombies(serverLevel, pos, infest);
        }
    }

    private void spawnExtraZombies(ServerLevel level, BlockPos origin, ChunkInfestationLevel infest) {
        int extraCount  = infest.getExtraZombies();
        int groupBonus  = infest.getGroupSizeBonus();
        int totalExtra  = extraCount + (groupBonus > 0 ? RAND.nextInt(groupBonus + 1) : 0);
        if (totalExtra <= 0) return;

        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Infested chunk (tier {}) spawning +{} extra zombies",
                    infest.getTier(), totalExtra);
        }

        for (int i = 0; i < totalExtra; i++) {
            int dx = RAND.nextInt(17) - 8;
            int dz = RAND.nextInt(17) - 8;
            BlockPos spawnPos = findSafeSpawn(level, origin.offset(dx, 0, dz));
            if (spawnPos == null) continue;

            Zombie z = new Zombie(EntityType.ZOMBIE, level);
            z.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
            z.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos), MobSpawnType.MOB_SUMMONED, null, null);
            level.addFreshEntity(z);

            HordeDensityManager.recordNaturalSpawn(); // extra zombies also trickle devalued density
        }
    }

    private BlockPos findSafeSpawn(ServerLevel level, BlockPos base) {
        for (int dy = 5; dy >= -5; dy--) {
            BlockPos pos   = base.above(dy);
            BlockPos below = pos.below();
            if (level.getBlockState(pos).isAir()
                    && level.getBlockState(pos.above()).isAir()
                    && level.getBlockState(below).isCollisionShapeFullBlock(level, below)) {
                return pos;
            }
        }
        return null;
    }
}
