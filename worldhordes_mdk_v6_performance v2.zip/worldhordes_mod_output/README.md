# Days Gone: Zombie Horde Ecosystem Mod
**Minecraft 1.20.1 | Forge 47.4.10**

A dynamic zombie population and territory system inspired by *Days Gone*. The world reacts to every zombie spawned, every kill made, and every survivor lost — building toward a living ecosystem of roaming hordes and infested territories.

---

## Installation

1. Install [Forge 47.4.10 for Minecraft 1.20.1](https://files.minecraftforge.net/)
2. Drop the compiled `daysgone-1.0.0.jar` into your `mods/` folder
3. Start the game — config file generates at `config/daysgone-common.toml`

### Building from Source
```bash
./gradlew build
# Output: build/libs/daysgone-1.0.0.jar
```

---

## Core Systems

### 🧠 Horde Density (Global)
A single global value that tracks the "danger level" of the world's zombie population.

| Event | Density Change |
|-------|----------------|
| Natural zombie spawns | +1 (configurable) |
| Player killed by zombie | +25 |
| NPC/Villager killed by zombie | +10 |
| Player kills a zombie | -2 |

- **Passive decay**: -3 per minute (configurable)
- **Horde threshold**: When density reaches 100+, wandering hordes begin spawning
- **Cap**: 10,000 max density

---

### 🧟 Wandering Hordes
When Horde Density crosses the threshold, a wandering horde forms somewhere in the world — distant from players, but moving toward them.

- **Size scales with density**: Higher density → bigger hordes
- **Movement**: Hordes migrate chunk by chunk on a cooldown timer
- **Encounter**: When a horde passes within 8 chunks of a player, a wave of zombies is deployed
- **Settlement**: Hordes can settle into heavily infested chunks and dig in
- **Max active hordes**: 5 (configurable)

---

### 🗺️ Chunk Infestation System
Every chunk has an infestation level (0–1000+) that determines how dangerous it is.

#### Infestation Sources
- Natural zombie spawns in a chunk: +2 infestation
- Horde arriving in a chunk: +150 infestation
- Horde leaving a chunk: +50 infestation (zombies left behind)

#### Infestation Decay
- Player kills zombie in chunk: -5 infestation
- Passive decay (no horde): -1 per minute

#### Infestation Tiers
| Tier | Level | Effects |
|------|-------|---------|
| **None** | < 50 | Normal vanilla behavior |
| **Tier 1** | 50–199 | +1 extra zombie guaranteed per natural spawn nearby, +2 group size |
| **Tier 2** | 200–399 | No guaranteed extra zombies — only amplifies natural spawns that actually happen nearby, +5 group size |
| **Tier 3** | 400+ | No guaranteed extra zombies — only amplifies natural spawns that actually happen nearby, +10 group size |

Tier 2 and Tier 3 no longer force-summon a flat batch of bonus zombies on top of every natural spawn (the old system could stack +6 guaranteed plus up to +10 random per single spawn event, which snowballed unfairly). Now only Tier 1 has a small guaranteed bonus; higher tiers rely on the group-size roll and the zone's own population-driven wave spawner instead.

#### Dens (Infestation Zones) and World Population
Each infestation "den" is a shared 4×4 zone (2×2 Core + outer ring) — all 16 chunks in it share **one** population pool, so players are fighting one entity instead of 16 separate smaller infestations. A den's live member count is counted directly towards the global World Horde Density (the "world population"), and that contribution rises and falls with the den's actual population — so clearing or shrinking a den genuinely lowers world pressure, rather than past activity permanently inflating the total.

#### Population Regen
Established dens slowly regenerate population, but the regen now ticks with the **Minecraft day/night cycle** rather than real-world time: once per in-game day, a Tier 2/3 den regenerates up to 10 zombies, while a Tier 1 den is capped at 1.

#### Spread
Chunks at 500+ infestation have a 5% chance per minute to spread to each adjacent chunk. Infestation is contagious — clearing one chunk while ignoring neighbors will see it re-infested.

---

### 💾 Data Persistence
All data is saved per-world:
- `<world>/daysgone_density.dat` — Global Horde Density state
- `<world>/daysgone_infestation.dat` — All chunk infestation levels
- `<world>/daysgone_hordes.dat` — All active wandering horde states

Data is automatically loaded on server start and saved on server stop.

---

## Configuration (`config/daysgone-common.toml`)

### Key Settings
```toml
[horde_density]
  densityThresholdForHorde = 100   # Density needed to trigger hordes
  maxGlobalDensity = 10000         # Cap on global density
  densityDecayPerMinute = 3        # Passive density drop per minute

[horde_spawning]
  hordeMinSize = 8                 # Smallest horde that can form
  hordeMaxSize = 30                # Largest horde (scaled by density)
  maxActiveHordes = 5              # How many hordes roam at once
  hordeSpawnIntervalTicks = 6000   # ~5 minutes between horde checks

[infestation]
  infestationSpreadThreshold = 500 # Level at which chunks spread
  infestationSpreadChance = 0.05   # 5% per minute spread chance

[misc]
  debugMode = false                # Enable to see detailed logs
  ticksPerInfestationUpdate = 1200 # ~60s between full updates
```

---

## How Gameplay Changes

**Early game**: Mostly vanilla. A few more zombies in areas you've avoided.

**Mid game**: Horde Density builds. You start seeing larger zombie packs. Chunks near your deaths or NPC villages start showing Tier 1 infestation.

**Late game**: Wandering hordes roam the world. Heavily infested territories become nearly impassable at night. Clearing an area requires systematic zombie elimination across multiple chunks — and constant vigilance against re-infestation from spreading neighbors or migrating hordes.

---

## Mod Structure

```
src/main/java/com/daysgone/mod/
├── DaysGoneMod.java              - Mod entrypoint
├── config/
│   └── DaysGoneConfig.java       - All config values
├── data/
│   ├── HordeDensityManager.java  - Global density tracker + persistence
│   ├── InfestationData.java      - Per-chunk infestation + spread + persistence
│   └── ChunkInfestationLevel.java- Data model for one chunk's infestation
├── horde/
│   ├── HordeManager.java         - Horde lifecycle, migration, spawning
│   └── WanderingHorde.java       - Data model for one wandering horde
├── events/
│   ├── EntityEventHandler.java   - Death events → density/infestation changes
│   ├── SpawnEventHandler.java    - Spawn events → extra zombies in infested chunks
│   └── WorldEventHandler.java    - Server tick → drives horde system
├── registry/
│   └── ModCapabilities.java      - Capability registration (extensible)
├── capability/
│   └── ChunkInfestationCapability.java - Stub for future use
└── util/
    └── DimUtil.java              - Dimension name helpers
```

---

## License
MIT — free to use, modify, and distribute.
