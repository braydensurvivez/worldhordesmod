package com.worldhordes.mod.horde;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.data.InfestationZone;
import com.worldhordes.mod.data.InfestationZoneRegistry;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class HordeManager {

    private static final List<WanderingHorde> activeHordes = new CopyOnWriteArrayList<>();
    private static MinecraftServer server;
    private static long lastHordeSpawnTick    = 0;
    private static long lastHordeMigrationTick = 0;
    private static long lastInfestSpawnTick   = 0;

    private static final String SAVE_FILE = "worldhordes_hordes.dat";
    private static final Random RAND = new Random();

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        load();
    }

    public static List<WanderingHorde> getActiveHordes() { return Collections.unmodifiableList(activeHordes); }
    public static MinecraftServer getServer() { return server; }

    // -------------------------------------------------------------------------
    // Main tick
    // -------------------------------------------------------------------------

    public static void tick(long gameTick) {
        HordeDensityManager.tick();
        InfestationData.tick();

        int spawnInterval = WorldHordesConfig.COMMON.hordeSpawnIntervalTicks.get();
        if (gameTick - lastHordeSpawnTick >= spawnInterval) {
            lastHordeSpawnTick = gameTick;
            trySpawnHorde();
        }

        int moveInterval = WorldHordesConfig.COMMON.hordeMoveCooldownTicks.get();
        if (gameTick - lastHordeMigrationTick >= moveInterval) {
            lastHordeMigrationTick = gameTick;
            tickHordeMigration();
        }

        int pulseInterval = WorldHordesConfig.COMMON.infestationChunkSpawnPulseTicks.get();
        if (gameTick - lastInfestSpawnTick >= pulseInterval) {
            lastInfestSpawnTick = gameTick;
            tickInfestationSpawns();
        }

        activeHordes.removeIf(h -> {
            if (h.isDepleted()) {
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} depleted and removed.", h.getId().toString().substring(0,8));
                return true;
            }
            return false;
        });
    }

    // -------------------------------------------------------------------------
    // Horde spawning
    // -------------------------------------------------------------------------

    private static void trySpawnHorde() {
        int maxHordes = WorldHordesConfig.COMMON.maxActiveHordes.get();
        if (activeHordes.size() >= maxHordes) return;
        if (!HordeDensityManager.isAboveHordeThreshold()) return;

        ServerLevel overworld = server.getLevel(Level.OVERWORLD);
        if (overworld == null) return;
        List<net.minecraft.world.entity.player.Player> players = new ArrayList<>(overworld.players());
        if (players.isEmpty()) return;

        net.minecraft.world.entity.player.Player player = players.get(RAND.nextInt(players.size()));
        BlockPos playerPos = player.blockPosition();

        int offsetX = (80 + RAND.nextInt(70)) * (RAND.nextBoolean() ? 1 : -1);
        int offsetZ = (80 + RAND.nextInt(70)) * (RAND.nextBoolean() ? 1 : -1);
        int spawnChunkX = (playerPos.getX() >> 4) + (offsetX / 16);
        int spawnChunkZ = (playerPos.getZ() >> 4) + (offsetZ / 16);

        if (!InfestationData.isRegionDistanceValid(DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ)) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug("[WorldHordes] Horde spawn rejected — too close to existing infested region.");
            }
            return;
        }

        int minSize = WorldHordesConfig.COMMON.hordeMinSize.get();
        int maxSize = WorldHordesConfig.COMMON.hordeMaxSize.get();
        int size    = minSize + RAND.nextInt(Math.max(1, maxSize - minSize));

        int density   = HordeDensityManager.getDensity();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        float densityScale = Math.min(3.0f, (float) density / threshold);
        size = (int)(size * densityScale);
        size = Math.max(minSize, Math.min(size, maxSize));

        WanderingHorde horde = new WanderingHorde(DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ, size);
        activeHordes.add(horde);

        // Seed the zone-based infestation (Core + Ring layout)
        InfestationZone zone = InfestationData.seedInfestationRegion(
                DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ,
                WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get());

        if (zone != null) {
            // Distribute horde reserves across core chunks, respecting core population limit
            int coreLimit = WorldHordesConfig.COMMON.coreHordePopulationLimit.get();
            int perCore = Math.min(size, coreLimit);
            for (int[] chunk : zone.getCoreChunks()) {
                InfestationData.getOrCreate(DimUtil.OVERWORLD_DIM, chunk[0], chunk[1])
                        .addToReserve(perCore);
            }
            // Overflow into ring
            int outerLimit = WorldHordesConfig.COMMON.outerRingHordePopulationLimit.get();
            int overflow = Math.max(0, size - (perCore * 4));
            if (overflow > 0) {
                int perRing = Math.min(overflow / 12 + 1, outerLimit);
                for (int[] chunk : zone.getOuterRingChunks()) {
                    InfestationData.getOrCreate(DimUtil.OVERWORLD_DIM, chunk[0], chunk[1])
                            .addToReserve(perRing);
                }
            }
        } else {
            // Fallback if zone creation was rejected
            InfestationData.getOrCreate(DimUtil.OVERWORLD_DIM, spawnChunkX, spawnChunkZ).addToReserve(size);
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Spawned {} [size={}] at chunk ({},{}). Active hordes: {}",
                horde, size, spawnChunkX, spawnChunkZ, activeHordes.size());
    }

    // -------------------------------------------------------------------------
    // Horde migration
    // -------------------------------------------------------------------------

    private static void tickHordeMigration() {
        int chunksPerMove  = WorldHordesConfig.COMMON.hordeChunksPerMove.get();
        double settleChance = WorldHordesConfig.COMMON.hordeEnterInfestedChunkChance.get();

        for (WanderingHorde horde : activeHordes) {
            if (horde.isSettled()) {
                InfestationData.addInfestation(horde.getDimension(), horde.getChunkX(), horde.getChunkZ(), 3);
                if (RAND.nextInt(20) == 0) {
                    horde.setSettled(false);
                    WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} moving again from ({},{})",
                            horde.getId().toString().substring(0,8), horde.getChunkX(), horde.getChunkZ());
                }
                continue;
            }

            int prevCx = horde.getChunkX(), prevCz = horde.getChunkZ();
            ChunkInfestationLevel prevInf = InfestationData.getOrCreate(horde.getDimension(), prevCx, prevCz);
            int carryReserve = prevInf.getZombieReserve();
            InfestationData.addInfestation(horde.getDimension(), prevCx, prevCz,
                    WorldHordesConfig.COMMON.hordeZombiesLeftBehindOnExit.get());
            prevInf.removeFromReserve(carryReserve);

            int[] next = horde.nextChunkPosition(chunksPerMove);
            int nx = next[0], nz = next[1];
            horde.setChunkX(nx); horde.setChunkZ(nz); horde.incrementSteps();

            InfestationData.addInfestation(horde.getDimension(), nx, nz,
                    WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get());
            ChunkInfestationLevel newInf = InfestationData.getOrCreate(horde.getDimension(), nx, nz);

            // Respect population limit for the chunk's role
            InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(horde.getDimension(), nx, nz);
            int limit = (role == InfestationZone.ZoneRole.CORE)
                    ? WorldHordesConfig.COMMON.coreHordePopulationLimit.get()
                    : WorldHordesConfig.COMMON.outerRingHordePopulationLimit.get();
            int toAdd = Math.min(carryReserve, Math.max(0, limit - newInf.getZombieReserve()));
            newInf.addToReserve(toAdd);

            int existingInfest = InfestationData.getLevel(horde.getDimension(), nx, nz);
            if (existingInfest >= WorldHordesConfig.COMMON.infestationTier2.get()
                    && RAND.nextDouble() < settleChance) {
                horde.setSettled(true);
                newInf.setHasActiveHorde(true);
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} settled in heavily infested chunk ({},{})",
                        horde.getId().toString().substring(0,8), nx, nz);
            }

            if (horde.hasExhausted()) {
                if (RAND.nextBoolean()) { horde.setSettled(true); newInf.setHasActiveHorde(true); }
                else { horde.setSize(0); }
            }

            spawnHordeZombiesNearPlayer(horde);
        }
    }

    // -------------------------------------------------------------------------
    // Infested chunk spawn pulses — Core spawns more than Outer Ring
    // -------------------------------------------------------------------------

    private static void tickInfestationSpawns() {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;

        int minDist = WorldHordesConfig.COMMON.infestationSpawnMinDistFromPlayer.get();
        int maxDist = WorldHordesConfig.COMMON.infestationSpawnMaxDistFromPlayer.get();
        int coreMax  = WorldHordesConfig.COMMON.coreSpawnPerPulse.get();
        int outerMax = WorldHordesConfig.COMMON.outerRingSpawnPerPulse.get();
        // Legacy fallback for non-zoned chunks
        int regionRadius = WorldHordesConfig.COMMON.infestationRegionRadius.get();

        for (net.minecraft.world.entity.player.Player player : level.players()) {
            BlockPos playerPos = player.blockPosition();
            int playerCx = playerPos.getX() >> 4;
            int playerCz = playerPos.getZ() >> 4;

            for (int dx = -regionRadius; dx <= regionRadius; dx++) {
                for (int dz = -regionRadius; dz <= regionRadius; dz++) {
                    int cx = playerCx + dx;
                    int cz = playerCz + dz;

                    if (!level.hasChunk(cx, cz)) continue;

                    ChunkInfestationLevel inf = InfestationData.get(DimUtil.OVERWORLD_DIM, cx, cz);
                    if (!inf.isInfested() || inf.getZombieReserve() <= 0) continue;

                    // Determine spawn cap based on zone role
                    InfestationZone.ZoneRole role = InfestationZoneRegistry.getRoleOf(DimUtil.OVERWORLD_DIM, cx, cz);
                    int maxPerPulse;
                    if (role == InfestationZone.ZoneRole.CORE) {
                        maxPerPulse = coreMax;
                    } else if (role == InfestationZone.ZoneRole.OUTER_RING) {
                        maxPerPulse = outerMax;
                    } else {
                        // Not in any zone — use a mid-range default
                        maxPerPulse = Math.max(1, (coreMax + outerMax) / 2);
                    }

                    int toSpawn = Math.min(RAND.nextInt(maxPerPulse + 1) + 1, inf.getZombieReserve());
                    int spawned = 0;

                    for (int i = 0; i < toSpawn; i++) {
                        double angle = RAND.nextDouble() * Math.PI * 2;
                        double dist  = minDist + RAND.nextDouble() * (maxDist - minDist);
                        int spawnX   = (int)(playerPos.getX() + Math.cos(angle) * dist);
                        int spawnZ   = (int)(playerPos.getZ() + Math.sin(angle) * dist);
                        int spawnY   = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawnX, spawnZ);
                        BlockPos spawnPos = new BlockPos(spawnX, spawnY, spawnZ);

                        if (isValidSpawnPos(level, spawnPos)) {
                            Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                            zombie.setPos(spawnX + 0.5, spawnY, spawnZ + 0.5);
                            zombie.getPersistentData().putInt("worldhordes_src_cx", cx);
                            zombie.getPersistentData().putInt("worldhordes_src_cz", cz);
                            zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                            zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                                    MobSpawnType.MOB_SUMMONED, null, null);
                            level.addFreshEntity(zombie);
                            spawned++;
                        }
                    }

                    if (spawned > 0) {
                        InfestationData.getOrCreate(DimUtil.OVERWORLD_DIM, cx, cz).removeFromReserve(spawned);
                    }
                }
            }
        }
    }

    /** Returns the spawn role label for a chunk (used in debug / event handler). */
    public static InfestationZone.ZoneRole getChunkRole(String dim, int cx, int cz) {
        return InfestationZoneRegistry.getRoleOf(dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Horde encounter spawns
    // -------------------------------------------------------------------------

    private static void spawnHordeZombiesNearPlayer(WanderingHorde horde) {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;
        int minDist = WorldHordesConfig.COMMON.infestationSpawnMinDistFromPlayer.get();
        int maxDist = WorldHordesConfig.COMMON.infestationSpawnMaxDistFromPlayer.get();

        for (net.minecraft.world.entity.player.Player player : level.players()) {
            BlockPos pos = player.blockPosition();
            int pCx = pos.getX() >> 4, pCz = pos.getZ() >> 4;
            int dx = Math.abs(pCx - horde.getChunkX()), dz = Math.abs(pCz - horde.getChunkZ());
            if (dx <= 8 && dz <= 8) {
                int waveSize = Math.min(horde.getSize(), 3 + RAND.nextInt(5));
                int spawned = 0;
                for (int i = 0; i < waveSize; i++) {
                    double angle = RAND.nextDouble() * Math.PI * 2;
                    double dist  = minDist + RAND.nextDouble() * (maxDist - minDist);
                    int spawnX   = (int)(pos.getX() + Math.cos(angle) * dist);
                    int spawnZ   = (int)(pos.getZ() + Math.sin(angle) * dist);
                    int spawnY   = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawnX, spawnZ);
                    BlockPos spawnPos = new BlockPos(spawnX, spawnY, spawnZ);
                    if (isValidSpawnPos(level, spawnPos)) {
                        Zombie zombie = new Zombie(EntityType.ZOMBIE, level);
                        zombie.setPos(spawnX + 0.5, spawnY, spawnZ + 0.5);
                        zombie.getPersistentData().putInt("worldhordes_src_cx", horde.getChunkX());
                        zombie.getPersistentData().putInt("worldhordes_src_cz", horde.getChunkZ());
                        zombie.getPersistentData().putBoolean("worldhordes_infest_spawn", true);
                        zombie.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos),
                                MobSpawnType.MOB_SUMMONED, null, null);
                        level.addFreshEntity(zombie);
                        spawned++;
                    }
                }
                horde.shrink(spawned);
                WorldHordesMod.LOGGER.info("[WorldHordes] Horde {} encountered player — deployed {} zombies. Remaining: {}",
                        horde.getId().toString().substring(0,8), spawned, horde.getSize());
                break;
            }
        }
    }

    private static boolean isValidSpawnPos(ServerLevel level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(pos).isAir()
                && level.getBlockState(pos.above()).isAir()
                && level.getBlockState(below).isCollisionShapeFullBlock(level, below);
    }

    // -------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------

    public static void onInfestZombieUntrack(Zombie zombie) {
        if (!zombie.getPersistentData().getBoolean("worldhordes_infest_spawn")) return;
        int cx = zombie.getPersistentData().getInt("worldhordes_src_cx");
        int cz = zombie.getPersistentData().getInt("worldhordes_src_cz");
        InfestationData.getOrCreate(DimUtil.OVERWORLD_DIM, cx, cz).addToReserve(1);
        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Infest zombie returned to reserve at ({},{}).", cx, cz);
        }
    }

    public static void forceSpawnHorde(String dim, int cx, int cz, int size) {
        WanderingHorde horde = new WanderingHorde(dim, cx, cz, size);
        activeHordes.add(horde);
        InfestationZone zone = InfestationData.seedInfestationRegion(dim, cx, cz,
                WorldHordesConfig.COMMON.hordeInfestOnArrivalAmount.get());
        if (zone != null) {
            int perCore = Math.min(size, WorldHordesConfig.COMMON.coreHordePopulationLimit.get());
            for (int[] chunk : zone.getCoreChunks()) {
                InfestationData.getOrCreate(dim, chunk[0], chunk[1]).addToReserve(perCore);
            }
        } else {
            InfestationData.getOrCreate(dim, cx, cz).addToReserve(size);
        }
        WorldHordesMod.LOGGER.info("[WorldHordes] Force-spawned horde {} [size={}] at chunk ({},{}).",
                horde.getId().toString().substring(0,8), size, cx, cz);
    }

    public static int clearAllHordes() {
        int count = activeHordes.size();
        activeHordes.clear();
        WorldHordesMod.LOGGER.info("[WorldHordes] Cleared {} active hordes via debug command.", count);
        return count;
    }

    public static void onZombieKilledInChunk(String dim, int cx, int cz) {
        for (WanderingHorde horde : activeHordes) {
            if (horde.isSettled() && horde.getDimension().equals(dim)
                    && horde.getChunkX() == cx && horde.getChunkZ() == cz) {
                horde.shrink(1);
                if (horde.isDepleted()) {
                    InfestationData.getOrCreate(dim, cx, cz).setHasActiveHorde(false);
                    WorldHordesMod.LOGGER.info("[WorldHordes] Settled horde {} wiped out at ({},{})",
                            horde.getId().toString().substring(0,8), cx, cz);
                }
            }
        }
    }

    /**
     * Called when infestation in a chunk reaches zero from player kills.
     * Marks chunk cleared and removes all blood decals in the zone.
     */
    public static void onChunkFullyCleared(ServerLevel serverLevel, String dim, int cx, int cz) {
        InfestationData.markChunkCleared(dim, cx, cz);
        InfestationData.removeBloodDecalsInRegion(serverLevel, dim, cx, cz);
    }

    // -------------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(activeHordes.size());
            for (WanderingHorde h : activeHordes) {
                out.writeUTF(h.getId().toString());
                out.writeUTF(h.getDimension());
                out.writeInt(h.getChunkX());
                out.writeInt(h.getChunkZ());
                out.writeInt(h.getSize());
                out.writeInt(h.getTargetChunkX());
                out.writeInt(h.getTargetChunkZ());
                out.writeLong(h.getLastMoveTick());
                out.writeBoolean(h.isSettled());
                out.writeInt(h.getWanderDirection());
                out.writeInt(h.getStepsTaken());
                out.writeInt(h.getMaxSteps());
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved {} active hordes.", activeHordes.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save horde data", e);
        }
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int count = in.readInt();
            for (int i = 0; i < count; i++) {
                UUID id = UUID.fromString(in.readUTF());
                String dim = in.readUTF();
                int cx = in.readInt(), cz = in.readInt(), size = in.readInt();
                int tx = in.readInt(), tz = in.readInt();
                long lastMove = in.readLong();
                boolean settled = in.readBoolean();
                int dir = in.readInt(), steps = in.readInt(), maxSteps = in.readInt();
                activeHordes.add(new WanderingHorde(id, dim, cx, cz, size, tx, tz, lastMove, settled, dir, steps, maxSteps));
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded {} active hordes.", activeHordes.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load horde data", e);
        }
    }
}
