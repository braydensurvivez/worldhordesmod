package com.worldhordes.mod.events;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.horde.HordeManager;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class WorldEventHandler {

    private static long serverTick = 0;

    /**
     * Tracks which players were already warned this session (UUID → last warn tick).
     * Warnings are sent once when the player first enters detection range, then
     * suppressed until they leave and re-enter the area.
     */
    private static final Map<UUID, Long> lastWarningTick = new HashMap<>();
    /**
     * How many ticks between repeat warnings for the same player still inside range.
     * Default: 6000 ticks = 5 minutes.
     */
    private static final long WARNING_COOLDOWN_TICKS = 6000L;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        serverTick++;

        int updateInterval = WorldHordesConfig.COMMON.ticksPerInfestationUpdate.get();
        if (serverTick % updateInterval == 0) {
            HordeManager.tick(serverTick);
        }

        // Player proximity warnings — checked every 2 seconds (40 ticks)
        if (serverTick % 40 == 0) {
            tickPlayerWarnings();
        }
    }

    /**
     * Sends a warning to any player who enters an infested area.
     * The warning fires once on entry, then respects WARNING_COOLDOWN_TICKS before repeating.
     */
    private void tickPlayerWarnings() {
        int warningRadius = WorldHordesConfig.COMMON.infestationWarningDetectionChunks.get();
        if (warningRadius <= 0) return;

        for (net.minecraft.server.MinecraftServer server : getServers()) {
            ServerLevel overworld = server.getLevel(Level.OVERWORLD);
            if (overworld == null) continue;
            String dim = DimUtil.OVERWORLD_DIM;

            for (net.minecraft.world.entity.player.Player rawPlayer : overworld.players()) {
                if (!(rawPlayer instanceof ServerPlayer player)) continue;

                UUID uuid = player.getUUID();
                BlockPos pos = player.blockPosition();
                int playerCx = pos.getX() >> 4;
                int playerCz = pos.getZ() >> 4;

                int[] nearest = InfestationData.getNearestInfestedRegionCentre(
                        dim, playerCx, playerCz, warningRadius);

                if (nearest != null) {
                    long lastWarn = lastWarningTick.getOrDefault(uuid, -WARNING_COOLDOWN_TICKS);
                    if (serverTick - lastWarn >= WARNING_COOLDOWN_TICKS) {
                        lastWarningTick.put(uuid, serverTick);
                        // Distance in chunks for context
                        int dist = Math.max(Math.abs(playerCx - nearest[0]), Math.abs(playerCz - nearest[1]));
                        player.sendSystemMessage(Component.literal(
                                "§4⚠ You are entering an infested area! "
                                + "Zombies are nearby (" + dist + " chunk" + (dist == 1 ? "" : "s") + " away). Be careful!"));
                    }
                } else {
                    // Player left the danger zone — reset so they get a fresh warning on next entry
                    lastWarningTick.remove(uuid);
                }
            }
        }
    }

    /** Helper to access all running server instances (in practice always one). */
    private Iterable<net.minecraft.server.MinecraftServer> getServers() {
        net.minecraft.server.MinecraftServer s = HordeManager.getServer();
        return s != null ? java.util.List.of(s) : java.util.List.of();
    }

    @SubscribeEvent
    public void onLevelLoad(LevelEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel level) {
            if (level.dimension() == Level.OVERWORLD) {
                WorldHordesMod.LOGGER.info("[WorldHordes] Overworld loaded - zombie ecosystem is active.");
            }
        }
    }

    /**
     * Fires when an entity leaves the chunk tracking system (i.e. despawns naturally
     * or is unloaded far from players). If it's a tagged infest-zombie, return it
     * to its source chunk's reserve.
     */
    @SubscribeEvent
    public void onEntityLeaveWorld(EntityLeaveLevelEvent event) {
        if (!(event.getEntity() instanceof Zombie zombie)) return;
        if (!zombie.getPersistentData().getBoolean("worldhordes_infest_spawn")) return;
        if (!zombie.isAlive()) return;
        HordeManager.onInfestZombieUntrack(zombie);
    }
}
