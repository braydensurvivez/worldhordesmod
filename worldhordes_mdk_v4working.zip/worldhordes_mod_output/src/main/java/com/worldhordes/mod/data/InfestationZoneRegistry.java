package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks all active InfestationZones and provides lookup of a chunk's role
 * (Core, Outer Ring, or None) within any zone.
 *
 * Zone keys are stored as "dim:originX:originZ" where originX/Z is the top-left core chunk.
 */
public class InfestationZoneRegistry {

    /** key: "dim:originX:originZ" → zone */
    private static final Map<String, InfestationZone> activeZones = new ConcurrentHashMap<>();
    /** Reverse lookup: "dim:cx:cz" → zone key (for fast role queries) */
    private static final Map<String, String> chunkToZoneKey = new ConcurrentHashMap<>();

    private static String zoneKey(String dim, InfestationZone zone) {
        return dim + ":" + zone.getOriginX() + ":" + zone.getOriginZ();
    }

    private static String chunkKey(String dim, int cx, int cz) {
        return dim + ":" + cx + ":" + cz;
    }

    /**
     * Registers a new InfestationZone centred near (centreX, centreZ) in the given dimension.
     * Seeds all 16 chunks with the appropriate infestation amounts.
     * Returns the created zone, or null if placement is invalid (too close to existing zone).
     */
    public static InfestationZone createZone(String dim, int centreX, int centreZ) {
        InfestationZone zone = InfestationZone.centredAt(centreX, centreZ);

        // Distance check
        int minDist = WorldHordesConfig.COMMON.infestationRegionMinDistance.get();
        if (minDist > 0 && !isDistanceValid(dim, zone, minDist)) {
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug("[WorldHordes] Zone creation rejected at ({},{}) — too close to existing zone.", centreX, centreZ);
            }
            return null;
        }

        String key = zoneKey(dim, zone);
        activeZones.put(key, zone);

        // Seed Core chunks
        int coreInfest = WorldHordesConfig.COMMON.coreInitialInfestation.get();
        for (int[] chunk : zone.getCoreChunks()) {
            InfestationData.getOrCreate(dim, chunk[0], chunk[1]).addInfestation(coreInfest);
            chunkToZoneKey.put(chunkKey(dim, chunk[0], chunk[1]), key);
        }

        // Seed Outer Ring chunks
        int ringInfest = WorldHordesConfig.COMMON.outerRingInitialInfestation.get();
        for (int[] chunk : zone.getOuterRingChunks()) {
            InfestationData.getOrCreate(dim, chunk[0], chunk[1]).addInfestation(ringInfest);
            chunkToZoneKey.put(chunkKey(dim, chunk[0], chunk[1]), key);
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Created {} in dim={}", zone, dim);
        return zone;
    }

    /**
     * Returns the role of chunk (cx, cz) across all active zones in the given dimension.
     */
    public static InfestationZone.ZoneRole getRoleOf(String dim, int cx, int cz) {
        String key = chunkToZoneKey.get(chunkKey(dim, cx, cz));
        if (key == null) return InfestationZone.ZoneRole.NONE;
        InfestationZone zone = activeZones.get(key);
        if (zone == null) return InfestationZone.ZoneRole.NONE;
        return zone.roleOf(cx, cz);
    }

    /**
     * Returns the InfestationZone that contains chunk (cx, cz), or null.
     */
    public static InfestationZone getZoneFor(String dim, int cx, int cz) {
        String key = chunkToZoneKey.get(chunkKey(dim, cx, cz));
        if (key == null) return null;
        return activeZones.get(key);
    }

    /** Returns true if chunk (cx, cz) belongs to any zone's core. */
    public static boolean isCore(String dim, int cx, int cz) {
        return getRoleOf(dim, cx, cz) == InfestationZone.ZoneRole.CORE;
    }

    /** Returns true if chunk (cx, cz) belongs to any zone's outer ring. */
    public static boolean isOuterRing(String dim, int cx, int cz) {
        return getRoleOf(dim, cx, cz) == InfestationZone.ZoneRole.OUTER_RING;
    }

    /** Returns true if chunk is in any active zone. */
    public static boolean isInAnyZone(String dim, int cx, int cz) {
        return getRoleOf(dim, cx, cz) != InfestationZone.ZoneRole.NONE;
    }

    /**
     * Removes a zone and all its chunk mappings. Called when an infestation is fully cleared.
     */
    public static void removeZone(String dim, int cx, int cz) {
        String key = chunkToZoneKey.get(chunkKey(dim, cx, cz));
        if (key == null) return;
        InfestationZone zone = activeZones.remove(key);
        if (zone == null) return;
        for (int[] chunk : zone.getAllChunks()) {
            chunkToZoneKey.remove(chunkKey(dim, chunk[0], chunk[1]));
        }
        WorldHordesMod.LOGGER.info("[WorldHordes] Removed zone {} from dim={}", zone, dim);
    }

    /**
     * Finds the nearest zone centre to (cx, cz) within searchRadius chunks, or null.
     */
    public static int[] getNearestZoneCentre(String dim, int cx, int cz, int searchRadius) {
        int bestDist = Integer.MAX_VALUE;
        int[] best = null;
        for (Map.Entry<String, InfestationZone> entry : activeZones.entrySet()) {
            if (!entry.getKey().startsWith(dim + ":")) continue;
            InfestationZone zone = entry.getValue();
            int ecx = zone.getZoneCentreX();
            int ecz = zone.getZoneCentreZ();
            int dist = Math.max(Math.abs(cx - ecx), Math.abs(cz - ecz));
            if (dist <= searchRadius && dist < bestDist) {
                bestDist = dist;
                best = new int[]{ecx, ecz};
            }
        }
        return best;
    }

    /**
     * Returns all active zone centres in a dimension as a list of int[]{cx,cz}.
     */
    public static List<int[]> getAllZoneCentres(String dim) {
        List<int[]> result = new ArrayList<>();
        for (Map.Entry<String, InfestationZone> entry : activeZones.entrySet()) {
            if (!entry.getKey().startsWith(dim + ":")) continue;
            InfestationZone z = entry.getValue();
            result.add(new int[]{z.getZoneCentreX(), z.getZoneCentreZ()});
        }
        return result;
    }

    /** Returns all active zones across all dimensions. */
    public static Collection<InfestationZone> getAllZones() {
        return Collections.unmodifiableCollection(activeZones.values());
    }

    public static int getZoneCount() {
        return activeZones.size();
    }

    /** Clear all zone data (e.g. on server shutdown). */
    public static void clear() {
        activeZones.clear();
        chunkToZoneKey.clear();
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    private static boolean isDistanceValid(String dim, InfestationZone candidate, int minDist) {
        int cx = candidate.getZoneCentreX();
        int cz = candidate.getZoneCentreZ();
        for (Map.Entry<String, InfestationZone> entry : activeZones.entrySet()) {
            if (!entry.getKey().startsWith(dim + ":")) continue;
            InfestationZone existing = entry.getValue();
            int dist = Math.max(Math.abs(cx - existing.getZoneCentreX()),
                                Math.abs(cz - existing.getZoneCentreZ()));
            if (dist < minDist) return false;
        }
        return true;
    }
}
