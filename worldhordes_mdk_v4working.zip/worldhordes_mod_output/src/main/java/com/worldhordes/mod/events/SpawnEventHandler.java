package com.worldhordes.mod.events;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.util.DimUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Random;

public class SpawnEventHandler {

    private static final Random RAND = new Random();

    @SubscribeEvent
    public void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn event) {
        if (!(event.getEntity() instanceof Zombie zombie)) return;
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        MobSpawnType reason = event.getSpawnType();
        if (reason == MobSpawnType.NATURAL || reason == MobSpawnType.CHUNK_GENERATION) {
            HordeDensityManager.addDensity(WorldHordesConfig.COMMON.densityPerZombieSpawn.get());

            String dim = DimUtil.getDim(serverLevel);
            BlockPos pos = zombie.blockPosition();
            int cx = pos.getX() >> 4;
            int cz = pos.getZ() >> 4;

            // A natural spawn may seed a NEW infestation only when minimum distance is respected.
            // If the chunk is already infested we always add growth.
            ChunkInfestationLevel existing = InfestationData.get(dim, cx, cz);
            boolean alreadyInfested = existing.isInfested() || existing.getLevel() > 0;

            if (alreadyInfested) {
                // Growth within an established infestation — always allowed
                InfestationData.addInfestationFromZombie(dim, cx, cz,
                        WorldHordesConfig.COMMON.infestationGrowthPerZombie.get());
            } else {
                // Brand-new location: enforce minimum distance before seeding
                if (InfestationData.isRegionDistanceValid(dim, cx, cz)) {
                    // Seed the full starting area (default 8×8 chunks) around this spawn point
                    int seedAmount = WorldHordesConfig.COMMON.infestationGrowthPerZombie.get();
                    InfestationData.seedInfestationRegion(dim, cx, cz, seedAmount);
                    WorldHordesMod.LOGGER.info(
                            "[WorldHordes] Natural zombie at ({},{}) seeded new infestation region.", cx, cz);
                } else {
                    // Too close to an existing infestation — contribute to the nearest one instead
                    InfestationData.addInfestationFromZombie(dim, cx, cz,
                            WorldHordesConfig.COMMON.infestationGrowthPerZombie.get());
                    if (WorldHordesConfig.COMMON.debugMode.get()) {
                        WorldHordesMod.LOGGER.debug(
                                "[WorldHordes] Natural zombie at ({},{}) too close to existing infestation — skipped new region.", cx, cz);
                    }
                }
            }

            ChunkInfestationLevel infest = InfestationData.get(dim, cx, cz);
            if (infest.isInfested()) {
                spawnExtraZombies(serverLevel, pos, infest);
            }
        }
    }

    private void spawnExtraZombies(ServerLevel level, BlockPos origin, ChunkInfestationLevel infest) {
        int extraCount = infest.getExtraZombies();
        int groupBonus = infest.getGroupSizeBonus();
        int totalExtra = extraCount + (groupBonus > 0 ? RAND.nextInt(groupBonus + 1) : 0);
        if (totalExtra <= 0) return;

        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Infested chunk (tier {}) spawning +{} extra zombies near {}",
                    infest.getTier(), totalExtra, origin);
        }

        for (int i = 0; i < totalExtra; i++) {
            int dx = RAND.nextInt(17) - 8;
            int dz = RAND.nextInt(17) - 8;
            BlockPos spawnPos = findSafeSpawn(level, origin.offset(dx, 0, dz));
            if (spawnPos == null) continue;

            Zombie z = new Zombie(EntityType.ZOMBIE, level);
            z.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
            z.finalizeSpawn(level, level.getCurrentDifficultyAt(spawnPos), MobSpawnType.MOB_SUMMONED, null, null);
            level.addFreshEntity(z);

            HordeDensityManager.addDensity(WorldHordesConfig.COMMON.densityPerZombieSpawn.get());
        }
    }

    private BlockPos findSafeSpawn(ServerLevel level, BlockPos base) {
        for (int dy = 5; dy >= -5; dy--) {
            BlockPos pos = base.above(dy);
            BlockPos below = pos.below();
            if (level.getBlockState(pos).isAir()
                    && level.getBlockState(pos.above()).isAir()
                    && level.getBlockState(below).isCollisionShapeFullBlock(level, below)) {
                return pos;
            }
        }
        return null;
    }
}
