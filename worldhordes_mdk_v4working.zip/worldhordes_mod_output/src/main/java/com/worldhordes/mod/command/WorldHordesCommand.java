package com.worldhordes.mod.command;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import com.worldhordes.mod.data.ChunkInfestationLevel;
import com.worldhordes.mod.data.HordeDensityManager;
import com.worldhordes.mod.data.InfestationData;
import com.worldhordes.mod.horde.HordeManager;
import com.worldhordes.mod.horde.WanderingHorde;
import com.worldhordes.mod.util.DimUtil;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * /worldhordes command tree:
 *
 *   /worldhordes status
 *   /worldhordes density [set|add <n>]
 *   /worldhordes infest [set|add|clear|list <n>]
 *   /worldhordes horde list
 *   /worldhordes horde spawn
 *   /worldhordes horde clear
 *   /worldhordes horde tp <index>          — TP to a wandering horde by list index
 *   /worldhordes debug [toggle|overlay]
 *   /worldhordes help
 */
public class WorldHordesCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("worldhordes")
            .requires(src -> src.hasPermission(2))

            .then(Commands.literal("status")
                .executes(WorldHordesCommand::cmdStatus))

            .then(Commands.literal("density")
                .executes(WorldHordesCommand::cmdDensityGet)
                .then(Commands.literal("set")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0))
                        .executes(WorldHordesCommand::cmdDensitySet)))
                .then(Commands.literal("add")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(-100000, 100000))
                        .executes(WorldHordesCommand::cmdDensityAdd))))

            .then(Commands.literal("infest")
                .executes(WorldHordesCommand::cmdInfestGet)
                .then(Commands.literal("set")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0))
                        .executes(WorldHordesCommand::cmdInfestSet)))
                .then(Commands.literal("add")
                    .then(Commands.argument("amount", IntegerArgumentType.integer(-100000, 100000))
                        .executes(WorldHordesCommand::cmdInfestAdd)))
                .then(Commands.literal("clear")
                    .executes(WorldHordesCommand::cmdInfestClear))
                .then(Commands.literal("list")
                    .executes(WorldHordesCommand::cmdInfestList)))

            .then(Commands.literal("horde")
                .then(Commands.literal("list")
                    .executes(WorldHordesCommand::cmdHordeList))
                .then(Commands.literal("spawn")
                    .executes(WorldHordesCommand::cmdHordeSpawn))
                .then(Commands.literal("clear")
                    .executes(WorldHordesCommand::cmdHordeClear))
                .then(Commands.literal("tp")
                    .then(Commands.argument("index", IntegerArgumentType.integer(1))
                        .executes(WorldHordesCommand::cmdHordeTp))))

            .then(Commands.literal("debug")
                .then(Commands.literal("toggle")
                    .executes(WorldHordesCommand::cmdDebugToggle))
                .then(Commands.literal("overlay")
                    .executes(WorldHordesCommand::cmdDebugOverlay)))

            .then(Commands.literal("help")
                .executes(WorldHordesCommand::cmdHelp))
        );
    }

    // =========================================================================
    //  STATUS
    // =========================================================================

    private static int cmdStatus(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ServerPlayer player = getPlayer(src);

        int density = HordeDensityManager.getDensity();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        int activeHordes = HordeManager.getActiveHordes().size();
        int infestCount = InfestationData.getAllEntries().size();

        send(src, "§6=== WorldHordes Status ===");
        send(src, "§eGlobal Density: §f" + density + " §7/ " + WorldHordesConfig.COMMON.maxGlobalDensity.get()
                + (density >= threshold ? " §c[HORDE THRESHOLD MET]" : ""));
        send(src, "§eActive Hordes: §f" + activeHordes + " §7/ " + WorldHordesConfig.COMMON.maxActiveHordes.get());
        send(src, "§eInfested Chunks: §f" + infestCount + "  §eActive Zones: §f"
                + com.worldhordes.mod.data.InfestationZoneRegistry.getZoneCount());

        if (player != null) {
            ServerLevel level = player.serverLevel();
            String dim = DimUtil.getDim(level);
            ChunkPos cp = new ChunkPos(player.blockPosition());
            ChunkInfestationLevel infest = InfestationData.get(dim, cp.x, cp.z);
            com.worldhordes.mod.data.InfestationZone.ZoneRole role =
                    com.worldhordes.mod.data.InfestationZoneRegistry.getRoleOf(dim, cp.x, cp.z);
            String roleLabel = switch (role) {
                case CORE       -> "§c[CORE ZONE]";
                case OUTER_RING -> "§6[OUTER RING]";
                default         -> "§7[no zone]";
            };
            send(src, "§eYour Chunk (" + cp.x + "," + cp.z + "): §f" + infest.getLevel()
                    + " §7[" + tierLabel(infest.getTier()) + "§7]"
                    + " " + roleLabel
                    + (infest.hasActiveHorde() ? " §c[ACTIVE HORDE]" : "")
                    + (infest.isCleared() ? " §a[CLEARED]" : "")
                    + " §7reserve=" + infest.getZombieReserve());
        }

        send(src, "§eDebug Mode: " + (WorldHordesConfig.COMMON.debugMode.get() ? "§aON" : "§cOFF"));
        return 1;
    }

    // =========================================================================
    //  DENSITY
    // =========================================================================

    private static int cmdDensityGet(CommandContext<CommandSourceStack> ctx) {
        int d = HordeDensityManager.getDensity();
        int max = WorldHordesConfig.COMMON.maxGlobalDensity.get();
        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        send(ctx.getSource(), "§6[Density] §fCurrent: §e" + d + " §7/ " + max
                + (d >= threshold ? " §c[ABOVE HORDE THRESHOLD " + threshold + "]" : " §7[threshold: " + threshold + "]"));
        return 1;
    }

    private static int cmdDensitySet(CommandContext<CommandSourceStack> ctx) {
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        int current = HordeDensityManager.getDensity();
        int delta = amount - current;
        HordeDensityManager.addDensity(delta);
        send(ctx.getSource(), "§6[Density] §fSet to §e" + HordeDensityManager.getDensity());
        return 1;
    }

    private static int cmdDensityAdd(CommandContext<CommandSourceStack> ctx) {
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        HordeDensityManager.addDensity(amount);
        send(ctx.getSource(), "§6[Density] §f" + (amount >= 0 ? "+" : "") + amount + " → §e" + HordeDensityManager.getDensity());
        return 1;
    }

    // =========================================================================
    //  INFEST
    // =========================================================================

    private static int cmdInfestGet(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        ChunkInfestationLevel infest = InfestationData.get(dim, cp.x, cp.z);

        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + "): "
                + "§e" + infest.getLevel() + " §7/ " + WorldHordesConfig.COMMON.infestationMaxLevel.get()
                + " " + tierLabel(infest.getTier())
                + (infest.hasActiveHorde() ? " §c[ACTIVE HORDE]" : "")
                + (infest.isCleared() ? " §a[CLEARED]" : "")
                + (infest.shouldSpread() ? " §d[SPREADING]" : "")
                + " §7reserve=§f" + infest.getZombieReserve());
        return 1;
    }

    private static int cmdInfestSet(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        InfestationData.getOrCreate(dim, cp.x, cp.z).setLevel(amount);
        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + ") set to §e" + amount
                + " " + tierLabel(InfestationData.get(dim, cp.x, cp.z).getTier()));
        return 1;
    }

    private static int cmdInfestAdd(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());

        if (amount >= 0) InfestationData.addInfestation(dim, cp.x, cp.z, amount);
        else InfestationData.removeInfestation(dim, cp.x, cp.z, -amount);

        int newLevel = InfestationData.get(dim, cp.x, cp.z).getLevel();
        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + ") "
                + (amount >= 0 ? "+" : "") + amount + " → §e" + newLevel
                + " " + tierLabel(InfestationData.get(dim, cp.x, cp.z).getTier()));
        return 1;
    }

    private static int cmdInfestClear(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        String dim = DimUtil.getDim(player.serverLevel());
        ChunkPos cp = new ChunkPos(player.blockPosition());
        InfestationData.markChunkCleared(dim, cp.x, cp.z);
        send(ctx.getSource(), "§6[Infest] §fChunk (" + cp.x + "," + cp.z + ") §acleared. §7Zombies must physically enter to re-infest.");
        return 1;
    }

    private static int cmdInfestList(CommandContext<CommandSourceStack> ctx) {
        var entries = InfestationData.getAllEntries();
        if (entries.isEmpty()) {
            send(ctx.getSource(), "§6[Infest] §fNo infested chunks.");
            return 1;
        }
        send(ctx.getSource(), "§6[Infest] §f" + entries.size() + " chunk(s):");
        int count = 0;
        for (Map.Entry<String, ChunkInfestationLevel> e : entries) {
            if (count++ >= 25) {
                send(ctx.getSource(), "§7  ... and " + (entries.size() - 25) + " more. Use debug overlay to see all.");
                break;
            }
            String key = e.getKey();
            ChunkInfestationLevel inf = e.getValue();
            String[] parts = key.split(":");
            String chunkInfo = parts.length >= 3 ? "(" + parts[parts.length-2] + "," + parts[parts.length-1] + ")" : key;
            String dim = parts.length >= 3 ? String.join(":", Arrays.copyOf(parts, parts.length-2)) : "?";
            send(ctx.getSource(), "  §7" + dim + " " + chunkInfo
                    + " §f→ §e" + inf.getLevel() + " " + tierLabel(inf.getTier())
                    + (inf.isCleared() ? " §a[CLEARED]" : "")
                    + (inf.hasActiveHorde() ? " §c[HORDE]" : "")
                    + (inf.shouldSpread() ? " §d[SPREAD]" : "")
                    + " §7res=" + inf.getZombieReserve());
        }
        return 1;
    }

    // =========================================================================
    //  HORDE
    // =========================================================================

    private static int cmdHordeList(CommandContext<CommandSourceStack> ctx) {
        List<WanderingHorde> hordes = HordeManager.getActiveHordes();
        if (hordes.isEmpty()) {
            send(ctx.getSource(), "§6[Horde] §fNo active hordes.");
            return 1;
        }
        send(ctx.getSource(), "§6[Horde] §f" + hordes.size() + " active horde(s):");
        int i = 1;
        for (WanderingHorde h : hordes) {
            int blockX = h.getChunkX() * 16 + 8;
            int blockZ = h.getChunkZ() * 16 + 8;
            send(ctx.getSource(), "  §e#" + i + " " + h.getId().toString().substring(0, 8)
                    + " §7dim=§f" + h.getDimension()
                    + " §7chunk=§f(" + h.getChunkX() + "," + h.getChunkZ() + ")"
                    + " §7≈§f(" + blockX + "," + blockZ + ")"
                    + " §7size=§f" + h.getSize()
                    + " §7steps=§f" + h.getStepsTaken() + "/" + h.getMaxSteps()
                    + (h.isSettled() ? " §a[SETTLED]" : " §b[WANDERING]"));
            i++;
        }
        send(ctx.getSource(), "§7Use §e/worldhordes horde tp <index>§7 to teleport to a horde.");
        return 1;
    }

    private static int cmdHordeSpawn(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        int threshold = WorldHordesConfig.COMMON.densityThresholdForHorde.get();
        if (HordeDensityManager.getDensity() < threshold) {
            HordeDensityManager.addDensity(threshold - HordeDensityManager.getDensity());
        }

        ChunkPos cp = new ChunkPos(player.blockPosition());
        java.util.Random rand = new java.util.Random();
        int offsetX = (10 + rand.nextInt(20)) * (rand.nextBoolean() ? 1 : -1);
        int offsetZ = (10 + rand.nextInt(20)) * (rand.nextBoolean() ? 1 : -1);
        int hcx = cp.x + offsetX;
        int hcz = cp.z + offsetZ;

        int minSize = WorldHordesConfig.COMMON.hordeMinSize.get();
        int maxSize = WorldHordesConfig.COMMON.hordeMaxSize.get();
        int size = minSize + rand.nextInt(Math.max(1, maxSize - minSize));

        HordeManager.forceSpawnHorde(DimUtil.getDim(player.serverLevel()), hcx, hcz, size);
        send(ctx.getSource(), "§6[Horde] §fForce-spawned horde [size=" + size + "] at chunk ("
                + hcx + "," + hcz + ") — §7approx §f"
                + (Math.abs(offsetX) * 16) + "§7 blocks " + (offsetX > 0 ? "east" : "west")
                + ", §f" + (Math.abs(offsetZ) * 16) + "§7 blocks " + (offsetZ > 0 ? "south" : "north")
                + ". §7Use §e/worldhordes horde list§7 then §e/worldhordes horde tp <index>§7 to go there.");
        return 1;
    }

    private static int cmdHordeClear(CommandContext<CommandSourceStack> ctx) {
        int count = HordeManager.clearAllHordes();
        send(ctx.getSource(), "§6[Horde] §fRemoved §e" + count + "§f active horde(s).");
        return 1;
    }

    /**
     * Teleport the executing player to a wandering horde by list index (1-based).
     * Finds a safe surface position above the horde's chunk centre.
     */
    private static int cmdHordeTp(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }

        int index = IntegerArgumentType.getInteger(ctx, "index");
        List<WanderingHorde> hordes = HordeManager.getActiveHordes();
        if (hordes.isEmpty()) {
            send(ctx.getSource(), "§c[Horde] No active hordes to teleport to.");
            return 0;
        }
        if (index < 1 || index > hordes.size()) {
            send(ctx.getSource(), "§c[Horde] Index out of range. Use 1-" + hordes.size() + ".");
            return 0;
        }

        WanderingHorde horde = hordes.get(index - 1);
        // Find a safe Y at the horde's chunk centre
        ServerLevel level = HordeManager.getServer().getLevel(Level.OVERWORLD);
        if (level == null) { send(ctx.getSource(), "§cCould not access overworld."); return 0; }

        int blockX = horde.getChunkX() * 16 + 8;
        int blockZ = horde.getChunkZ() * 16 + 8;
        int blockY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, blockX, blockZ) + 1;

        player.teleportTo(level, blockX + 0.5, blockY, blockZ + 0.5,
                player.getYRot(), player.getXRot());

        send(ctx.getSource(), "§6[Horde] §fTeleported to horde §e#" + index
                + " §f(" + horde.getId().toString().substring(0,8) + ")"
                + " at §e(" + blockX + ", " + blockY + ", " + blockZ + ")"
                + " — size §f" + horde.getSize()
                + (horde.isSettled() ? " §a[SETTLED]" : " §b[WANDERING]"));
        return 1;
    }

    // =========================================================================
    //  DEBUG
    // =========================================================================

    private static int cmdDebugToggle(CommandContext<CommandSourceStack> ctx) {
        boolean current = WorldHordesConfig.COMMON.debugMode.get();
        WorldHordesConfig.COMMON.debugMode.set(!current);
        send(ctx.getSource(), "§6[Debug] §fDebug mode: " + (!current ? "§aON" : "§cOFF"));
        return 1;
    }

    private static int cmdDebugOverlay(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = getPlayer(ctx.getSource());
        if (player == null) { send(ctx.getSource(), "§cMust be run by a player."); return 0; }
        send(ctx.getSource(), "§6[Debug] §fUse §eF3 + I§f in-game to toggle the chunk overlay.");
        return 1;
    }

    // =========================================================================
    //  HELP
    // =========================================================================

    private static int cmdHelp(CommandContext<CommandSourceStack> ctx) {
        send(ctx.getSource(), "§6=== WorldHordes Commands ===");
        send(ctx.getSource(), "§e/worldhordes status §7— Overview of density, hordes, your chunk");
        send(ctx.getSource(), "§e/worldhordes density §7— Show global horde density");
        send(ctx.getSource(), "§e/worldhordes density set <n> §7— Set density to n");
        send(ctx.getSource(), "§e/worldhordes density add <n> §7— Add n to density");
        send(ctx.getSource(), "§e/worldhordes infest §7— Show infestation of your current chunk");
        send(ctx.getSource(), "§e/worldhordes infest set <n> §7— Set current chunk infestation to n");
        send(ctx.getSource(), "§e/worldhordes infest add <n> §7— Add n infestation to your chunk");
        send(ctx.getSource(), "§e/worldhordes infest clear §7— Mark chunk as cleared (spread-immune)");
        send(ctx.getSource(), "§e/worldhordes infest list §7— List all infested/cleared chunks");
        send(ctx.getSource(), "§e/worldhordes horde list §7— List all active hordes with index & coords");
        send(ctx.getSource(), "§e/worldhordes horde spawn §7— Force spawn a horde near you");
        send(ctx.getSource(), "§e/worldhordes horde clear §7— Remove all active hordes");
        send(ctx.getSource(), "§e/worldhordes horde tp <index> §7— Teleport to a horde by list index");
        send(ctx.getSource(), "§e/worldhordes debug toggle §7— Toggle debug logging at runtime");
        send(ctx.getSource(), "§e/worldhordes debug overlay §7— Info on chunk overlay toggle (F3+I)");
        send(ctx.getSource(), "§e/worldhordes help §7— This message");
        return 1;
    }

    // =========================================================================
    //  HELPERS
    // =========================================================================

    private static void send(CommandSourceStack src, String msg) {
        src.sendSuccess(() -> Component.literal(msg), false);
    }

    private static ServerPlayer getPlayer(CommandSourceStack src) {
        try { return src.getPlayerOrException(); }
        catch (Exception e) { return null; }
    }

    private static String tierLabel(ChunkInfestationLevel.Tier tier) {
        return switch (tier) {
            case TIER1 -> "§a[T1]";
            case TIER2 -> "§6[T2]";
            case TIER3 -> "§c[T3]";
            default   -> "§7[NONE]";
        };
    }
}
