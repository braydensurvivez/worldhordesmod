package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class InfestationData {

    // Key: "dimension:chunkX:chunkZ"
    private static final Map<String, ChunkInfestationLevel> chunkData = new ConcurrentHashMap<>();
    private static MinecraftServer server;
    private static long lastSpreadTime  = 0;
    private static long lastDecayTime   = 0;
    private static long lastRegenTime   = 0;

    private static final String SAVE_FILE = "worldhordes_infestation.dat";

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        load();
        long now = System.currentTimeMillis();
        lastSpreadTime = now;
        lastDecayTime  = now;
        lastRegenTime  = now;
    }

    private static String key(String dim, int cx, int cz) {
        return dim + ":" + cx + ":" + cz;
    }

    public static ChunkInfestationLevel getOrCreate(String dim, int cx, int cz) {
        return chunkData.computeIfAbsent(key(dim, cx, cz), k -> new ChunkInfestationLevel());
    }

    public static ChunkInfestationLevel get(String dim, int cx, int cz) {
        return chunkData.getOrDefault(key(dim, cx, cz), new ChunkInfestationLevel());
    }

    /** Standard spread-based infestation add — respects cleared flag. */
    public static void addInfestation(String dim, int cx, int cz, int amount) {
        getOrCreate(dim, cx, cz).addInfestation(amount);
        HordeDensityManager.addDensity(amount / 10);
    }

    /**
     * Forced infestation from a zombie physically entering — bypasses cleared flag.
     * This is how cleared chunks can be re-infested.
     */
    public static void addInfestationFromZombie(String dim, int cx, int cz, int amount) {
        getOrCreate(dim, cx, cz).addInfestationForced(amount);
        HordeDensityManager.addDensity(amount / 10);
    }

    public static void removeInfestation(String dim, int cx, int cz, int amount) {
        String k = key(dim, cx, cz);
        ChunkInfestationLevel inf = chunkData.get(k);
        if (inf != null) {
            inf.removeInfestation(amount);
            if (inf.getLevel() <= 0 && !inf.isCleared()) {
                chunkData.remove(k);
            }
        }
    }

    /**
     * Mark a chunk as fully cleared by players.
     * Cleared chunks cannot re-infest from spread — only from zombies walking in.
     */
    public static void markChunkCleared(String dim, int cx, int cz) {
        ChunkInfestationLevel inf = getOrCreate(dim, cx, cz);
        inf.markCleared();
        WorldHordesMod.LOGGER.info("[WorldHordes] Chunk ({},{}) marked cleared.", cx, cz);
    }

    public static boolean isChunkCleared(String dim, int cx, int cz) {
        return chunkData.containsKey(key(dim, cx, cz)) && chunkData.get(key(dim, cx, cz)).isCleared();
    }

    public static int getLevel(String dim, int cx, int cz) {
        return get(dim, cx, cz).getLevel();
    }

    public static ChunkInfestationLevel.Tier getTier(String dim, int cx, int cz) {
        return get(dim, cx, cz).getTier();
    }

    /**
     * Seeds a new multi-chunk infestation zone centred on (cx, cz).
     * Uses the 4×4 Core+Ring layout. The zone is registered in InfestationZoneRegistry.
     *
     * @param dim    dimension key
     * @param cx     desired centre chunk X
     * @param cz     desired centre chunk Z
     * @param amount additional infestation points beyond the defaults (can be 0)
     */
    public static InfestationZone seedInfestationRegion(String dim, int cx, int cz, int amount) {
        InfestationZone zone = InfestationZoneRegistry.createZone(dim, cx, cz);
        if (zone == null) return null; // placement rejected

        // Additional seeding from the calling horde's arrival bonus
        if (amount > 0) {
            for (int[] chunk : zone.getCoreChunks()) {
                getOrCreate(dim, chunk[0], chunk[1]).addInfestation(amount);
            }
            int ringBonus = amount / 3; // ring gets a fraction of the arrival bonus
            for (int[] chunk : zone.getOuterRingChunks()) {
                getOrCreate(dim, chunk[0], chunk[1]).addInfestation(ringBonus);
            }
        }

        WorldHordesMod.LOGGER.info("[WorldHordes] Seeded infestation {} in dim={}", zone, dim);
        return zone;
    }

    /**
     * Removes all blood splatter decals tracked in an infestation zone centred on (cx, cz).
     * Called automatically when an infestation is fully cleared.
     */
    public static void removeBloodDecalsInRegion(net.minecraft.server.level.ServerLevel serverLevel,
                                                  String dim, int cx, int cz) {
        InfestationZone zone = InfestationZoneRegistry.getZoneFor(dim, cx, cz);
        int[][] chunks;
        if (zone != null) {
            chunks = zone.getAllChunks();
        } else {
            // Fallback: scan a small area if zone isn't registered
            int radius = Math.max(2, WorldHordesConfig.COMMON.infestationRegionRadius.get());
            List<int[]> list = new ArrayList<>();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    list.add(new int[]{cx + dx, cz + dz});
                }
            }
            chunks = list.toArray(new int[0][]);
        }

        com.worldhordes.mod.registry.ModBlocks.BLOOD_SPLATTER.ifPresent(bloodBlock -> {
            int removed = 0;
            for (int[] chunk : chunks) {
                int chunkX = chunk[0], chunkZ = chunk[1];
                if (!serverLevel.hasChunk(chunkX, chunkZ)) continue;
                net.minecraft.world.level.chunk.LevelChunk lc = serverLevel.getChunk(chunkX, chunkZ);
                net.minecraft.world.level.ChunkPos cp = lc.getPos();
                int baseX = cp.getMinBlockX();
                int baseZ = cp.getMinBlockZ();
                int minY = serverLevel.getMinBuildHeight();
                int maxY = serverLevel.getMaxBuildHeight();
                for (int bx = baseX; bx < baseX + 16; bx++) {
                    for (int bz = baseZ; bz < baseZ + 16; bz++) {
                        for (int by = minY; by < maxY; by++) {
                            net.minecraft.core.BlockPos pos = new net.minecraft.core.BlockPos(bx, by, bz);
                            if (serverLevel.getBlockState(pos).getBlock() == bloodBlock) {
                                serverLevel.setBlock(pos,
                                        net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),
                                        net.minecraft.world.level.block.Block.UPDATE_CLIENTS
                                        | net.minecraft.world.level.block.Block.UPDATE_SUPPRESS_DROPS);
                                removed++;
                            }
                        }
                    }
                }
            }
            if (removed > 0) {
                WorldHordesMod.LOGGER.info("[WorldHordes] Removed {} blood decals from cleared zone at ({},{}).", removed, cx, cz);
            }
        });

        // Deregister the zone
        InfestationZoneRegistry.removeZone(dim, cx, cz);
    }

    /**
     * Check if a new infested region origin at (cx, cz) is far enough from
     * all existing infested regions. Returns true if placement is valid.
     */
    public static boolean isRegionDistanceValid(String dim, int cx, int cz) {
        int minDist = WorldHordesConfig.COMMON.infestationRegionMinDistance.get();
        if (minDist <= 0) return true;
        // Check via zone registry first
        if (InfestationZoneRegistry.getAllZones().size() > 0) {
            int[] nearest = InfestationZoneRegistry.getNearestZoneCentre(dim, cx, cz, minDist - 1);
            if (nearest != null) return false;
        }
        // Fallback: also check raw chunk data for legacy compatibility
        for (Map.Entry<String, ChunkInfestationLevel> entry : chunkData.entrySet()) {
            ChunkInfestationLevel inf = entry.getValue();
            if (inf.getLevel() <= 0) continue;
            String[] parts = entry.getKey().split(":");
            if (parts.length < 3) continue;
            String entryDim = String.join(":", Arrays.copyOf(parts, parts.length - 2));
            if (!entryDim.equals(dim)) continue;
            try {
                int ecx = Integer.parseInt(parts[parts.length - 2]);
                int ecz = Integer.parseInt(parts[parts.length - 1]);
                int dist = Math.max(Math.abs(cx - ecx), Math.abs(cz - ecz));
                if (dist < minDist) return false;
            } catch (NumberFormatException ignored) {}
        }
        return true;
    }

    /**
     * Find the centre of the nearest infested region to (cx, cz), or null if none within range.
     * Used by the player warning system.
     */
    public static int[] getNearestInfestedRegionCentre(String dim, int cx, int cz, int searchRadius) {
        // Prefer zone registry
        int[] zoneCentre = InfestationZoneRegistry.getNearestZoneCentre(dim, cx, cz, searchRadius);
        if (zoneCentre != null) return zoneCentre;

        // Fallback to raw chunk data
        int bestDist = Integer.MAX_VALUE;
        int[] best = null;
        for (Map.Entry<String, ChunkInfestationLevel> entry : chunkData.entrySet()) {
            ChunkInfestationLevel inf = entry.getValue();
            if (!inf.isInfested()) continue;
            String[] parts = entry.getKey().split(":");
            if (parts.length < 3) continue;
            String entryDim = String.join(":", Arrays.copyOf(parts, parts.length - 2));
            if (!entryDim.equals(dim)) continue;
            try {
                int ecx = Integer.parseInt(parts[parts.length - 2]);
                int ecz = Integer.parseInt(parts[parts.length - 1]);
                int dist = Math.max(Math.abs(cx - ecx), Math.abs(cz - ecz));
                if (dist <= searchRadius && dist < bestDist) {
                    bestDist = dist;
                    best = new int[]{ecx, ecz};
                }
            } catch (NumberFormatException ignored) {}
        }
        return best;
    }

    /**
     * Main tick: spread, decay, regen.
     */
    public static void tick() {
        long now = System.currentTimeMillis();

        if (now - lastDecayTime >= 60_000L) {
            lastDecayTime = now;
            applyPassiveDecay();
        }

        if (now - lastSpreadTime >= 60_000L) {
            lastSpreadTime = now;
            applySpread();
        }

        int regenIntervalMinutes = WorldHordesConfig.COMMON.infestationRegenIntervalMinutes.get();
        if (regenIntervalMinutes > 0) {
            long regenIntervalMs = regenIntervalMinutes * 60_000L;
            if (now - lastRegenTime >= regenIntervalMs) {
                lastRegenTime = now;
                applyPopulationRegen();
            }
        }
    }

    private static void applyPassiveDecay() {
        int decay = WorldHordesConfig.COMMON.infestationDecayPerMinute.get();
        List<String> toRemove = new ArrayList<>();
        for (Map.Entry<String, ChunkInfestationLevel> entry : chunkData.entrySet()) {
            ChunkInfestationLevel inf = entry.getValue();
            if (!inf.hasActiveHorde()) {
                inf.removeInfestation(decay);
                if (inf.getLevel() <= 0 && !inf.isCleared()) {
                    toRemove.add(entry.getKey());
                }
            }
        }
        toRemove.forEach(chunkData::remove);
    }

    private static void applyPopulationRegen() {
        int regenAmount = WorldHordesConfig.COMMON.infestationRegenAmountPerTick.get();
        if (regenAmount <= 0) return;
        int regenCount = 0;
        for (ChunkInfestationLevel inf : chunkData.values()) {
            if (inf.isInfested() && !inf.isCleared()) {
                inf.addToReserve(regenAmount);
                regenCount++;
            }
        }
        if (WorldHordesConfig.COMMON.debugMode.get() && regenCount > 0) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Population regen tick: +{} reserve to {} infested chunks.", regenAmount, regenCount);
        }
    }

    private static void applySpread() {
        double spreadChance = WorldHordesConfig.COMMON.infestationSpreadChance.get();
        int regionRadius    = WorldHordesConfig.COMMON.infestationRegionRadius.get();
        Random rand = new Random();
        Map<String, Integer> spreadsToApply = new HashMap<>();

        for (Map.Entry<String, ChunkInfestationLevel> entry : chunkData.entrySet()) {
            ChunkInfestationLevel inf = entry.getValue();
            if (!inf.shouldSpread()) continue;

            String[] parts = entry.getKey().split(":");
            if (parts.length < 3) continue;
            String dim = String.join(":", Arrays.copyOf(parts, parts.length - 2));
            int cx, cz;
            try {
                cx = Integer.parseInt(parts[parts.length - 2]);
                cz = Integer.parseInt(parts[parts.length - 1]);
            } catch (NumberFormatException e) { continue; }

            for (int dx = -regionRadius; dx <= regionRadius; dx++) {
                for (int dz = -regionRadius; dz <= regionRadius; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    int dist = Math.max(Math.abs(dx), Math.abs(dz));
                    double distChance = spreadChance / (1 + dist * 0.5);
                    if (rand.nextDouble() < distChance) {
                        String nbKey = key(dim, cx + dx, cz + dz);
                        ChunkInfestationLevel nbInf = chunkData.get(nbKey);
                        if (nbInf != null && nbInf.isCleared()) continue;
                        int spreadAmount = Math.max(1, inf.getLevel() / (10 + dist * 5));
                        spreadsToApply.merge(nbKey, spreadAmount, Integer::sum);
                    }
                }
            }
        }

        for (Map.Entry<String, Integer> spread : spreadsToApply.entrySet()) {
            chunkData.computeIfAbsent(spread.getKey(), k -> new ChunkInfestationLevel())
                    .addInfestation(spread.getValue());
        }
    }

    public static Set<Map.Entry<String, ChunkInfestationLevel>> getAllEntries() {
        return chunkData.entrySet();
    }

    public static Map<String, ChunkInfestationLevel> getChunkData() {
        return chunkData;
    }

    // -------------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------------

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(2);
            out.writeInt(chunkData.size());
            for (Map.Entry<String, ChunkInfestationLevel> entry : chunkData.entrySet()) {
                out.writeUTF(entry.getKey());
                ChunkInfestationLevel inf = entry.getValue();
                out.writeInt(inf.getLevel());
                out.writeLong(inf.getLastActivityTime());
                out.writeBoolean(inf.hasActiveHorde());
                out.writeBoolean(inf.isCleared());
                out.writeInt(inf.getZombieReserve());
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved {} infested chunks.", chunkData.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save infestation data", e);
        }
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            int version = in.readInt();
            int count = in.readInt();
            for (int i = 0; i < count; i++) {
                String k = in.readUTF();
                int level = in.readInt();
                long time = in.readLong();
                boolean horde = in.readBoolean();
                boolean cleared = false;
                int reserve = 0;
                if (version >= 2) {
                    cleared = in.readBoolean();
                    reserve = in.readInt();
                }
                chunkData.put(k, new ChunkInfestationLevel(level, time, horde, cleared, reserve));
            }
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded {} infested chunks.", chunkData.size());
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load infestation data", e);
        }
    }
}
