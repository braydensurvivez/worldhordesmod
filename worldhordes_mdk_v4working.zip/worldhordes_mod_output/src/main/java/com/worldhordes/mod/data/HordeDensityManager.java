package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.*;
import java.nio.file.Path;

public class HordeDensityManager {

    private static int globalDensity = 0;
    private static long lastDecayTime = 0;
    private static MinecraftServer server;

    private static final String SAVE_FILE = "worldhordes_density.dat";

    public static void init(MinecraftServer mcServer) {
        server = mcServer;
        load();
        lastDecayTime = System.currentTimeMillis();
    }

    public static void addDensity(int amount) {
        int max = WorldHordesConfig.COMMON.maxGlobalDensity.get();
        globalDensity = Math.min(globalDensity + amount, max);
        if (WorldHordesConfig.COMMON.debugMode.get()) {
            WorldHordesMod.LOGGER.debug("[WorldHordes] Density +{} -> {}", amount, globalDensity);
        }
    }

    public static void removeDensity(int amount) {
        globalDensity = Math.max(0, globalDensity - amount);
    }

    public static int getDensity() {
        return globalDensity;
    }

    public static boolean isAboveHordeThreshold() {
        return globalDensity >= WorldHordesConfig.COMMON.densityThresholdForHorde.get();
    }

    /**
     * Called periodically (once per minute) to apply passive density decay.
     */
    public static void tick() {
        long now = System.currentTimeMillis();
        long elapsed = now - lastDecayTime;
        if (elapsed >= 60_000L) {
            int decay = WorldHordesConfig.COMMON.densityDecayPerMinute.get();
            removeDensity(decay);
            lastDecayTime = now;
            if (WorldHordesConfig.COMMON.debugMode.get()) {
                WorldHordesMod.LOGGER.debug("[WorldHordes] Density decay -{} -> {}", decay, globalDensity);
            }
        }
    }

    public static void save(MinecraftServer mcServer) {
        Path worldDir = mcServer.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        try (DataOutputStream out = new DataOutputStream(new FileOutputStream(file))) {
            out.writeInt(globalDensity);
            out.writeLong(lastDecayTime);
            WorldHordesMod.LOGGER.info("[WorldHordes] Saved horde density: {}", globalDensity);
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to save density data", e);
        }
    }

    private static void load() {
        Path worldDir = server.getWorldPath(LevelResource.ROOT);
        File file = worldDir.resolve(SAVE_FILE).toFile();
        if (!file.exists()) return;
        try (DataInputStream in = new DataInputStream(new FileInputStream(file))) {
            globalDensity = in.readInt();
            lastDecayTime = in.readLong();
            WorldHordesMod.LOGGER.info("[WorldHordes] Loaded horde density: {}", globalDensity);
        } catch (IOException e) {
            WorldHordesMod.LOGGER.error("[WorldHordes] Failed to load density data", e);
        }
    }
}
