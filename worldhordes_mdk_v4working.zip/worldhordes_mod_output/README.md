# Days Gone: Zombie Horde Ecosystem Mod
**Minecraft 1.20.1 | Forge 47.4.10**

A dynamic zombie population and territory system inspired by *Days Gone*. The world reacts to every zombie spawned, every kill made, and every survivor lost — building toward a living ecosystem of roaming hordes and infested territories.

---

## Installation

1. Install [Forge 47.4.10 for Minecraft 1.20.1](https://files.minecraftforge.net/)
2. Drop the compiled `daysgone-1.0.0.jar` into your `mods/` folder
3. Start the game — config file generates at `config/daysgone-common.toml`

### Building from Source
```bash
./gradlew build
# Output: build/libs/daysgone-1.0.0.jar
```

---

## Core Systems

### 🧠 Horde Density (Global)
A single global value that tracks the "danger level" of the world's zombie population.

| Event | Density Change |
|-------|----------------|
| Natural zombie spawns | +1 (configurable) |
| Player killed by zombie | +25 |
| NPC/Villager killed by zombie | +10 |
| Player kills a zombie | -2 |

- **Passive decay**: -3 per minute (configurable)
- **Horde threshold**: When density reaches 100+, wandering hordes begin spawning
- **Cap**: 10,000 max density

---

### 🧟 Wandering Hordes
When Horde Density crosses the threshold, a wandering horde forms somewhere in the world — distant from players, but moving toward them.

- **Size scales with density**: Higher density → bigger hordes
- **Movement**: Hordes migrate chunk by chunk on a cooldown timer
- **Encounter**: When a horde passes within 8 chunks of a player, a wave of zombies is deployed
- **Settlement**: Hordes can settle into heavily infested chunks and dig in
- **Max active hordes**: 5 (configurable)

---

### 🗺️ Chunk Infestation System
Every chunk has an infestation level (0–1000+) that determines how dangerous it is.

#### Infestation Sources
- Natural zombie spawns in a chunk: +2 infestation
- Horde arriving in a chunk: +150 infestation
- Horde leaving a chunk: +50 infestation (zombies left behind)

#### Infestation Decay
- Player kills zombie in chunk: -5 infestation
- Passive decay (no horde): -1 per minute

#### Infestation Tiers
| Tier | Level | Effects |
|------|-------|---------|
| **None** | < 100 | Normal vanilla behavior |
| **Tier 1** | 100–399 | +1 extra zombie per spawn, +2 group size |
| **Tier 2** | 400–699 | +3 extra zombies per spawn, +5 group size |
| **Tier 3** | 700+ | +6 extra zombies per spawn, +10 group size |

#### Spread
Chunks at 500+ infestation have a 5% chance per minute to spread to each adjacent chunk. Infestation is contagious — clearing one chunk while ignoring neighbors will see it re-infested.

---

### 💾 Data Persistence
All data is saved per-world:
- `<world>/daysgone_density.dat` — Global Horde Density state
- `<world>/daysgone_infestation.dat` — All chunk infestation levels
- `<world>/daysgone_hordes.dat` — All active wandering horde states

Data is automatically loaded on server start and saved on server stop.

---

## Configuration (`config/daysgone-common.toml`)

### Key Settings
```toml
[horde_density]
  densityThresholdForHorde = 100   # Density needed to trigger hordes
  maxGlobalDensity = 10000         # Cap on global density
  densityDecayPerMinute = 3        # Passive density drop per minute

[horde_spawning]
  hordeMinSize = 8                 # Smallest horde that can form
  hordeMaxSize = 30                # Largest horde (scaled by density)
  maxActiveHordes = 5              # How many hordes roam at once
  hordeSpawnIntervalTicks = 6000   # ~5 minutes between horde checks

[infestation]
  infestationSpreadThreshold = 500 # Level at which chunks spread
  infestationSpreadChance = 0.05   # 5% per minute spread chance

[misc]
  debugMode = false                # Enable to see detailed logs
  ticksPerInfestationUpdate = 1200 # ~60s between full updates
```

---

## How Gameplay Changes

**Early game**: Mostly vanilla. A few more zombies in areas you've avoided.

**Mid game**: Horde Density builds. You start seeing larger zombie packs. Chunks near your deaths or NPC villages start showing Tier 1 infestation.

**Late game**: Wandering hordes roam the world. Heavily infested territories become nearly impassable at night. Clearing an area requires systematic zombie elimination across multiple chunks — and constant vigilance against re-infestation from spreading neighbors or migrating hordes.

---

## Mod Structure

```
src/main/java/com/daysgone/mod/
├── DaysGoneMod.java              - Mod entrypoint
├── config/
│   └── DaysGoneConfig.java       - All config values
├── data/
│   ├── HordeDensityManager.java  - Global density tracker + persistence
│   ├── InfestationData.java      - Per-chunk infestation + spread + persistence
│   └── ChunkInfestationLevel.java- Data model for one chunk's infestation
├── horde/
│   ├── HordeManager.java         - Horde lifecycle, migration, spawning
│   └── WanderingHorde.java       - Data model for one wandering horde
├── events/
│   ├── EntityEventHandler.java   - Death events → density/infestation changes
│   ├── SpawnEventHandler.java    - Spawn events → extra zombies in infested chunks
│   └── WorldEventHandler.java    - Server tick → drives horde system
├── registry/
│   └── ModCapabilities.java      - Capability registration (extensible)
├── capability/
│   └── ChunkInfestationCapability.java - Stub for future use
└── util/
    └── DimUtil.java              - Dimension name helpers
```

---

## License
MIT — free to use, modify, and distribute.
