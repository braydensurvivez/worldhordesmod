package com.worldhordes.mod.data;

import com.worldhordes.mod.WorldHordesMod;
import com.worldhordes.mod.config.WorldHordesConfig;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;

/**
 * NaturalSpawnGatekeeper — time-gated quota system for natural spawn instances.
 *
 * Each infestation zone (den) has its own cooldown window.  After a zone absorbs
 * its allowed quota of members from natural spawns it enters a cooldown period.
 * Only once the cooldown elapses can it absorb new natural spawn members again.
 *
 * The global density bank uses the same mechanism: once it has received its quota
 * of contributions from natural spawns it waits for the cooldown before accepting more.
 *
 * Configurable via:
 *   /worldhordes naturalspawn [time_seconds] [max_members]
 *
 * Defaults (from config):
 *   naturalSpawnCooldownSeconds  = 30
 *   naturalSpawnMaxMembersPerWindow = 5
 */
public class NaturalSpawnGatekeeper {

    // ---- Runtime overrides (0 = use config default) ----
    private static volatile int cooldownSecondsOverride = 0;
    private static volatile int maxMembersOverride       = 0;

    // ---- Global density gate (world horde bank) ----
    private static int  globalConsumedThisWindow = 0;
    private static long globalWindowStartMs      = System.currentTimeMillis();

    // ---- Per-den gate: zoneKey -> consumed count this window ----
    private static final Map<String, Integer> denConsumed      = new ConcurrentHashMap<>();
    // Per-den gate: zoneKey -> window start time (ms)
    private static final Map<String, Long>    denWindowStart   = new ConcurrentHashMap<>();

    // -------------------------------------------------------------------------
    // Config helpers
    // -------------------------------------------------------------------------

    public static int getEffectiveCooldownSeconds() {
        if (cooldownSecondsOverride > 0) return cooldownSecondsOverride;
        return WorldHordesConfig.COMMON.naturalSpawnCooldownSeconds.get();
    }

    public static int getEffectiveMaxMembers() {
        if (maxMembersOverride > 0) return maxMembersOverride;
        return WorldHordesConfig.COMMON.naturalSpawnMaxMembersPerWindow.get();
    }

    // -------------------------------------------------------------------------
    // Global density gate
    // -------------------------------------------------------------------------

    /**
     * Attempt to record a natural spawn contribution to the global density bank.
     * Returns the number of members actually allowed (0 or 1 per natural spawn call).
     */
    public static int tryGlobalContribute(int amount) {
        long now = System.currentTimeMillis();
        long cooldownMs = getEffectiveCooldownSeconds() * 1000L;
        int  maxMembers = getEffectiveMaxMembers();

        // Reset window if cooldown has elapsed
        if (now - globalWindowStartMs >= cooldownMs) {
            globalConsumedThisWindow = 0;
            globalWindowStartMs = now;
        }

        int remaining = maxMembers - globalConsumedThisWindow;
        int allowed   = Math.min(amount, Math.max(0, remaining));
        globalConsumedThisWindow += allowed;

        if (allowed < amount && WorldHordesConfig.COMMON.debugMode.get()) {
            long msLeft = cooldownMs - (now - globalWindowStartMs);
            WorldHordesMod.LOGGER.debug(
                "[WorldHordes] Global natural spawn gate: allowed {}/{} (cooldown resets in {}ms)",
                allowed, amount, msLeft);
        }
        return allowed;
    }

    /** How many slots remain in the current global window. */
    public static int globalRemaining() {
        long now = System.currentTimeMillis();
        long cooldownMs = getEffectiveCooldownSeconds() * 1000L;
        if (now - globalWindowStartMs >= cooldownMs) return getEffectiveMaxMembers();
        return Math.max(0, getEffectiveMaxMembers() - globalConsumedThisWindow);
    }

    /** Milliseconds until the global window resets (0 if already reset). */
    public static long globalCooldownRemainingMs() {
        long now = System.currentTimeMillis();
        long elapsed = now - globalWindowStartMs;
        long cooldownMs = getEffectiveCooldownSeconds() * 1000L;
        return Math.max(0, cooldownMs - elapsed);
    }

    // -------------------------------------------------------------------------
    // Per-den gate
    // -------------------------------------------------------------------------

    /**
     * Attempt to record a natural spawn contribution to a specific den.
     * Returns the number of members actually allowed (0 or 1 per natural spawn call).
     *
     * @param zoneKey  unique key for the infestation zone/den
     * @param amount   how many members the spawn event wants to contribute
     */
    public static int tryDenContribute(String zoneKey, int amount) {
        long now = System.currentTimeMillis();
        long cooldownMs = getEffectiveCooldownSeconds() * 1000L;
        int  maxMembers = getEffectiveMaxMembers();

        long windowStart = denWindowStart.getOrDefault(zoneKey, 0L);
        int  consumed    = denConsumed.getOrDefault(zoneKey, 0);

        // Reset window if cooldown has elapsed
        if (now - windowStart >= cooldownMs) {
            consumed    = 0;
            windowStart = now;
            denWindowStart.put(zoneKey, windowStart);
            denConsumed.put(zoneKey, 0);
        }

        int remaining = maxMembers - consumed;
        int allowed   = Math.min(amount, Math.max(0, remaining));

        if (allowed > 0) {
            denConsumed.put(zoneKey, consumed + allowed);
        }

        if (allowed < amount && WorldHordesConfig.COMMON.debugMode.get()) {
            long msLeft = cooldownMs - (now - windowStart);
            WorldHordesMod.LOGGER.debug(
                "[WorldHordes] Den '{}' natural spawn gate: allowed {}/{} (cooldown resets in {}ms)",
                zoneKey, allowed, amount, msLeft);
        }
        return allowed;
    }

    /** How many slots remain for a specific den in its current window. */
    public static int denRemaining(String zoneKey) {
        long now = System.currentTimeMillis();
        long cooldownMs = getEffectiveCooldownSeconds() * 1000L;
        long windowStart = denWindowStart.getOrDefault(zoneKey, 0L);
        if (now - windowStart >= cooldownMs) return getEffectiveMaxMembers();
        int consumed = denConsumed.getOrDefault(zoneKey, 0);
        return Math.max(0, getEffectiveMaxMembers() - consumed);
    }

    /** Milliseconds until a specific den's window resets (0 if already reset). */
    public static long denCooldownRemainingMs(String zoneKey) {
        long now = System.currentTimeMillis();
        long cooldownMs = getEffectiveCooldownSeconds() * 1000L;
        long windowStart = denWindowStart.getOrDefault(zoneKey, 0L);
        return Math.max(0, cooldownMs - (now - windowStart));
    }

    // -------------------------------------------------------------------------
    // Runtime override getters/setters (used by commands)
    // -------------------------------------------------------------------------

    public static int  getCooldownSecondsOverride()         { return cooldownSecondsOverride; }
    public static void setCooldownSecondsOverride(int secs) { cooldownSecondsOverride = secs; }
    public static int  getMaxMembersOverride()              { return maxMembersOverride; }
    public static void setMaxMembersOverride(int members)   { maxMembersOverride = members; }

    /** Reset both overrides back to "use config". */
    public static void resetOverrides() {
        cooldownSecondsOverride = 0;
        maxMembersOverride      = 0;
    }

    /** Force-reset all window counters (for testing). */
    public static void forceReset() {
        globalConsumedThisWindow = 0;
        globalWindowStartMs      = System.currentTimeMillis();
        denConsumed.clear();
        denWindowStart.clear();
    }

    // -------------------------------------------------------------------------
    // Player-presence detection
    // -------------------------------------------------------------------------

    /**
     * Returns true if any player is currently standing inside the given zone's 4×4 chunk
     * footprint (core + outer ring, i.e. chunks from originX-1..originX+2 in both axes).
     *
     * Used by SpawnEventHandler to suppress natural spawn membership growth when a player
     * is actively inside the infested zone — preventing unfair respawn-during-combat.
     */
    public static boolean isPlayerInZone(ServerLevel level, com.worldhordes.mod.data.InfestationZone zone) {
        if (zone == null) return false;
        int minCx = zone.getOriginX() - 1;
        int maxCx = zone.getOriginX() + 2;
        int minCz = zone.getOriginZ() - 1;
        int maxCz = zone.getOriginZ() + 2;
        // Bounding box in block coordinates (full 4×4 chunk area)
        double minX = minCx * 16.0;
        double maxX = (maxCx + 1) * 16.0;
        double minZ = minCz * 16.0;
        double maxZ = (maxCz + 1) * 16.0;
        for (Player player : level.players()) {
            double px = player.getX(), pz = player.getZ();
            if (px >= minX && px < maxX && pz >= minZ && pz < maxZ) {
                return true;
            }
        }
        return false;
    }

    /** Remove tracking data for a specific den (called when a zone is destroyed). */
    public static void removeDen(String zoneKey) {
        denConsumed.remove(zoneKey);
        denWindowStart.remove(zoneKey);
    }
}
