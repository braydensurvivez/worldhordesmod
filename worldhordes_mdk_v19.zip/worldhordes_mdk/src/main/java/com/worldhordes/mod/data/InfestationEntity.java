package com.worldhordes.mod.data;

import com.worldhordes.mod.config.WorldHordesConfig;

/**
 * Represents the shared, zone-level population state of a single infestation.
 * The entire 4×4 zone (2×2 core + 1-chunk outer ring) shares ONE InfestationEntity.
 *
 * COMBAT LOCK: while the den is in active combat (a player has recently killed a zombie
 * inside it) natural spawn growth and regen are suppressed.  This prevents players from
 * fighting a den only to have it immediately regrow from natural spawns during the fight.
 */
public class InfestationEntity {

    private int population;
    private int spawnReserve;
    private boolean active;
    private boolean markedForDestruction;
    private long lastActivityTime;

    /**
     * Timestamp (System.currentTimeMillis) of the last player kill inside this den.
     * While (now - lastCombatTime) < COMBAT_LOCK_MS the den is "in combat" and will
     * not accept natural spawn growth or regen.
     */
    private long lastCombatTime = 0L;

    /** How long (ms) the den stays in combat-lock after the last player kill. 30 seconds. */
    private static final long COMBAT_LOCK_MS = 30_000L;

    /**
     * Timestamp of the last time a player entered this infested chunk.
     * Triggers ATTACK STATUS — aggressive spawn pressure.
     */
    private long lastPlayerEntryTime = 0L;

    /** How long (ms) the attack status persists after a player was last seen in the zone. 20 seconds. */
    private static final long ATTACK_STATUS_MS = 20_000L;

    /** Tracks how many zombies are currently spawned inside the zone (pre-pop + wave spawns). */
    private int currentLiveInChunk = 0;

    /** Minimum zombies that must be present inside the infested zone at all times (pressure floor). */
    public static final int MIN_CHUNK_PRESENCE = 50;

    private int lastDensityContribution = 0;
    private String zoneKey = null;

    public void setZoneKey(String key) { this.zoneKey = key; }
    public String getZoneKey() { return zoneKey; }

    // -------------------------------------------------------------------------

    public InfestationEntity(int initialPopulation) {
        this.population           = initialPopulation;
        this.spawnReserve         = initialPopulation;
        this.active               = false;
        this.markedForDestruction = false;
        this.lastActivityTime     = System.currentTimeMillis();
    }

    public InfestationEntity(int population, int spawnReserve, boolean active,
                              boolean markedForDestruction, long lastActivityTime) {
        this.population           = population;
        this.spawnReserve         = spawnReserve;
        this.active               = active;
        this.markedForDestruction = markedForDestruction;
        this.lastActivityTime     = lastActivityTime;
    }

    // -------------------------------------------------------------------------
    // Combat lock
    // -------------------------------------------------------------------------

    /** True if a player has killed a zombie here recently (within COMBAT_LOCK_MS). */
    public boolean isInCombat() {
        return (System.currentTimeMillis() - lastCombatTime) < COMBAT_LOCK_MS;
    }

    /** Refresh the combat timer. Called every time a player kills a zombie in this den. */
    public void markCombat() {
        lastCombatTime = System.currentTimeMillis();
    }

    /** Remaining combat-lock ms (0 if not in combat). */
    public long getCombatLockRemainingMs() {
        long remaining = COMBAT_LOCK_MS - (System.currentTimeMillis() - lastCombatTime);
        return Math.max(0, remaining);
    }

    // -------------------------------------------------------------------------
    // Attack status — triggered when a player enters an infested chunk
    // -------------------------------------------------------------------------

    /**
     * Called when any player steps into a chunk belonging to this zone.
     * Activates attack status, causing aggressive spawn pressure.
     */
    public void onPlayerEntered() {
        lastPlayerEntryTime = System.currentTimeMillis();
    }

    /**
     * True while a player has been inside the zone recently (within ATTACK_STATUS_MS).
     * During attack status, zombies spawn in groups from 1 chunk outside the zone
     * to maintain the MIN_CHUNK_PRESENCE floor.
     */
    public boolean isUnderAttack() {
        return (System.currentTimeMillis() - lastPlayerEntryTime) < ATTACK_STATUS_MS;
    }

    // -------------------------------------------------------------------------
    // Live-in-chunk tracking — the count of zombies actually spawned inside the zone
    // -------------------------------------------------------------------------

    /** Increments the live-in-chunk counter when a zombie is spawned inside zone bounds. */
    public void onZombieSpawnedInChunk() {
        currentLiveInChunk = Math.max(0, currentLiveInChunk + 1);
    }

    /**
     * Decrements the live-in-chunk counter when a tagged zombie dies or despawns.
     * Clamped to 0 — can never go negative.
     */
    public void onZombieRemovedFromChunk() {
        currentLiveInChunk = Math.max(0, currentLiveInChunk - 1);
    }

    /** How many WorldHordes-tagged zombies are currently alive inside the zone. */
    public int getCurrentLiveInChunk() { return currentLiveInChunk; }

    /**
     * How many more zombies need to be spawned to reach the MIN_CHUNK_PRESENCE floor.
     * Returns 0 if presence is already satisfied.
     * Capped by the remaining population so we never spawn more than available.
     */
    public int getPresenceDeficit() {
        int needed = Math.max(0, MIN_CHUNK_PRESENCE - currentLiveInChunk);
        // Don't deficit beyond remaining population
        return Math.min(needed, population);
    }

    // -------------------------------------------------------------------------
    // Population mutation
    // -------------------------------------------------------------------------

    /**
     * Natural zombie spawn within the zone increases shared population.
     * BLOCKED while the den is in combat to prevent active regen during a fight.
     */
    public void onNaturalSpawn(int amount) {
        if (isInCombat()) return; // combat lock — no growth during active fight

        int effective = (zoneKey != null)
                ? com.worldhordes.mod.data.NaturalSpawnGatekeeper.tryDenContribute(zoneKey, amount)
                : amount;
        if (effective <= 0) return;
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        population   = Math.min(population + effective, max);
        spawnReserve = Math.min(spawnReserve + effective, max);
        lastActivityTime = System.currentTimeMillis();
    }

    /**
     * Player kill reduces shared population, refreshes combat lock, and checks destroy threshold.
     * Returns true if the population just fell below the destroy threshold.
     */
    public boolean onZombieKilledByPlayer(int decayPerKill) {
        markCombat(); // refresh combat lock on every player kill
        population   = Math.max(0, population - decayPerKill);
        spawnReserve = Math.max(0, spawnReserve - 1);
        onZombieRemovedFromChunk(); // one fewer live zombie in the zone
        lastActivityTime = System.currentTimeMillis();
        int threshold = WorldHordesConfig.COMMON.infestationDestroyThreshold.get();
        if (population <= threshold && !markedForDestruction) {
            markedForDestruction = true;
            return true;
        }
        return false;
    }

    /**
     * Passive regen tick — also blocked during combat so players clearing a den
     * don't watch it refill in real-time while they fight.
     */
    public void applyRegen(int regenAmount) {
        if (markedForDestruction) return;
        if (isInCombat()) return; // combat lock — no regen during active fight

        int effective = (zoneKey != null)
                ? com.worldhordes.mod.data.NaturalSpawnGatekeeper.tryDenContribute(zoneKey, regenAmount)
                : regenAmount;
        if (effective <= 0) return;
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        population   = Math.min(population + effective, max);
        spawnReserve = Math.min(spawnReserve + effective / 2 + 1, max);
    }

    // -------------------------------------------------------------------------
    // Wave spawning
    // -------------------------------------------------------------------------

    public int drawFromReserve(int count) {
        int drawn = Math.min(count, spawnReserve);
        spawnReserve = Math.max(0, spawnReserve - drawn);
        return drawn;
    }

    public void returnToReserve(int count) {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        spawnReserve = Math.min(spawnReserve + count, max);
    }

    public void refillReserve() {
        int max = WorldHordesConfig.COMMON.infestationMaxLevel.get();
        int cap = Math.max(1, population / 2);
        if (spawnReserve < cap) {
            spawnReserve = Math.min(cap, spawnReserve + Math.max(1, population / 10));
            spawnReserve = Math.min(spawnReserve, max);
        }
    }

    // -------------------------------------------------------------------------
    // Global density contribution
    // -------------------------------------------------------------------------

    public int computeDensityContribution() {
        return active ? Math.max(1, population / 10) : 0;
    }

    public int computeDensityDelta() {
        int current = computeDensityContribution();
        int delta = current - lastDensityContribution;
        lastDensityContribution = current;
        return delta;
    }

    public int getLastDensityContribution() { return lastDensityContribution; }

    // -------------------------------------------------------------------------
    // State queries
    // -------------------------------------------------------------------------

    public int     getPopulation()            { return population; }
    public int     getSpawnReserve()          { return spawnReserve; }
    public boolean isActive()                 { return active; }
    public boolean isMarkedForDestruction()   { return markedForDestruction; }
    public long    getLastActivityTime()      { return lastActivityTime; }

    public void setActive(boolean active)     { this.active = active; }
    public void setPopulation(int pop)        { this.population = Math.max(0, pop); }
}
